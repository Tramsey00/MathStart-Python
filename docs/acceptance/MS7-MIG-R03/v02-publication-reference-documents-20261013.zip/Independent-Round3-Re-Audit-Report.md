# MS7-MIG-V02 — Independent Round 3 Re-Audit Report

13.10.2026, Europe/Moscow. Issue #35. Независимый **STRICT READ-ONLY** аудит publication gate. Исходный worktree/index не изменён; пробы, отчёт и trace находятся вне репозитория. Human Task Approval не выдаётся.

**Verdict: TECHNICALLY VERIFIED — OWNER EXCEPTION APPROVAL PENDING.** Последний manifest mode/attributes P2 закрыт на проверенном staged snapshot. Действующий внешний R03 gate и решение Руслана не подтверждены; разрешение на publication этим отчётом не выдаётся.

| Статус | Результат |
| --- | --- |
| Manifest mode/attributes P2 | **CLOSED** |
| P01 external trust anchor | **PENDING** |
| P02 | **CLOSED** |
| P03 | **CLOSED** |
| Full git diff --check | **FAIL / exit 2** |
| Blocking implementation/publication defects | **0** |
| Human Task Approval | **PENDING** |

## 1. Reviewed source/index snapshot

Branch `ms7-mig-v02-content`; HEAD / V02_BASE_SHA `0c03197e23f69a233c0fcf8bdffa336feca20b92`. Merge-base с локальным remote-tracking integration ref: `0c03197e23f69a233c0fcf8bdffa336feca20b92`. Immutable MIG_BASE_SHA и merge-base с ним: `60b341fbd00f4c8dadd54ae9a3e5811869a9b0f7`. Implementation commit отсутствует: HEAD остаётся input BASE, `tested_implementation_sha=null`, `publication_status=PENDING_PUBLICATION`.

Фактически **151 staged additions, 0 unstaged, 0 untracked**; modified/deleted baseline paths отсутствуют. Все151 index entries stage0/mode100644. Точный publication tree, созданный **только в scratch**, `dbad1e853dff354c5d3255755afb5cc32e0ad279`; это tree OID, не commit SHA. Owner Владимир и Task Approver/root CI Owner Руслан подтверждены локальной active plan и migration ownership specification. Live Issue/назначения в GitHub не проверялись.

Windows, Python **3.12.10**, Git **2.47.0.windows.1**. Source commands: `GIT_OPTIONAL_LOCKS=0`; Python runners: `-I -B`; зависимости не устанавливались. Source index SHA256 до/после `753f1c31f73b9186cbff005a22351b18d5aa10157d8ed6b5035bb884049340db`; все 1823 tracked index entries, status/HEAD/branch и рабочие SHA256 совпали.

Прочитаны report-v3, manifest-v3, owner-handoff и bindings, v2/v3 verifier/policy, тестовые harness sources, применимые attributes, предыдущий независимый negative report и independent acceptance records. Обязательные источники доступны; пересказы разработчика не заменяли внешние originals. Полные read/hash receipts: [supplement-evidence.json](<C:/Users/vladimir/.codex/visualizations/2026/10/13/01a132a9-e802-75c1-a84a-4987aeee13c2/publication-reaudit-v3/supplement-evidence.json>).

## 2. Previous P2 reproduction against v2

В отдельном Git root восстановлен **точный прежний139** staged path set из неизменённых текущих blobs. Неизменённый v2 executable вынесен за scratch root; синтетический byte-only anchor фиксировал reviewed policy/verifier/manifest SHA256. Fixture содержит явное NOT OWNER APPROVAL. Результаты ниже воспроизведены самостоятельно.

| Probe | Secure expected exit | Actual exit | Результат |
| --- | ---: | ---: | --- |

| v2-correct139-baseline | 0 | 0 | Baseline PASS |

| v2-manifest-mode-local | 1 | 0 | Исходный bypass воспроизведён |

| v2-manifest-mode-byte-anchor | 1 | 0 | Исходный bypass воспроизведён |

| v2-manifest-mode-tree-byte-anchor | 1 | 0 | Исходный bypass воспроизведён |

| v2-manifest-text-local | 1 | 0 | Исходный bypass воспроизведён |

| v2-manifest-text-byte-anchor | 1 | 0 | Исходный bypass воспроизведён |

Все mutation cases сохраняли manifest SHA256 `77b1683733d82a6407f07cc8ce84b5f5344d9f1fd7bf4568ea294b0f6ab10662`, OID `b94ccda772489f8aa784cf0397bc59cfad96035f`, size103763. Mode100755 меняет tree metadata; -text меняет cached/working attributes без изменения bytes. Exact argv, attrs, modes, hashes/tree OID: [v2-corrected-reproduction.json](<C:/Users/vladimir/.codex/visualizations/2026/10/13/01a132a9-e802-75c1-a84a-4987aeee13c2/publication-reaudit-v3/v2-corrected-reproduction.json>).

Первоначальная настройка моей v2 копии ошибочно оставила151 paths и получила `PUBLICATION_PATH_SET`; после удаления **только12 Round3 entries во временном index** получены результаты139 выше. Эти setup failures не трактуются как защита v2.

## 3. Same attack results against v3

На финальном151 snapshot неизменённый independently copied v3 runner отвергает mode100755 и -text: **exit1 FIXED_MODE / FIXED_ATTRIBUTES**. Проверены local proposal, прежний synthetic byte-only anchor, новый metadata anchor и `--ref` altered-tree mode. При mode/attribute attacks manifest bytes/OID/size остаются прежними. Никакой автоприём изменённых index metadata не наблюдался.

Baseline with correct synthetic metadata anchor проходит exit0; default без anchor возвращает **exit3 OWNER_EXCEPTION_APPROVAL_PENDING**. Synthetic success обозначен `SYNTHETIC_ANCHOR_VALIDATED_NOT_OWNER_APPROVAL`. Полные результаты: [probes.json](<C:/Users/vladimir/.codex/visualizations/2026/10/13/01a132a9-e802-75c1-a84a-4987aeee13c2/publication-reaudit-v3/probes.json>), окончательные восстановленные positives: [corrected-final-probes.json](<C:/Users/vladimir/.codex/visualizations/2026/10/13/01a132a9-e802-75c1-a84a-4987aeee13c2/publication-reaudit-v3/corrected-final-probes.json>).

## 4. Manifest mode/attributes negative tests

| Независимая mutation | Expected / actual | Actual error |
| --- | --- | --- |
| Manifest Git mode100755: local/metadata anchor/legacy anchor/tree | 1 / 1 | FIXED_MODE |
| Manifest -text или text=set вместо auto | 1 / 1 | FIXED_ATTRIBUTES |
| Manifest eol=crlf | 1 / 1 | FIXED_ATTRIBUTES |
| filter=unapproved | 1 / 1 | FIXED_ATTRIBUTES |
| working-tree-encoding=UTF-16LE-BOM | 1 / 1 | FIXED_ATTRIBUTES |
| ident=set, export-subst=set | 1 / 1 | FIXED_ATTRIBUTES |
| Unknown attribute=value и unknown attribute=unset | 1 / 1 | FIXED_ALL_ATTRIBUTES |
| Те же9 attribute mutations для policy и verifier | 1 / 1 каждый | FIXED_ATTRIBUTES / FIXED_ALL_ATTRIBUTES |
| Policy/verifier/derived-bindings mode100755 | 1 / 1 каждый | FIXED_MODE |
| Root .gitattributes content replacement | 1 / 1 | EXISTING_BASELINE_CHANGE |
| V02 .gitattributes content replacement | 1 / 1 | BLOB_OID |
| Root / V02 .gitattributes effective filter change | 1 / 1 | TRUSTED_ATTRIBUTES_EFFECTIVE / FIXED_ATTRIBUTES |
| Applicable V02 .gitattributes adds manifest -text; old manifest bytes | 1 / 1 | BLOB_OID |
| То же с пересчитанным manifest/handoff | 1 / 1 | FIXED_ATTRIBUTES |

Attributes probes использовали exact path `.git/info/attributes` в scratch; staged-file probes использовали raw hash-object/update-index. Source mode/bytes/index не менялись. Full `check-attr --cached -a` обнаруживает unknown attributes; fixed13 map отдельно проверяет specified/unspecified values. Данные и SHA проверенных151 файлов находятся в integrity inventory.

## 5. Full 151-file integrity reconciliation

**139 предыдущих +12 новых =151**. Внешний previous independent reconciliation подтверждает OID/SHA256/size/mode/working SHA256 всех139; drift0. Четыре прежних независимо измеренных attributes совпадают; полные13/full maps сверены с v3 policy и intake, defaults/raw profiles совпали для всех151. Cached и working maps совпадают.

Manifest содержит149 byte records плюс2 контролируемых paths: self manifest и derived handoff. Missing/extra0; для149 каждый blob OID, SHA256, size, mode,13/full attributes независимо сопоставлен с реальным index. Полные151 records и additions: [reconciliation.json](<C:/Users/vladimir/.codex/visualizations/2026/10/13/01a132a9-e802-75c1-a84a-4987aeee13c2/publication-reaudit-v3/reconciliation.json>).

Все12 additions находятся в `docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/`. Назначения:

| Новый файл | Назначение | SHA256 staged blob |
| --- | --- | --- |

| checkout-results.json | Developer checkout receipts; промежуточные/final snapshots различаются, final independently rerun здесь. | `451f78983d0526a3f6efe488c8b9d1a22424d6f4f1a6f06e0204b3b9ed5d10da` |

| exception-policy.json | Exact40 exceptions,73 raw pins,139 previous pins,151 paths и fixed metadata. | `0e990932da607ff62ad8ed51938d78ff830e0043c56708faa137076791a09d6a` |

| intake.json | 139-file pre-Round3 inventory и metadata observations. | `bc2cd4d0eb7be970716c765f5aaf81b89a98bd546b2a5aacd98b368718fc424a` |

| owner-handoff-bindings.json | Derived non-circular exact five-input handoff. | `a3151ad6a39066a9cd01b952f9aa3fb89c5e124d0adac21438aea3aade024100` |

| owner-handoff.md | Owner-controlled gate schema/commands/control requirements. | `1221ca4f8d78206cb04c5e196acdb05848e8a9258e94b4bdecf9731eca40fe7e` |

| probe-results.json | Developer v2/v3 attacks, commands/hashes; не independent verdict. | `bc1d98b155a371e5dd089d667f07cd708a4a77914a805418376b615af7e2ab0d` |

| publication-manifest-v3.json | 149 byte records плюс self/derived controls. | `9763119d60d8355854c45df6c032424a3dfac54e7d0576de25ff0247a2dfd394` |

| report-v3.md | Scope, limitations, gate status и авторские результаты. | `e2eb6bbd1b00355d395f33f897b19d45699603347916c9554c80b7a5682e1e69` |

| source-imports.json | Lossless previous independent negative audit: base64 плюс escaped UTF8. | `e0059e099bd0615b556b1ee86c6f9ca9fa877455ce53854e2609ce6b0deffc45` |

| test_publication_v3.py | Real-Git scratch harness, использующий только standard library. | `5d4df8ce60ca385d78dc93f88d6d61092952c122e1eaf3d6d3c447c02f1d1123` |

| verification.json | Developer final checks/status/receipt summary. | `80c5959baa62e0d5f8345e7df5b5c4706ca1edd9fe4af7d067913d84a83c95f2` |

| verify_publication_v3.py | Standalone checker; pinned policy, all151 metadata, external metadata-anchor validation. | `54da54d7a54f9ca714a393577a31a74e948c373bbee4c92045110958c59a56a5` |

Ownership violations0; временные/cache/DB/credential filenames не найдены. Limited staged-byte private-key/AWS/GitHub/OpenAI-token signature inspection: findings0. Новые записи — объяснённые task evidence; production credentials не обнаружены. Dedicated universal secret/PII scanner не запускался; это ограничение, не универсальная гарантия.

## 6. Manifest and trust-policy verification

У v3 expected mode/attributes поступают из policy `default_publication_metadata` / `raw_publication_metadata`, чей **точный byte SHA256 закреплён неизменённым reviewed executable**. Проверки FIXED_MODE/FIXED_ATTRIBUTES/FIXED_ALL_ATTRIBUTES выполняются для **всех151**, до branch исключения self byte hashes. Изменение ожидаемого mode внутри policy с пересчётом manifest возвращает1 POLICY_DIGEST_MISMATCH.

Сам manifest не содержит собственный hash; derived bindings не хешируются в manifest, поскольку содержат manifest SHA. Их bytes обязаны равняться canonical recomputation five-input binding, а mode/attributes фиксированы. Самоподтверждающего circular hash нет. Изменённый derived JSON возвращает1 HANDOFF_BINDINGS_CONTENT.

Изменение manifest bytes с корректно пересчитанным derived handoff отвергается прежним внешним metadata anchor:1 OWNER_INPUT_BYTES_AND_METADATA. В anchor проверяются SHA256/OID/size/mode/13 attributes/full map для всех5 inputs; **изолированные** неверные manifest tuple fields (SHA256, OID, size, mode, attributes, full map) каждый вернули1 OWNER_INPUT_BYTES_AND_METADATA. Прежний v2 byte-only schema не является достаточным v3 approval artifact.

Joint replacement policy + verifier digest + manifest + handoff: изменённый runner в local proposal получает0, unchanged trusted runner возвращает1 POLICY_DIGEST_MISMATCH, изменённый runner с прежним independently pinned anchor возвращает1 OWNER_INPUT_BYTES_AND_METADATA. Before-execution digest pin также выявляет changed executable. Это подтверждает необходимость внешнего executable/anchor, а не защищённость произвольного task self-check.

Actual joint mutations, SHA256/OIDs и commands: [joint-tamper.json](<C:/Users/vladimir/.codex/visualizations/2026/10/13/01a132a9-e802-75c1-a84a-4987aeee13c2/publication-reaudit-v3/joint-tamper.json>). Final isolated anchor/manifest negatives: [corrected-final-probes.json](<C:/Users/vladimir/.codex/visualizations/2026/10/13/01a132a9-e802-75c1-a84a-4987aeee13c2/publication-reaudit-v3/corrected-final-probes.json>).

## 7. P02 clean-checkout tests

Созданы **три отдельных свежих Git roots**; source index скопирован, objects доступны через read-only alternates. Реальный `git checkout-index --all --force`, `core.longpaths=true`, Python -I -B. Commit/reset/clean не выполнялись.

| core.autocrlf | Correct synthetic metadata anchor | --ref staged tree + тот же anchor |
| --- | --- | --- |
| false | PASS/0 | PASS/0 |
| true | PASS/0 | PASS/0 |
| input | PASS/0 | PASS/0 |

Все три используют одинаковый exact151 tree. Raw73 остаются точными bytes; normal paths используют text=auto,eol=lf. Проходящие actual checks не зависят от developer absolute source paths или прежних Windows working hashes. P02 CLOSED в проверенном Windows scope; cross-OS execution не выполнялся.

## 8. P03 40-path exception verification

Policy содержит ровно40 уникальных whitespace exceptions и отдельно73 unique raw-preservation paths;40 subset73,33 raw paths не exempt. Все40 entries (paths/OID/SHA256/size/line reasons) и73 raw entries **полностью равны v2 policy**. Exceptions не включают active backend/tests либо новые mutable Round3 reports/manifests.

Каждый из40 actual blobs независимо изменён (`original bytes + X`) во временном index, manifest/handoff пересчитаны. **40/40 → exit1 ORIGINAL139_BLOB_MUTATION** на конкретном изменённом path. Добавление нового exception →1 POLICY_DIGEST_MISMATCH. Новый whitespace defect в report-v3 вне40 после корректного rebind →1 UNKNOWN_OR_CHANGED_WHITESPACE_DIAGNOSTICS: ordinary.

Исторические raw73 working bytes равны staged blobs. Все3887 ordinary diagnostic lines имеют CR suffix без trailing space/tab перед CR;6 residual diagnostics — CRCR на строках68/79 трёх verify-repo-command records. Каждый actual diagnostic line/reason array точно равен policy. Полные independently checked40 hashes/OIDs/reasons/lines: [supplement-evidence.json](<C:/Users/vladimir/.codex/visualizations/2026/10/13/01a132a9-e802-75c1-a84a-4987aeee13c2/publication-reaudit-v3/supplement-evidence.json>); handoff exception records: [independently-measured-handoff.json](<C:/Users/vladimir/.codex/visualizations/2026/10/13/01a132a9-e802-75c1-a84a-4987aeee13c2/publication-reaudit-v3/independently-measured-handoff.json>).

## 9. Actual full/scoped whitespace exit codes

| Реальный Git check | Result | Exit | Diagnostics / paths | Stream SHA256 |
| --- | --- | ---: | --- | --- |

| full-cr-at-eol | **FAIL** | 2 | 6 / 3 | `5837278beb0d2ef638db564512c6913f9ae02346d204ba7b75c059aaef373f63` |

| full-ordinary | **FAIL** | 2 | 3887 / 40 | `c1b69b199ac5cd41c665d656a72587d36ff0d13dc04a82c0a4c3d75086da20fb` |

| scoped-cr-at-eol | PASS | 0 | 0 / 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |

| scoped-ordinary | PASS | 0 | 0 / 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |

Запущены full `git diff --cached --check`, full `git -c core.whitespace=cr-at-eol diff --cached --check` и оба scoped checks с точными `:(exclude,literal)` для40 путей. Полные FAIL/2 **не переименованы в PASS**. stdout сохранён полностью без подавления; stderr пуст. [whitespace.json](<C:/Users/vladimir/.codex/visualizations/2026/10/13/01a132a9-e802-75c1-a84a-4987aeee13c2/publication-reaudit-v3/whitespace.json>), [full-ordinary.txt](<C:/Users/vladimir/.codex/visualizations/2026/10/13/01a132a9-e802-75c1-a84a-4987aeee13c2/publication-reaudit-v3/full-ordinary.txt>), [full-cr-at-eol.txt](<C:/Users/vladimir/.codex/visualizations/2026/10/13/01a132a9-e802-75c1-a84a-4987aeee13c2/publication-reaudit-v3/full-cr-at-eol.txt>).

## 10. Frozen and backend identity

Все28 backend/source/test/lock/README файлов побайтово совпадают с **внешним positive independent F01/F02 source snapshot** по SHA256/size и previous independent139 working inventory. F01/F02 остаются CLOSED; новый полный PostgreSQL/HTTP/runtime re-audit не требуется.

Все60 frozen HEAD/index blobs совпадают с inputBASE и historical external records; working hashes совпадают с external frozen receipts. Все47 archived files независимо совпадают с реально существующим **original negative independent snapshot**, не только авторским report. Original negative report/snapshot copies byte-identical external originals. V2 source imports проверены decoding/hash/size/verbatim против всех3 внешних originals, Round3 import — против actual previous negative publication report.

V01/Alembic, frontend и root CI unchanged: baseline staged/worktree изменений нет; весь139 previous task snapshot unchanged. Исторические negative verdicts не переписаны. Identity evidence позволяет не перезапускать runtime suites; старые PASS не объявляются новым выполнением.

## 11. Remaining P1/P2/P3 findings

**Новых подтверждённых P1/P2/P3 implementation defects:0.** Previous manifest self-metadata P2 CLOSED по независимо повторённым rejecting tests. P02/P03 CLOSED. P01 остаётся **PENDING**, поскольку нет проверенного deployed owner-controlled gate; это открытая зависимость внешней приёмки, а не новый bypass неизменённого v3 checker.

Setup mistakes собственного audit harness устранены:151 вместо139 в первой v2 copy; scratch root .gitattributes work bytes не входили в первоначальный publication151 restore set; первый вспомогательный manifest-byte test ошибочно восстановил исходный manifest при rebinding. Initial exit0 того последнего теста относится к **неизменённому manifest**, не к успешной атаке. После корректного изменения manifest bytes и rebind только handoff получен ожидаемый anchor FAIL. Joint-probe metadata annotation сначала использовала неверный тип dict; исправлено до mutation. Исходный worktree не затронут ни одной из этих ошибок.

Initial PUBLICATION_PATH_SET / TRUSTED_ATTRIBUTES_WORK результаты не используются как доказательство соответствующих intended tests. Они сохранены в raw probes и initial-harness-attempt receipts. Окончательные checks проверяют не только exit, но и конкретный rejection reason.

## 12. External trust-anchor dependencies

**LOCAL TECHNICAL CORRECTNESS:** reviewed v3 executable/policy/final151 snapshot проходят собственные positive/negative probes. **EXTERNAL TRUST ANCHOR:** Руслан/R03 должен независимо утвердить и закрепить vetted executable до execution, policy, manifest, Git metadata, applicable attributes inputs, exact40 exception paths/digest и отдельный approval artifact digest. **HUMAN TASK APPROVAL:** отдельно проверить опубликованный exact candidate SHA/current CI/acceptance.

`owner-handoff.md` + `owner-handoff-bindings.json` достаточны как **конкретный технический handoff**, чтобы Руслан реализовал независимый контроль в R03/root ownership **без изменения V02-owned files**. Они дают schema,5 exact tuples,40 paths/digest, commands, negatives, execution controls и запрет трактовать local/synthetic outputs как approval. Их собственные author-generated данные не являются approved pins.

Owner должен контролировать Python/Git binaries, startup/environment/config, base/ref/clean checkout, исключить untrusted PYTHONPATH, Git filter/external diff/fsmonitor и system/global/info attributes. Publication gate не использует --local-proposal; approved artifact не должен иметь `_fixture`. Перед execution проверяется independently supplied executable digest, затем anchor digest/tuples и exception decision. Candidate pins нельзя автоматически извлекать/одобрять из mutable evidence.

Наличие deployed R03 enforcement/реального approved anchor не доказано. **P01 external trust anchor: PENDING**, не CLOSED/VERIFIED.

## 13. Exact owner-handoff SHA256/OID/mode/attributes

Все tuples ниже независимо измерены из **staged Git blobs**, не взяты на доверии из developer report. Они совпали с owner-handoff bindings. Machine-readable полный5-input/40-exception пакет: [independently-measured-handoff.json](<C:/Users/vladimir/.codex/visualizations/2026/10/13/01a132a9-e802-75c1-a84a-4987aeee13c2/publication-reaudit-v3/independently-measured-handoff.json>).

| Exact input path | SHA256 staged blob | Git blob OID | Bytes | Mode |
| --- | --- | --- | ---: | --- |

| `.gitattributes` | `7a281342095c7b25129c37566a80d778bbe992a17d11f6db26ff707e09350069` | `57268d3f736a2c43c697c661521cbbf106f921f4` | 653 | 100644 |

| `docs/acceptance/MS7-MIG-V02/.gitattributes` | `176ca6dd41c2ce253a103f4d3a717004d6be84756ee3400b409a85a2b2f60e3f` | `24c965ee9cf9a9b3e04a296863140bbd34457adc` | 380 | 100644 |

| `docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/exception-policy.json` | `0e990932da607ff62ad8ed51938d78ff830e0043c56708faa137076791a09d6a` | `c28a0f52d54770232db9f97dfa46864096e60015` | 513044 | 100644 |

| `docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/publication-manifest-v3.json` | `9763119d60d8355854c45df6c032424a3dfac54e7d0576de25ff0247a2dfd394` | `f5ca3e093eef3ba4c3d3a61f993ac79f5dd3bf62` | 147628 | 100644 |

| `docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/verify_publication_v3.py` | `54da54d7a54f9ca714a393577a31a74e948c373bbee4c92045110958c59a56a5` | `28c6394703cd4f5792847feedd615f90ec568782` | 18578 | 100644 |

Для **каждого5 input**: `text=auto`, `eol=lf`; `filter`, `working-tree-encoding`, `ident`, `crlf`, `diff`, `whitespace`, `merge`, `binary`, `export-ignore`, `export-subst`, `encoding` = **unspecified**. Полный effective map ровно `{"eol":"lf","text":"auto"}`. Expected mode100644. Raw73 profile отдельно имеет text=unset, остальные значения те же.

Manifest SHA256 **`9763119d60d8355854c45df6c032424a3dfac54e7d0576de25ff0247a2dfd394`** подтверждён. Это raw staged Git blob SHA256; текущие original working-tree bytes имеют **тот же** SHA256. Manifest OID `f5ca3e093eef3ba4c3d3a61f993ac79f5dd3bf62`, size147628. Exception-set SHA256 `fa62cf5f4c9b3aaf91864b9face548a5f45759390fb7bedd9cdef5ae6e7c2e18` (canonical sorted-key compact JSON40 array + LF).

Передать Руслану exact input BASE, immutable MIG_BASE_SHA, reviewed treeOID из§1; пять tuples, оба fixed metadata profiles, full151 inventory, все40 exception blob SHA/OID/size/lines/reasons и exception-set digest. При publication дополнительно bind фактический reviewed candidate commit SHA и current CI. Отдельный real approval-artifact digest создаёт/контролирует owner; здесь такого digest нет.

## 14. NOT VERIFIED

- Deployed independently protected R03/root CI executable, реальный approved anchor и решение по40 exceptions.
- Human Task Approval Руслана; опубликованный implementation SHA/current candidate target CI; live GitHub approvals/Issue state.
- Новый PostgreSQL/HTTP/Django/V01/verify_repo execution: **NOT RERUN** по разрешённой identity-based scope. Historical PASS не заменяет новый run.
- Linux/macOS или иной cross-OS checkout; Windows longpaths scratch configuration использована явно.
- Полная V03/V04/I02/I03/V05 integration, production/performance/cutover/deployment.
- Dedicated universal secrets/PII scanning.

Production/working DB не использовалась. GitHub PR/review/message не создавались. No git add/commit/push/merge/reset/rebase/clean. Scratch update-index/hash-object/write-tree/ref setup не меняли source Git index/objects/refs.

## 15. Publication recommendation

**TECHNICALLY VERIFIED — OWNER EXCEPTION APPROVAL PENDING.** Последний manifest mode/attributes P2 CLOSED, P02 CLOSED, P03 CLOSED. Blocking implementation/publication defects0; full ordinary/cr-at-eol checks всё ещё FAIL/2. Exception acceptance и deployed external gate Руслана требуются до publication; Human Task Approval PENDING. Статус READY FOR PUBLICATION не выдаётся.

Сохранность source staged snapshot подтверждена byte SHA256 index, exact151 staged set, всеми 1823 tracked entries/working hashes, status/HEAD/branch до/после: [source-preservation.json](<C:/Users/vladimir/.codex/visualizations/2026/10/13/01a132a9-e802-75c1-a84a-4987aeee13c2/publication-reaudit-v3/source-preservation.json>), [before.json](<C:/Users/vladimir/.codex/visualizations/2026/10/13/01a132a9-e802-75c1-a84a-4987aeee13c2/publication-reaudit-v3/before.json>), [after.json](<C:/Users/vladimir/.codex/visualizations/2026/10/13/01a132a9-e802-75c1-a84a-4987aeee13c2/publication-reaudit-v3/after.json>). Отчёт относится к указанным staged bytes/metadata, не к будущему implementation commit.

## Appendix A. Exact independent probe results

Окончательная evidence selection: **112 CLI results** (включая v2 baseline +5 воспроизведённых bypasses). Все intended v3 negatives отвергнуты; joint local rewritten-runner PASS0 сохраняется как демонстрация внешней trust dependency. Exact argv, input snapshots, SHA256/OID/attrs и stdout hashes — JSON рядом.

| Probe | Expected exit | Actual exit | Actual reason/status |
| --- | ---: | ---: | --- |

| v3-clean-false-anchor | 0 | 0 | SYNTHETIC_ANCHOR_VALIDATED_NOT_OWNER_APPROVAL |

| v3-clean-false-tree-anchor | 0 | 0 | SYNTHETIC_ANCHOR_VALIDATED_NOT_OWNER_APPROVAL |

| v3-clean-true-anchor | 0 | 0 | SYNTHETIC_ANCHOR_VALIDATED_NOT_OWNER_APPROVAL |

| v3-clean-true-tree-anchor | 0 | 0 | SYNTHETIC_ANCHOR_VALIDATED_NOT_OWNER_APPROVAL |

| v3-clean-input-anchor | 0 | 0 | SYNTHETIC_ANCHOR_VALIDATED_NOT_OWNER_APPROVAL |

| v3-clean-input-tree-anchor | 0 | 0 | SYNTHETIC_ANCHOR_VALIDATED_NOT_OWNER_APPROVAL |

| v3-default-no-anchor | 3 | 3 | OWNER_EXCEPTION_APPROVAL_PENDING |

| v3-manifest-mode-anchor | 1 | 1 | FIXED_MODE: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/publication-manifest-v3.json |

| v3-manifest-mode-local | 1 | 1 | FIXED_MODE: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/publication-manifest-v3.json |

| v3-manifest-mode-tree | 1 | 1 | FIXED_MODE: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/publication-manifest-v3.json |

| v3-manifest-mode-legacy-anchor | 1 | 1 | FIXED_MODE: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/publication-manifest-v3.json |

| v3-policy-mode-anchor | 1 | 1 | FIXED_MODE: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/exception-policy.json |

| v3-verifier-mode-anchor | 1 | 1 | FIXED_MODE: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/verify_publication_v3.py |

| v3-bindings-mode-anchor | 1 | 1 | FIXED_MODE: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/owner-handoff-bindings.json |

| v3-manifest-attr--text | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/publication-manifest-v3.json |

| v3-manifest-text-local | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/publication-manifest-v3.json |

| v3-manifest-text-legacy-anchor | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/publication-manifest-v3.json |

| v3-manifest-attr-text | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/publication-manifest-v3.json |

| v3-manifest-attr-eol=crlf | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/publication-manifest-v3.json |

| v3-manifest-attr-filter=unapproved | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/publication-manifest-v3.json |

| v3-manifest-attr-working-tree-encoding=UTF-16LE-BOM | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/publication-manifest-v3.json |

| v3-manifest-attr-ident | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/publication-manifest-v3.json |

| v3-manifest-attr-export-subst | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/publication-manifest-v3.json |

| v3-manifest-attr-independent-unknown=enabled | 1 | 1 | FIXED_ALL_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/publication-manifest-v3.json |

| v3-manifest-attr--independent-unknown | 1 | 1 | FIXED_ALL_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/publication-manifest-v3.json |

| v3-policy-attr--text | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/exception-policy.json |

| v3-policy-attr-text | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/exception-policy.json |

| v3-policy-attr-eol=crlf | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/exception-policy.json |

| v3-policy-attr-filter=unapproved | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/exception-policy.json |

| v3-policy-attr-working-tree-encoding=UTF-16LE-BOM | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/exception-policy.json |

| v3-policy-attr-ident | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/exception-policy.json |

| v3-policy-attr-export-subst | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/exception-policy.json |

| v3-policy-attr-independent-unknown=enabled | 1 | 1 | FIXED_ALL_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/exception-policy.json |

| v3-policy-attr--independent-unknown | 1 | 1 | FIXED_ALL_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/exception-policy.json |

| v3-verifier-attr--text | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/verify_publication_v3.py |

| v3-verifier-attr-text | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/verify_publication_v3.py |

| v3-verifier-attr-eol=crlf | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/verify_publication_v3.py |

| v3-verifier-attr-filter=unapproved | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/verify_publication_v3.py |

| v3-verifier-attr-working-tree-encoding=UTF-16LE-BOM | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/verify_publication_v3.py |

| v3-verifier-attr-ident | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/verify_publication_v3.py |

| v3-verifier-attr-export-subst | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/verify_publication_v3.py |

| v3-verifier-attr-independent-unknown=enabled | 1 | 1 | FIXED_ALL_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/verify_publication_v3.py |

| v3-verifier-attr--independent-unknown | 1 | 1 | FIXED_ALL_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/verify_publication_v3.py |

| v3-root-attributes-bytes | 1 | 1 | EXISTING_BASELINE_CHANGE |

| v3-root-attributes-effective | 1 | 1 | TRUSTED_ATTRIBUTES_EFFECTIVE: .gitattributes |

| v3-local-attributes-bytes | 1 | 1 | BLOB_OID: docs/acceptance/MS7-MIG-V02/.gitattributes |

| v3-local-attributes-effective | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/.gitattributes |

| v3-applicable-attributes-manifest-unchanged | 1 | 1 | BLOB_OID: docs/acceptance/MS7-MIG-V02/.gitattributes |

| v3-applicable-attributes-rebound | 1 | 1 | FIXED_ATTRIBUTES: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/publication-manifest-v3.json |

| v3-exception-blob-55 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/full_content-command.txt |

| v3-exception-blob-56 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/legacy-fresh-smoke-command.txt |

| v3-exception-blob-57 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/legacy-version-report-command.txt |

| v3-exception-blob-58 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/r02-command.txt |

| v3-exception-blob-59 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/r02a-command.txt |

| v3-exception-blob-60 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/r03a-command.txt |

| v3-exception-blob-61 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/before-fix-command.txt |

| v3-exception-blob-62 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/full_content-command.txt |

| v3-exception-blob-63 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/files.md |

| v3-exception-blob-64 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/frozen-ownership.json |

| v3-exception-blob-65 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/full_content-command.txt |

| v3-exception-blob-66 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/legacy-fresh-smoke-command.txt |

| v3-exception-blob-67 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/legacy-version-report-command.txt |

| v3-exception-blob-68 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/old-to-new-evidence.json |

| v3-exception-blob-69 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/r02-command.txt |

| v3-exception-blob-70 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/r02a-command.txt |

| v3-exception-blob-71 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/r03a-command.txt |

| v3-exception-blob-72 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/routes.json |

| v3-exception-blob-73 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/test-matrix.json |

| v3-exception-blob-74 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/v01-command.txt |

| v3-exception-blob-75 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/v02-command.txt |

| v3-exception-blob-76 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/verification.json |

| v3-exception-blob-77 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/verify-repo-command.txt |

| v3-exception-blob-78 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/workspace-manifest.json |

| v3-exception-blob-79 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/intermediate-v02-84-command.txt |

| v3-exception-blob-80 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/legacy-fresh-smoke-command.txt |

| v3-exception-blob-81 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/legacy-version-report-command.txt |

| v3-exception-blob-82 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/original-audit/independent-source-snapshot.json |

| v3-exception-blob-83 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/r02-command.txt |

| v3-exception-blob-84 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/r02a-command.txt |

| v3-exception-blob-85 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/r03a-command.txt |

| v3-exception-blob-86 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/runtime-command.txt |

| v3-exception-blob-87 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/runtime-pip-command.txt |

| v3-exception-blob-88 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/test-pip-command.txt |

| v3-exception-blob-89 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/v01-command.txt |

| v3-exception-blob-90 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/v02-command.txt |

| v3-exception-blob-91 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/verify-repo-command.txt |

| v3-exception-blob-92 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/v01-command.txt |

| v3-exception-blob-93 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/v02-command.txt |

| v3-exception-blob-94 | 1 | 1 | ORIGINAL139_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/verify-repo-command.txt |

| v3-new-exception | 1 | 1 | POLICY_DIGEST_MISMATCH |

| v3-policy-metadata-tamper | 1 | 1 | POLICY_DIGEST_MISMATCH |

| v2-correct139-baseline | 0 | 0 | OWNER_EXCEPTION_APPROVED_BY_EXTERNAL_ANCHOR |

| v2-manifest-mode-local | 1 | 0 | OWNER_EXCEPTION_APPROVAL_PENDING |

| v2-manifest-mode-byte-anchor | 1 | 0 | OWNER_EXCEPTION_APPROVED_BY_EXTERNAL_ANCHOR |

| v2-manifest-mode-tree-byte-anchor | 1 | 0 | OWNER_EXCEPTION_APPROVED_BY_EXTERNAL_ANCHOR |

| v2-manifest-text-local | 1 | 0 | OWNER_EXCEPTION_APPROVAL_PENDING |

| v2-manifest-text-byte-anchor | 1 | 0 | OWNER_EXCEPTION_APPROVED_BY_EXTERNAL_ANCHOR |

| corrected-pristine-metadata-anchor | 0 | 0 | SYNTHETIC_ANCHOR_VALIDATED_NOT_OWNER_APPROVAL |

| corrected-new-whitespace-after-rebind | 1 | 1 | UNKNOWN_OR_CHANGED_WHITESPACE_DIAGNOSTICS: ordinary |

| corrected-manifest-bytes-rebound-anchor | 1 | 1 | OWNER_INPUT_BYTES_AND_METADATA |

| corrected-anchor-blob_sha256-mismatch | 1 | 1 | OWNER_INPUT_BYTES_AND_METADATA |

| corrected-anchor-blob_oid-mismatch | 1 | 1 | OWNER_INPUT_BYTES_AND_METADATA |

| corrected-anchor-blob_bytes-mismatch | 1 | 1 | OWNER_INPUT_BYTES_AND_METADATA |

| corrected-anchor-mode-mismatch | 1 | 1 | OWNER_INPUT_BYTES_AND_METADATA |

| corrected-anchor-attributes-mismatch | 1 | 1 | OWNER_INPUT_BYTES_AND_METADATA |

| corrected-anchor-attributes_all-mismatch | 1 | 1 | OWNER_INPUT_BYTES_AND_METADATA |

| corrected-bindings-bytes-tamper | 1 | 1 | HANDOFF_BINDINGS_CONTENT |

| corrected-restored-metadata-anchor | 0 | 0 | SYNTHETIC_ANCHOR_VALIDATED_NOT_OWNER_APPROVAL |

| corrected-restored-local | 0 | 0 | OWNER_EXCEPTION_APPROVAL_PENDING |

| joint-replaced-local | 0 | 0 | OWNER_EXCEPTION_APPROVAL_PENDING |

| joint-trusted-runner | 1 | 1 | POLICY_DIGEST_MISMATCH |

| joint-replaced-original-anchor | 1 | 1 | OWNER_INPUT_BYTES_AND_METADATA |

## Appendix B. Exact40 exception handoff

| Exact path | Original staged SHA256 | Git blob OID | Bytes | Ordinary / cr-at-eol |
| --- | --- | --- | ---: | --- |

| `docs/acceptance/MS7-MIG-V02/full_content-command.txt` | `abb7ca52c7445d7e0225df99cef1a0d0defab765cde53dcb1589fa3291363130` | `d2888eed7b959f80f5fffd38d80a81aa1329dfb8` | 264 | 1 / 0 |

| `docs/acceptance/MS7-MIG-V02/legacy-fresh-smoke-command.txt` | `88a168d66b7a679dcf8fe30eabd32cadf4cc297273f62c3d0c8c615fa986748b` | `fb7041138a28c8341c90f25b78cf4aa5e44cece4` | 3948 | 75 / 0 |

| `docs/acceptance/MS7-MIG-V02/legacy-version-report-command.txt` | `105803c51de34022a77ffdef02852ce75ce1fcfea2cfd7d849e1cfff9a1b1a43` | `a8e70131166c1bcaf9281bb401a2633de41d9134` | 650 | 24 / 0 |

| `docs/acceptance/MS7-MIG-V02/r02-command.txt` | `faa185cf2db3682ccbaa98bccb4951c8eadfa472223a97d871441ed7ddf71409` | `c64a3712327f99e2f87f849fd3d8fa8a14220549` | 11626 | 68 / 0 |

| `docs/acceptance/MS7-MIG-V02/r02a-command.txt` | `dafd961558154ceb3cddfff4f90dd7229aa6ea73d40bbadf280c8174d6ce747a` | `744ccd25be565ed077f1dac1a6b44ea992ab6ce0` | 4494 | 35 / 0 |

| `docs/acceptance/MS7-MIG-V02/r03a-command.txt` | `33d07eed6d2827fa5fc7a2254aa7fdeced40065f2aeea01275d1c34f80c028d1` | `cd634dfb5892747b3c55e96c1dff4c551d84d2bd` | 5089 | 47 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/before-fix-command.txt` | `53ba91c265f8ae56363be8557b588d9b93df1776f8425ad0f35920dfa28c9ad4` | `766cab0914e11a8a6229960ccadaef54a206417d` | 2255 | 26 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/full_content-command.txt` | `abb7ca52c7445d7e0225df99cef1a0d0defab765cde53dcb1589fa3291363130` | `d2888eed7b959f80f5fffd38d80a81aa1329dfb8` | 264 | 1 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/files.md` | `3079f97accfb55c514eb03c7c5eb67ee2f29ade50c7680be1e1dcf2b03fc5115` | `dd51ed47a11db9a5640b5dea5ac329def469aa38` | 5158 | 53 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/frozen-ownership.json` | `1dbba499b2234e94f680cffacfaa0fa36f0f68c573108b82d8d2d1800fd7877d` | `9828ff349f131f8f6250168d7cd7f3a5cd1f8201` | 29591 | 513 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/full_content-command.txt` | `abb7ca52c7445d7e0225df99cef1a0d0defab765cde53dcb1589fa3291363130` | `d2888eed7b959f80f5fffd38d80a81aa1329dfb8` | 264 | 1 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/legacy-fresh-smoke-command.txt` | `88a168d66b7a679dcf8fe30eabd32cadf4cc297273f62c3d0c8c615fa986748b` | `fb7041138a28c8341c90f25b78cf4aa5e44cece4` | 3948 | 75 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/legacy-version-report-command.txt` | `105803c51de34022a77ffdef02852ce75ce1fcfea2cfd7d849e1cfff9a1b1a43` | `a8e70131166c1bcaf9281bb401a2633de41d9134` | 650 | 24 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/old-to-new-evidence.json` | `82913fe097e279f08ebbb1d4b26b9795473b4afe60bac4099a5886c0aa8b67ea` | `2e870bbc0729e68210694ca160fa85a27756f9d8` | 7017 | 143 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/r02-command.txt` | `faa185cf2db3682ccbaa98bccb4951c8eadfa472223a97d871441ed7ddf71409` | `c64a3712327f99e2f87f849fd3d8fa8a14220549` | 11626 | 68 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/r02a-command.txt` | `dafd961558154ceb3cddfff4f90dd7229aa6ea73d40bbadf280c8174d6ce747a` | `744ccd25be565ed077f1dac1a6b44ea992ab6ce0` | 4494 | 35 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/r03a-command.txt` | `33d07eed6d2827fa5fc7a2254aa7fdeced40065f2aeea01275d1c34f80c028d1` | `cd634dfb5892747b3c55e96c1dff4c551d84d2bd` | 5089 | 47 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/routes.json` | `95525391e04f00988a1ecd32eb238a9daecd3931e0093e59efd2630d8233aff6` | `a9b080ca72abc7014ba4dba5435dbc55cca01fe9` | 5011 | 192 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/test-matrix.json` | `fc08da1b76bc37f809b36cae842ff5e033bfab3c815caf7f20d6b7ba456352c3` | `09713b902baa525728817dd417eb90cdf8ad9621` | 18151 | 512 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/v01-command.txt` | `75d29c0df286c2a0b6db843ead8df5edc1bfe27cfb63e5b7dfbc79043b4c9add` | `24dccd1a03d49803d632e39d361cf0aadb2d1cea` | 5291 | 39 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/v02-command.txt` | `eb7b35590d12e4d3324cc205a83043a520f061e27e5a3b67fbbb6f7e57b70334` | `b848a725278d84d38167d0a0471689d53133aa9b` | 7295 | 46 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/verification.json` | `eda3dcabfc4846615d8556359f5e40c4bca842fa5cec9ce72f909e433ce67c3b` | `3f8e533feadb2ebd03cb141c20db638e565d96cc` | 12328 | 335 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/verify-repo-command.txt` | `b350b6ec5e6bfb56e3064f210aa337a95a89a8edd0f714bd3706a8031db57b75` | `7078b6e4504a6c8e984be4b7fbea4f7b789d9408` | 16720 | 194 / 2 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/workspace-manifest.json` | `0a2a37d7141e1b1e4662a4042bb59018995bc20e4b63a1d02b586ee24c266435` | `4b245ac2d8ecccafd0f9a94457a3177bd7be30b6` | 8730 | 195 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/intermediate-v02-84-command.txt` | `3a181050337c571eb7f23f2dcd84d08870d3ec4a9ffdc923ec93fbd5e1665898` | `e294c439242bcc1a4f300542119d8a9fa7330d4e` | 15003 | 89 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/legacy-fresh-smoke-command.txt` | `26d29d15ae943f4795d029fc3aa07abced09f69fc8694c444c7ea9f1a8a266d9` | `9b1f946bad2df57c63532dd4ac694024b0e79e9d` | 3948 | 75 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/legacy-version-report-command.txt` | `105803c51de34022a77ffdef02852ce75ce1fcfea2cfd7d849e1cfff9a1b1a43` | `a8e70131166c1bcaf9281bb401a2633de41d9134` | 650 | 24 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/original-audit/independent-source-snapshot.json` | `19349dca6f3dc9560723a8837766d01a114c6917b158c27a825fafbab0b74a30` | `f66e49eb3ae5785c68046cdfb7a6cf6566f6cc89` | 7827 | 194 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/r02-command.txt` | `83d2c167acd1c0950ce7754376b860b4c2b0738478b25baf21a988ddb1cf20c5` | `0713c503b266cfa0ce8fd5ae7d537ff49f1cb8f4` | 11626 | 68 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/r02a-command.txt` | `52e4bf5e0323651f6765a400cfb90e111c01e6c3f0104b7eb4fde7092d8c4637` | `79dd2149afe772e98386a44654e67d331456c010` | 4494 | 35 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/r03a-command.txt` | `7ef400d692becd196c2d1fdb001c47fab3501f9a7f9bfe72822bcc8f2477a14d` | `522074af58846733dc501cf400ececbe777ae708` | 5089 | 47 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/runtime-command.txt` | `c1db251b97af7cd8313f64f080fb02f0248aebdc8039b34ba7b50f938c06280d` | `019231a9c55e7d1c1bc34949c5da3a5c31c880d3` | 112 | 1 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/runtime-pip-command.txt` | `672aec65a45bed50e70229c70934a7eebf0462595c459b83023027645d57cccf` | `5c7a95a1123daef23ddc6831a08c3a59baedb153` | 31 | 1 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/test-pip-command.txt` | `672aec65a45bed50e70229c70934a7eebf0462595c459b83023027645d57cccf` | `5c7a95a1123daef23ddc6831a08c3a59baedb153` | 31 | 1 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/v01-command.txt` | `80989be4302e5ffb86c9eff7792875262ffe4dc4c0ec73d2a51d926f2de59dac` | `fc731837e344fb740cb087f2973fa89ab72a93bd` | 5291 | 39 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/v02-command.txt` | `08a8a1ab7041a22ca05e3011969ab8146137d711bcd566abef40ce8a9fddb257` | `9c919a96d9eadf26b2168a763e39eb1e52911f6a` | 15415 | 91 / 0 |

| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/verify-repo-command.txt` | `da00309e1d91b592e91f52a20b7be8a9b7b4696d6c59adc91e46c4ecccf24ea2` | `78827649e80bde2b19d72410003ef4d6e6c5162d` | 16720 | 194 / 2 |

| `docs/acceptance/MS7-MIG-V02/v01-command.txt` | `75d29c0df286c2a0b6db843ead8df5edc1bfe27cfb63e5b7dfbc79043b4c9add` | `24dccd1a03d49803d632e39d361cf0aadb2d1cea` | 5291 | 39 / 0 |

| `docs/acceptance/MS7-MIG-V02/v02-command.txt` | `eb7b35590d12e4d3324cc205a83043a520f061e27e5a3b67fbbb6f7e57b70334` | `b848a725278d84d38167d0a0471689d53133aa9b` | 7295 | 46 / 0 |

| `docs/acceptance/MS7-MIG-V02/verify-repo-command.txt` | `b350b6ec5e6bfb56e3064f210aa337a95a89a8edd0f714bd3706a8031db57b75` | `7078b6e4504a6c8e984be4b7fbea4f7b789d9408` | 16720 | 194 / 2 |
