"""Offline exact snapshot restoration into a NEW disposable Git repository only."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess

BASE = '0c03197e23f69a233c0fcf8bdffa336feca20b92'
TREE = 'dbad1e853dff354c5d3255755afb5cc32e0ad279'
APPROVED = 'fa62cf5f4c9b3aaf91864b9face548a5f45759390fb7bedd9cdef5ae6e7c2e18'
ATTR = ('text', 'eol', 'filter', 'working-tree-encoding', 'ident', 'crlf', 'diff', 'whitespace', 'merge', 'binary', 'export-ignore', 'export-subst', 'encoding')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('package', type=Path)
    parser.add_argument('destination', type=Path)
    parser.add_argument('--git', default=shutil.which('git'))
    args = parser.parse_args()
    assert args.git, 'Git is required on PATH or via --git'
    package = args.package.resolve()
    dest = args.destination.resolve()
    assert not dest.exists(), 'Destination already exists: refusing to modify it'
    assert package not in dest.parents, 'Destination must be outside the extracted package'
    inventory = json.loads((package / 'transport/inventory.json').read_bytes())
    assert inventory['base_sha'] == BASE and inventory['expected_tree_oid'] == TREE
    records = inventory['files']
    assert len(records) == 151 and len({r['path'] for r in records}) == 151
    members = json.loads((package / 'package-inventory.json').read_bytes())
    listed = {r['path'] for r in members['members']} | {'package-inventory.json'}
    observed = {f.relative_to(package).as_posix() for f in package.rglob('*') if f.is_file()}
    assert listed == observed, 'Package has missing or unexpected paths'
    for r in members['members']:
        p = PurePosixPath(r['path'])
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in r['path']
        raw = (package / r['path']).read_bytes()
        assert sha(raw) == r['sha256'] and len(raw) == r['size'], 'Package member mismatch: ' + r['path']
    policy = json.loads((package / 'snapshot/docs/acceptance/MS7-MIG-V02/publication-byte-audit/round3/exception-policy.json').read_bytes())
    assert sha((json.dumps(policy['whitespace_exceptions'], sort_keys=True, separators=(',', ':')) + '\n').encode()) == APPROVED
    assert len(policy['whitespace_exceptions']) == 40 and len(policy['preserve_raw_bytes']) == 73
    record_map = {r['path']: r for r in records}
    for r in policy['preserve_raw_bytes']:
        item = record_map[r['path']]
        assert (item['sha256'], item['blob_oid'], item['size']) == (r['blob_sha256'], r['blob_oid'], r['bytes'])
    env = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0', 'LC_ALL': 'C', 'PYTHONDONTWRITEBYTECODE': '1'}
    def git(*argv, data=None, allow=False):
        p = subprocess.run([args.git, '-C', str(dest), *argv], input=data, capture_output=True, env=env)
        if p.returncode and not allow:
            raise RuntimeError(f'{argv}: {p.stderr.decode(errors="replace")}')
        return p if allow else p.stdout
    dest.mkdir(parents=True)
    git('init', '--initial-branch=ms7-mig-v02-content')
    git('config', 'core.autocrlf', 'false')
    git('config', 'core.longpaths', 'true')
    baseline = json.loads((package / 'transport/baseline-inventory.json').read_bytes())
    assert baseline['base_sha'] == BASE
    pack = (package / 'transport/baseline.pack').read_bytes()
    assert sha(pack) == baseline['pack_sha256'] and len(pack) == baseline['pack_bytes']
    git('unpack-objects', '-r', data=pack)
    imported = {line.split()[0].decode() for line in git('cat-file', '--batch-all-objects', '--batch-check').splitlines()}
    assert imported == set(baseline['objects']), 'Baseline pack unexpected object inventory'
    (dest / '.git/shallow').write_bytes((BASE + '\n').encode())
    git('update-ref', 'refs/heads/ms7-mig-v02-content', BASE)
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    assert git('rev-parse', BASE + '^{tree}').decode().strip() == baseline['base_tree_oid']
    git('read-tree', BASE)
    for r in records:
        p = PurePosixPath(r['path'])
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in r['path']
        assert r['mode'] == '100644'
        raw = (package / 'snapshot' / r['path']).read_bytes()
        assert sha(raw) == r['sha256'] and len(raw) == r['size'], 'Blob SHA256 mismatch: ' + r['path']
        assert git('hash-object', '-w', '--stdin', data=raw).decode().strip() == r['blob_oid'], 'Blob OID mismatch: ' + r['path']
    git('update-index', '-z', '--index-info', data=b''.join(f"{r['mode']} {r['blob_oid']}\t{r['path']}\0".encode() for r in records))
    tree = git('write-tree').decode().strip()
    assert tree == TREE, 'STOP: reconstructed Git tree mismatch'
    paths = [r['path'] for r in records]
    payload = ('\0'.join(paths) + '\0').encode()
    for attribute_args, key in [(ATTR, 'attributes'), (('-a',), 'attributes_all')]:
        raw = git('check-attr', '--cached', '-z', '--stdin', *attribute_args, data=payload).split(b'\0')
        attrs = {p: {} for p in paths}
        for i in range(0, len(raw) - 1, 3):
            p, name, val = (v.decode() for v in raw[i:i+3])
            attrs[p][name] = val
        for r in records:
            assert attrs[r['path']] == r[key], 'Effective attributes mismatch: ' + r['path']
    git('checkout-index', '--all', '--force')
    assert not git('diff', '--name-only'), 'Clean checkout has unstaged changes'
    assert not git('ls-files', '--others', '--exclude-standard'), 'Unexpected untracked paths'
    staged = [p.decode() for p in git('diff', '--cached', '--name-only', '-z').split(b'\0') if p]
    assert sorted(staged) == sorted(paths)
    for r in policy['preserve_raw_bytes']:
        assert sha((dest / r['path']).read_bytes()) == r['blob_sha256'], 'Raw checkout mismatch: ' + r['path']
    git('fsck', '--full', '--no-reflogs', '--no-dangling')
    whitespace = []
    for cr in (False, True):
        for scoped in (False, True):
            command = (['-c', 'core.whitespace=cr-at-eol'] if cr else []) + ['diff', '--cached', '--check']
            if scoped:
                command += ['--', '.', *[':(exclude,literal)' + r['path'] for r in policy['whitespace_exceptions']]]
            result = git(*command, allow=True)
            assert result.returncode == (0 if scoped else 2)
            whitespace.append({'cr_at_eol': cr, 'scoped': scoped, 'exit_code': result.returncode, 'stdout_sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr)})
    print(json.dumps({'base_sha': BASE, 'reconstructed_tree_oid': tree, 'expected_tree_match': True, 'indexed_files': 151, 'approved_exception_digest': APPROVED, 'raw73_verified': True, 'all13_and_full_attributes': 'PASS', 'baseline_pack_object_set_exact': True, 'no_source_alternates_used': True, 'git_fsck': 'PASS', 'whitespace': whitespace, 'r03_gate': 'NOT_READY', 'owner_anchor': 'NOT_CREATED'}, indent=2))

if __name__ == '__main__':
    main()
