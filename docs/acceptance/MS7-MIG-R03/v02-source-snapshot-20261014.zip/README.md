# V02 immutable source snapshot for independent R03 comparison

Transport only. R03 gate remains NOT_READY. No implementation commit or owner approval JSON is required for this handoff. Ruslan has approved the exact 40-path exception set; do not request policy reapproval. The external owner anchor will be created in the owner-controlled R03 zone after source comparison. Historical policy/bindings retain their original pending labels and bytes; this README records the current user-provided clarification and is not an anchor.

BASE: 0c03197e23f69a233c0fcf8bdffa336feca20b92
Expected reconstructed tree: dbad1e853dff354c5d325575afb5bcc32e0ad279
Approved exception-set digest: fa62cf5f4c9b3aaf91864b9face548a5f45759390fb7bedd9cdef5ae6e7c2e18

Contents: snapshot/ contains exactly 151 indexed blobs, never Windows checkout copies. transport/inventory.json gives each path, SHA256, Git blob OID, size, mode, 13 attributes and full attributes. inventory.tsv is a compact exact listing. attributes-provenance.json and attributes-sources/ preserve root BASE attributes and staged V02 attributes. raw-73-preservation.json and approved-40-exceptions.json are distinct sets. All v3 verifier/policy/manifest/bindings are inside snapshot at their original paths. Auditor evidence includes original reports, reconciliation, probes and receipts with exact SHA256; historical synthetic fixtures there are evidence only, never gate approval. baseline.pack contains only the exact BASE commit and its trees/blobs, with parent history omitted, for offline reproduction.

Verify ZIP SHA256 against the separately transmitted sidecar before extracting. package-inventory.json lists and hashes all members except itself (explicit exclusion avoids self-hash circularity). On Windows use Expand-Archive into a NEW directory; on Linux use unzip into a NEW directory. No pre-existing task repository should be the restore destination.

Windows (Python 3.12+ and Git on PATH):
  py -3 -I -B C:\handoff\restore_snapshot.py C:\handoff C:\new-isolated-v02
Linux (Python 3.12+ and Git on PATH):
  python3 -I -B /tmp/handoff/restore_snapshot.py /tmp/handoff /tmp/new-isolated-v02

The supplied restore tool rejects an existing destination, imports the exact baseline pack into its own Git object store, marks BASE as a shallow boundary, verifies all 151 blob SHA256/OIDs/modes, fills the index using exact modes/OIDs (NOT git add), checks all effective attributes, builds and compares the tree, and checks out the snapshot. Existing BASE may alternatively be obtained from an already trusted R03 repository; Git ref/commit identity remains BASE. No new implementation commit is created. Do not normalize raw files. Windows clean checkout may transform ordinary text representations; the indexed blobs are authoritative. Git core.autocrlf=false and baseline/local attributes are used. Global/info attribute overrides are checked: any divergence aborts.

After restore run the v3 verifier with --root <new-repository> --local-proposal to check technical conformance only. Running without an external anchor intentionally exits 3. R03 must use its independently controlled verifier/anchor/enforcer for its own gate; the package's verifier is source for comparison, not external authority. No candidate-derived pins have been approved by this packaging operation.

Whitespace: unscoped ordinary FAIL/2 (3887 diagnostics); unscoped cr-at-eol FAIL/2 (6 diagnostics). Exactly 40 approved literal path exclusions yield scoped ordinary PASS/0 and scoped cr-at-eol PASS/0. The complete actual stdout/stderr, argv and exit codes are in transport/whitespace/. This exception policy does not convert the full checks into PASS. The raw-preservation set is exactly 73 paths; 33 raw paths are not whitespace exceptions.

Transport verification covers byte/metadata fidelity, tree identity, independent extraction, bounded secret signatures and source immutability. Runtime/DB/frontend/root CI tests are not rerun by this source-only packaging task. Clean Windows restore is executed; Linux restore instructions are supplied, with no claim of an actual Linux run.

Transmit the ZIP and its SHA256 sidecar to Ruslan/R03. Have R03 independently recompute archive SHA256, extract, run restore_snapshot.py in a clean isolated Windows or Linux location and compare inventories/tree with the owner-controlled baseline. Then create the external R03 anchor in its zone. READY TO TRANSFER is only transport readiness, never R03 gate acceptance.
