# MS7-MIG-V02 — Final Independent F01/F02 Re-Audit

13.10.2026, Europe/Moscow. Независимый STRICT READ-ONLY re-audit. Результаты относятся к конкретным текущим байтам, а не к implementation commit. Human Task Approval Руслана не выдаётся.

## 1. Exact reviewed source snapshot

Branch `ms7-mig-v02-content`. HEAD/V02_BASE_SHA/merge-base с `origin/ms7-mig-react-fastapi`: `0c03197e23f69a233c0fcf8bdffa336feca20b92`. Merge-base с immutable MIG_BASE_SHA: `60b341fbd00f4c8dadd54ae9a3e5811869a9b0f7`. Implementation SHA отсутствует; tested_implementation_sha=null.

SHA256 текущего `docs/acceptance/MS7-MIG-V02/workspace-manifest.json`: **aa6fff39637b1b775e2034c844428881756c0bb8077e05d62f09da7e50e01d0b**. Все указанные122 file hashes/sizes независимо совпали с checkout bytes. Полный независимый список123 файлов и хешей сохранён рядом: `reaudit-source-snapshot.json`. После проверок source hashes/file set остались неизменными, tracked/staged diff пуст.

## 2. Current file/manifest reconciliation

Исходный snapshot:47 файлов,46 manifest entries плюс сам manifest. Текущий:123 файла,122 entries плюс manifest. Добавлены76 файлов:47 byte-preserved originals в `remediation-f01-f02/history/initial/`,2 copies original independent audit/snapshot,1 новый regression module и26 remediation patch/report/intake/verification/test/log records. Их точные имена/размеры находятся в независимом snapshot JSON.

13 текущих original47 файлов изменены: releases.py, app.py, legacy_comparator.py; acceptance-draft, files, frozen-ownership, old-to-new-evidence, report, test-matrix, verification, workspace-manifest; task trace и plan.34 оставшихся совпадают, включая три original41 test modules. Архивные47 совпадают полностью, включая старый manifest. Утверждение byte-identical корректно для архива, не для исправленного текущего кода.

Общий untracked объём895041 bytes; largest file42539 bytes. В наборе нет DB/SQLite/pyc/.env/cache/venv/node_modules; ownership violations отсутствуют. Логи и патчи — ограниченные audit evidence, не случайный environment dump. Реальных secrets в проверенных новых материалах не обнаружено; synthetic credentials в fixtures/commands явно тестовые.

## 3. Original F01 reproduction

В отдельной `C:\Temp\mathstart-v02-negative-20261013` восстановлены original backend files из архива с независимой проверкой original hashes. Собственный probe на новой UUID PostgreSQL16 базе повторил shared CSS order0->1: HTTP `/api/v1/content/pages/topic/` **503**. Это expected negative reproduction, не PASS старой реализации. Рабочий код не изменялся.

## 4. F01 patch analysis

Runtime diff ограничен сравнением union identity. В releases.py исключается только `order`; storage_key/url/kind/sha256/lifecycle сравниваются, дополнительно сравниваются загруженные bytes. Per-page sorted/unique order, schema/digests/containment/private-path/kind allowlists сохранены. Original page arrays не переписываются. Один first-seen union entry на public URL остаётся.

First-seen descriptor хранит order первой страницы; этот order не используется asset HTTP serving. Перестановка index pages может изменить этот внутренний page-local marker и dictionary iteration order, но не глобальную identity/bytes, отсутствие дублей или page-local выдачу. Собственный probe проверил normalized union equality и неизменные page arrays после перестановки index pages. Для фиксированных index bytes load детерминирован; публичной недетерминированности не выявлено.

## 5. F01 independent tests

Собственные PG/ASGI probes подтверждают: shared CSS different page order200; несколько CSS/JS в разных page sequences200 с exact arrays; unique union из3 URLs; exact asset bytes SHA256; обычный unchanged shared asset200. Different valid digest, different storage с одинаковыми bytes, incompatible kind, valid script lifecycle conflict и damaged asset дают503. Нормализованная union identity сохраняется при обратном порядке страниц. SQL capture во время каждого probe request допускает только SELECT/SET TRANSACTION READ ONLY.

## 6. Original F02 reproduction

Тот же отдельно восстановленный original backend, другая новая UUID DB: missing `/static/old.css` с permanent active redirect даёт **404 без Location**. Это независимо воспроизвело исходный дефект; existing current snapshot не изменялся.

## 7. F02 patch analysis

app.py вводит общий `public_redirect_or_missing` для eligible public404. Missing static/media и missing page используют уже выбранный release. Existing assets/pages имеют приоритет. Page resolver errors проходят fallback только при status404;401/403/405/409/503 не преобразуются. Manifest/asset integrity failure возникает до fallback. Private/traversal проверки сохранены; raw invalid UTF-8 отсекается до возможного replacement-character match. Location quote сохраняет percent escapes и соответствует Django iri_to_uri в проверенных cases.

## 8. F02 independent tests

Собственные requests: missing static permanent301/temporary302; missing media302; GET/HEAD одинаковые status/Location; working asset200 и POST405 даже при conflicting redirect; no-rule404; unsafe target503; missing descriptor503; corrupt asset503 без Location; encoded traversal/backslash/invalid UTF-8/invalid percent/private paths404. Unicode old URL и Unicode/percent target дают ожидаемый encoded Location.

Inactive redirect исключается producer projection и не существует в active registry: это проверено substantive новым тестом с реальной inactive DB row. Собственная отдельная Django parity проверка inactive row дала404; собственный target no-rule404 подтвердил active-registry поведение. V02 не использует live DB Redirect как fallback к отсутствующему active rule.

## 9. Django parity findings

Собственный `independent_django_parity.py` выполнил8 сценариев с реальными WhiteNoiseMiddleware, django.views.static.serve, Redirect ORM и RedirectFallbackMiddleware: static301, temporary HEAD302, media302, existing static200, existing static POST405, inactive404, Unicode source с preserved percent target301, Unicode target HEAD302. Status/Location совпали с собственными target expectations. Все DB rule mutations были внутри rollback-only transactions на базе, созданной данным аудитом. WhiteNoise предупредил об отсутствующем default staticfiles каталоге; synthetic files явно добавлены через add_files, сценарии выполнены без skips.

Дополнительно developer PG comparator с8 native/target pairs был независимо повторно выполнен в составе86 suite. Он использует real handlers/ORM, не mock oracle.

## 10. Content/Grades/HTTP/staff regressions

Повторный public_baseline_projection:279 published pages/263 topics; exact source mapping/hashes, SEO и Django topic ordering совпали, SQL read-only. Полный HTML/assets/browser lifecycle этим тестом не доказан.

Original41 теста повторно прошли: published-only/no latest-DB leakage, coherent release selection, cursor real PK/number/created_at-id/default20-max100/signing/keyring/no expiry/tampering/races, query bounds, no-DML, permissions before lookup, anonymous/inactive401, ordinary/insufficient staff403, untrusted role headers, closed DTO/password secrecy, safe exceptions/statuses, no307/422.

Собственные all-route calls вызвали32 actual registered GET operations:31 ожидаемый200 на synthetic authorized principal и503 publication_state без V04 provider. Runtime32 registry сохранён. GET body ignoring и raw JSON helper semantics не изменены. Безопасный missing-DB probe вернул503 SERVICE_UNAVAILABLE без DSN/port disclosure; dialect остался PostgreSQL.

## 11. PostgreSQL verification

Dedicated local disposable PostgreSQL16.15 container `ms7-mig-v02-pg-alt-20261012`, host15441/internal55441. Каждый fixture/probe использует новый marked UUID DB; V01 guard не изменялся. Собственные probes удалили только созданные ими UUID DB. Smoke создал отдельную retained `ms6_v01_smoke_v02_7908aa91011d4f19a93bcfe23f479149` для просмотра. Рабочие/production базы не использованы.

V01 проверен на отдельной копии внутри Linux test container в PG network namespace (55441). UoW/repositories/schema/Alembic неизменны. READ ONLY/default rollback-close и отсутствие GET writes подтверждены. Реальная target runtime factory успешно запущена без установленного/импортированного Django;32 operations. Runtime pip check выполнен внешним pip --python; зависимости согласованы. Прямой runtime `-m pip` недоступен, что не заменяет успешно выполненную внешнюю проверку.

## 12. Full independent test matrix

| Suite/check | Actual result |
| --- | --- |
| V02 original modules + test_asset_regressions | PASS86, FAIL0, SKIP0;9 unit,37 SQLite,40 PG |
| New remediation module |45 collected/executed:22 SQLite,23 PG |
| V01 test_unit/test_postgres/test_remediation |PASS34, FAIL0, SKIP0;23 PG |
| R02 test_migration_r02_*.py |PASS63 |
| R02A test_r02a_contract.py |PASS30 |
| R03A test_r03a_contract.py |PASS41 |
| Fresh disposable PG smoke |PASS |
| verify_repo |PASS8/8;Django109,R0318,Harness73 |
| Content parity |PASS279/263 |
| Independent positive PG/ASGI probes |37 asserted HTTP requests, plus union/order/digest assertions |
| Independent old snapshot |2 expected bad HTTP outcomes reproduced:503/404 |
| Independent native Django parity |8 asserted scenarios |
| Independent all32 calls |31 expected200,1 expected503 |
| Missing-DB safe HTTP failure |Expected503, no fallback/disclosure |
| Test/runtime dependency checks |PASS both |
| Normal runtime without Django |PASS |
| Ruff/mypy/formatter |NOT RUN: not configured |

Exact Windows interpreter `C:\Projects\MathStart-Python-V02\var\ms7-mig-v02-venv\Scripts\python.exe` (P below), Python3.12.10. Linux Python3.12.15; PG16.15; Docker client/server29.8.0; Compose5.5.1; FastAPI0.115.12, SQLAlchemy2.0.46, Django5.2.16, httpx0.28.1, psycopg3.3.6.

Commands on `C:\Temp\mathstart-v02-reaudit-20261013`:

```text
P -m unittest backend.tests.v02.test_unit backend.tests.v02.test_http backend.tests.v02.test_postgres backend.tests.v02.test_asset_regressions -v
P -m unittest discover -s tests -p test_migration_r02_*.py
P -m backend.tests.v02.baseline
P -m backend.tests.v02.public_baseline_projection
P independent_reaudit_probes.py
P independent_django_parity.py
P all_routes_probe.py
P missing_db_probe.py
P -m pip check
P -m pip --python C:\Projects\MathStart-Python-V02\var\ms7-mig-v02-runtime-venv\Scripts\python.exe check
```

baseline independently runs scripts/fresh_install_smoke.py --disposable, scripts/verify_repo.py, scripts/version_report.py and unittest discover for test_r02a_contract.py/test_r03a_contract.py. Explicit synthetic PG admin/secret/runtime environment supplied; no working .env copied. V01 command: `python -m unittest backend.tests.test_unit backend.tests.test_postgres backend.tests.test_remediation -v` in `/tmp/independent-v02-reaudit-20261013`, with MATHSTART_V01_TEST_ADMIN_URL on reserved55441. Original repro: `P independent_reaudit_probes.py --old` in separate negative copy.

Logs/probe sources/native observations retained outside repository in `reaudit-evidence/` beside this report (23 files). Test collection independently confirmed9+15+17+45=86; actual log has86 ok lines,40 PostgreSQL ok lines,0 skipped lines. New tests do substantive HTTP/data/hash/status/Location assertions. Only resolver failure409/503 injection uses mocks to verify error precedence; no catch-all suppressions or conditional per-case skips. PG class requires reserved endpoint/version16; the actual class executed23 methods.

## 13. Frozen/ownership checks

60 frozen HEAD blobs/checkouts compared with V02_BASE_SHA: unchanged. V01 migrations/Alembic/frontend/root CI/historical tracked files unchanged. All123 untracked files stay in V02 owned paths/records. Original41 test source files unchanged. Final git status categories exactly match initial categories; no source/file-set drift. No repository files/code/tests/evidence were written by this re-audit.

## 14. Evidence/provenance quality

Original independent report and snapshot copies exactly match original files; report SHA256 `1feaa929b56e5485534fbc606184c8be9953199c1d558782a8fe6717549ddbd2`, snapshot SHA256 `19349dca6f3dc9560723a8837766d01a114c6917b158c27a825fafbab0b74a30`. Original verdict remains CHANGES REQUIRED. All47 archived sources match original independent inventory. Current §17 records array equals original exactly; remediation is appended separately. All15 retained command-log hashes match current remediation verification record. Logs/hash consistency was not accepted as execution proof: suites/probes were independently rerun.

Normative PDF originals now located/read in Downloads: v7.1 SECTION20 SHA256 `e477bf8c351c6b9453448080ed2e7283ad2b40cca82931906a5650d757d70acd`,114/114 readable pages; migration v1.1 SHA256 `a0c72fda223f86622d01665eaa7ec9d854c7b0b3014de38174f9ad4c582eb66e`,60/60 readable pages. Hashes match required inputs. Earlier audit's PDF-availability limitation remains its preserved historical observation, resolved for this re-audit.

Positive result binds manifest hash and independent123-file snapshot above. V02_BASE_SHA remains input provenance; no future implementation SHA invented. tested_implementation_sha=null; publication/CI/human approval pending. Future V03/V04/I02 integrations remain explicitly NOT VERIFIED.

## 15. Remaining findings

**F01: CLOSED. F02: CLOSED. Blocking findings:0.** No remaining confirmed P1/P2/P3 defect in reviewed V02 scope. Original locations are fixed in current releases.py identity block and app.py common eligible404 fallback; historical line numbers are retained in original negative report.

## 16. NOT VERIFIED

Real V03 sessions/CSRF/rotation/revocation; V04 production reviewed metadata/source inventory/activation/recovery; full I02/I03/V05 renderer/browser/SSG/all asset lifecycles/gateway; performance/deployment; future published commit blobs/candidate CI; live external GitHub approvals/receipts; human Task Approval. Safe missing integration ports do not fabricate production success and are not independent blockers for publishing the scoped adapters.

## 17. Recommendation

**READY FOR PUBLICATION** — technical recommendation for the exact uncommitted snapshot identified in section1. Both prior blocking P2 findings independently closed; required scoped regressions passed. This is not acceptance of a deployed/full integrated platform and is not Human Task Approval Руслана. Publication must produce a real commit SHA, independently bound Git-blob evidence/CI, and follow the required human gate. No commit/push/merge/rebase/reset/clean/PR/review action performed.
