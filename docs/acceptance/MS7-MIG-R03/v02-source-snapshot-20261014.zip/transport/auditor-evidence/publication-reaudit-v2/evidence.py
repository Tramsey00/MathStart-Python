from pathlib import Path
exec(Path(__file__).with_name('audit.py').read_text().split('before=state();')[0])
import importlib.util
spec=importlib.util.spec_from_file_location('checker',ROOT/V); checker=importlib.util.module_from_spec(spec); spec.loader.exec_module(checker)
view=checker.GitView(ROOT); paths=view.paths(); view.load_blobs(paths)
attrs=view.attributes(paths); workattrs=view.attributes(paths,working=True)
manifest=j(view.blob(M)); policy=j(view.blob(POL)); ent=view.entries
for p in paths:
    b=view.blob(p); assert attrs[p]==workattrs[p]
    assert ent[p]['mode']=='100644'
    if p!=M:
        x=manifest['files'][p]; assert (ent[p]['oid'],sha(b),len(b),ent[p]['mode'],attrs[p])==(x['blob_oid'],x['blob_sha256'],x['blob_bytes'],x['mode'],x['attributes']),p
    assert checker.canonical_work((ROOT/p).read_bytes(),attrs[p])==b
checks={}
exceptions=[x['path'] for x in policy['whitespace_exceptions']]
for name,cr,exclusions in [('ordinary',False,()),('cr-at-eol',True,()),('scoped-ordinary',False,exceptions),('scoped-cr-at-eol',True,exceptions)]:
    args=['git','-c','color.ui=false']
    if cr: args+=['-c','core.whitespace=cr-at-eol']
    args+=['diff','--cached','--check']
    if exclusions: args+=['--','.',*[':(exclude,literal)'+p for p in exclusions]]
    r=run(ROOT,args); (OUT/(name+'-diagnostics.txt')).write_bytes(r.stdout)
    checks[name]=checker.diagnostic_check(view,cr,exclusions); assert checks[name]['exit_code']==r.returncode
checker.validate_diagnostics(policy,checks['ordinary'],checks['cr-at-eol'])
assert set(checks['ordinary']['by_path'])==set(exceptions)
justifications=[]
for x in policy['whitespace_exceptions']:
    p=x['path']; b=view.blob(p); lines=b.split(b'\n'); diags=checks['ordinary']['by_path'][p]
    assert all(lines[d['line']-1].endswith(b'\r') and not lines[d['line']-1].rstrip(b'\r').endswith((b' ',b'\t')) for d in diags)
    assert (sha(b),ent[p]['oid'],len(b))==(x['blob_sha256'],x['blob_oid'],x['bytes'])
    justifications.append({**{k:v for k,v in x.items() if k not in ('ordinary','cr_at_eol')},'ordinary':diags,'cr_at_eol':checks['cr-at-eol']['by_path'].get(p,[]),'attributes':attrs[p]})
imports=j(view.blob(P+'source-imports.json'))['sources']; snap=j(base64.b64decode(imports['positive_runtime_snapshot']['bytes_base64']))
active=[p for p in paths if p.startswith('backend/')]; assert len(active)==28
ident=[]
for p in active:
    x=snap['files'][p]; b=(ROOT/p).read_bytes(); assert sha(b)==x['sha256']; assert view.blob(p)==b
    ident.append({'path':p,'sha256':sha(b),'bytes':len(b),'snapshot':x})
original=j(view.blob('docs/acceptance/MS7-MIG-V02/remediation-f01-f02/original-audit/independent-source-snapshot.json'))
archives=[]
for p,x in original['files'].items():
    a='docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/'+p; b=view.blob(a)
    assert sha(b)==x['sha256'] and (ROOT/a).read_bytes()==b
    archives.append({'path':a,'sha256':sha(b),'bytes':len(b)})
frozen=j(view.blob('docs/acceptance/MS7-MIG-V02/frozen-ownership.json'))['checked_frozen_files']; view.load_blobs([x['path'] for x in frozen])
for x in frozen:
    p=x['path']; b=view.blob(p); assert sha(b)==x['input_blob_sha256']==x['head_blob_sha256']==sha(git(ROOT,'show',BASE+':'+p))
    assert sha((ROOT/p).read_bytes())==x['checkout_sha256']
sig={}; bad_names=[]
for p in paths:
    if re.search(r'(?i)(\.sqlite3?$|\.pyc$|(^|/)(venv|\.venv|node_modules|__pycache__|\.env|cache)(/|$))',p): bad_names.append(p)
    for name,pattern in [('private_key',rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----'),('github_token',rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b'),('aws_key',rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b'),('slack',rb'\bxox[baprs]-[A-Za-z0-9-]{20,}\b')]:
        if re.search(pattern,view.blob(p)): sig.setdefault(p,[]).append(name)
dump('independent-evidence.json',{'checks':checks,'exceptions':justifications,'attributes':attrs,'backend28':ident,'archive47':archives,'frozen60':frozen,
    'manifest_self':{'oid':ent[M]['oid'],'sha256':sha(view.blob(M)),'bytes':len(view.blob(M)),'mode':ent[M]['mode'],'attributes':attrs[M]},
    'secret_signature_findings':sig,'bad_filenames':bad_names,'limitations':'signature inspection only; dedicated scanner not run'})
print('Independent blob/mode/attribute, 40 diagnostic justifications, 28 runtime,47 archive,60 frozen checks PASS')
print('Whitespace',[(k,v['exit_code'],v['count'],len(v['by_path'])) for k,v in checks.items()])
