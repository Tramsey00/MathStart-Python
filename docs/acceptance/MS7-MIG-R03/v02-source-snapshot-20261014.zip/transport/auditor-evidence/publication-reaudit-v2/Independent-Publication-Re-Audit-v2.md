# MS7-MIG-V02 — Final Independent Publication Re-Audit v2

13.10.2026, Europe/Moscow. Issue #35. STRICT READ-ONLY аудит исходного worktree/index. Все собственные изменения сделаны только в отдельном audit directory. Human Task Approval Руслана не выдаётся.

**Final verdict: CHANGES REQUIRED.** Подтверждены воспроизводимость clean checkout, прежние bytes и точное сужение whitespace exceptions. Обнаружен один новый блокирующий P2: verifier не проверяет Git mode и ожидаемые effective attributes собственного manifest. Byte-only external anchor также не устраняет этот дефект.

## 1. Actual branch, HEAD и Git index

- Branch: `ms7-mig-v02-content`.
- HEAD / V02_BASE_SHA / merge-base с `origin/ms7-mig-react-fastapi`: `0c03197e23f69a233c0fcf8bdffa336feca20b92`.
- Immutable MIG_BASE_SHA и merge-base с ним: `60b341fbd00f4c8dadd54ae9a3e5811869a9b0f7`.
- 139 staged additions; 0 unstaged; 0 untracked; 0 изменений/удалений baseline paths.
- Implementation commit отсутствует. `tested_implementation_sha=null`, `publication_status=PENDING_PUBLICATION` подтверждены по staged manifest.
- Инструменты: Windows, Python 3.12.10, Git 2.47.0.windows.1. Зависимости не устанавливались; production/working DB не использовались.

Исходный index является index отдельного Git worktree; реальный git-dir определён через `rev-parse --absolute-git-dir`. На source использовался `GIT_OPTIONAL_LOCKS=0`, Python — `-B`/`PYTHONDONTWRITEBYTECODE=1`. Source index SHA256 до/после: `2c728b3b3c374213a23834f6aadfce8d51b0c504d1201b3f3cf9775af81c01c4`.

## 2. Exact staged file reconciliation

139 = прежние 128 + 11 новых append-only файлов Round2. Все 128 независимо совпали по working SHA256, blob SHA256, OID и size с **внешним previous independent128_records**, а также с Round2 intake. Нулевой diff baseline исключает изменения V01/Alembic/frontend/root CI. Все 11 новых путей находятся в task-owned V02 acceptance subtree; это verifier, tests и evidence/handoff records.

Manifest содержит 138 records плюс исключённый из собственного хеширования manifest: 139 paths, missing/extra=0. Связка bytes/OID/size/mode/attributes для 138 records корректна в текущем index. Никакая historical manifest не переписана: они входят в неизменённые 128 и/или exact initial47 archive.

Полный 139-path inventory, hashes/OIDs/sizes/modes и точные 11 additions: [reconciliation.json](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/reconciliation.json>). Внешнее сравнение 128: [external128-comparison.json](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/external128-comparison.json>).

## 3. P01 — independent finding

**P01: NOT CLOSED end-to-end. Local mutable-policy bypass устранён; independent enforcement ещё PENDING.** Неизменённый staged v2 verifier закрепляет SHA256 policy `09fff1895df489f707000f4a1fec8f6ddd62d1666d2b1c44c94b16ca8ae1741f` в строке 17. Policy и verifier находятся внутри `docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/` и остаются изменяемыми task inputs.

Изменение entry, добавление mutable report/new allowed path, удаление entry и замена entry SHA256 возвращают exit1 `POLICY_DIGEST_MISMATCH`, в том числе после корректного пересчёта соседнего manifest. Новые exceptions автоматически не принимаются неизменённым verifier. Exact path set/count и original128 pins также действуют.

Собственный joint probe изменил policy metadata, заменил digest в verifier и пересчитал оба manifest records. Получен **exit0 local proposal conformance**. Это воспроизведение отсутствия independent local trust boundary; исторические bytes и diagnostics при этом не менялись. Внешний before-execution pin проверенного verifier отклонил заменённый executable digest в отдельной симуляции. Симуляция не доказывает наличие deployed R03 gate. Обычный запуск без anchor возвращает exit3; local proposal exit0 не является approval.

Внешний gate должен получать independently reviewed verifier digest/code, policy digest, final manifest digest, отдельный trusted anchor digest и контролируемый execution context. Их нельзя брать из candidate JSON/report или заново вычислять и объявлять approved самим task. Pending B не скрывается закрытием локальных negatives.

## 4. P02 — independent finding

**P02: CLOSED для исходного clean-checkout portability failure.** Все три реальных checkout проходят unchanged verifier в `--local-proposal` и `--ref TREE` режимах. Исходные Windows working hashes не обязательны; 20 text files меняют только CRLF/LF representation. Raw73 остаются точными bytes, Git index entries неизменны.

Отдельный новый P2 metadata finding в §15 остаётся открытым. Закрытие исходного P02 не означает, что все заявленные mode/attribute guarantees verifier выполнены.

## 5. P03 — independent finding

**P03: CLOSED.** Предыдущий allowlist содержит ровно 73 уникальных пути; новый whitespace allowlist — ровно 40, subset старого. Независимые ordinary diagnostics имеют именно эти 40 paths. Все 33 удалённых из whitespace exemption paths имеют ноль diagnostics; scoped ordinary и cr-at-eol checks вне 40 проходят exit0. Их raw/hash protection сохранена.

73 raw preservation paths = 47 initial archive files + 2 original negative-audit copies + 24 captured command logs. В 40 exceptions входят 17 archived records и 23 raw command logs; active implementation/test files и current mutable reports/manifests не exempt. Archived implementation/test files остаются raw-preserved, но исключены из whitespace waiver при отсутствии diagnostics.

Точный old73/new40/removed33 опубликован в [reconciliation.json](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/reconciliation.json>) и приложениях. Whitespace exceptions используют exact paths, Git pathspec `:(exclude,literal)`; wildcard/path-prefix exclusions отсутствуют. Wildcards в `.gitattributes` регулируют byte preservation архивов/логов и не расширяют whitespace exception list.

## 6. Clean-checkout verification

Созданы три независимых Git roots вне исходного worktree. Index скопирован; Git objects доступны через read-only alternates, новые objects/trees пишутся только в scratch object stores. Выполнен настоящий `git checkout-index --all --force`; commits не создавались. Windows long paths в scratch включены через `core.longpaths=true` из-за длинных repository paths. Initial scratch setup исправлен после CRLF в alternates file и длинных Windows путей; это ошибки настройки audit harness, не результаты candidate checks. Финальные результаты ниже получены после исправления harness.

| core.autocrlf | local proposal | Git tree | --ref tree | raw73 | text EOL-only changes |
| --- | --- | --- | --- | --- | --- |
| false | PASS/0 | `26dfd614f3babc918c7ce5c00c54db55fa983dfd` | PASS/0 | exact | 20 |
| true | PASS/0 | `26dfd614f3babc918c7ce5c00c54db55fa983dfd` | PASS/0 | exact | 20 |
| input | PASS/0 | `26dfd614f3babc918c7ce5c00c54db55fa983dfd` | PASS/0 | exact | 20 |

Во всех трёх roots Git tree representation одинаков; все index OID/mode/stage entries равны исходным. Raw73 bytes, SHA256 и sizes сохранены. Нормализуемые files имеют Git blob LF; дополнительный самостоятельный рабочий LF→CRLF probe на normal report проходит exit0 без изменения blobs. `eol=lf` задаёт LF и при autocrlf=true; отсутствие различий между тремя roots здесь ожидаемо. Explicit working normalization проверена отдельно.

Verifier не обращается к developer absolute path и не требует runtime/venv/DB/внешних original source files; абсолютные source paths в imports служат provenance. Другая ОС не запускалась. Полные checkout receipts: [checkouts.json](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/checkouts.json>).

## 7. Git blob/hash/mode/attributes verification

Независимо проверены все 139 текущих modes (100644), каждый blob SHA256/size/OID и effective cached/working attributes. Manifest records совпадают для 138 файлов. Normal paths: `text=auto,eol=lf,diff=unspecified,whitespace=unspecified`; raw73: `text=unset,eol=lf`, suppression отсутствует. Root и V02-local `.gitattributes` сохранены; baseline/root file mutations отсутствуют.

Raw archive byte, normal blob, unexpected staged path, missing staged/working path, normal file mode и изменённый staged attributes file отклоняются. Новый whitespace defect после manifest rebind также отклоняется по unknown diagnostics. Для **manifest self metadata** verifier фактически не обеспечивает такой же контроль: см. §15. Текущая корректность index metadata не заменяет failing negative test.

Самохеширование manifest обоснованно исключено во избежание цикла. Its working bytes сравниваются с canonical blob; independently pinned final manifest digest должен связывать его содержание. Но исключение self hash не требует исключать проверку mode и approved attributes. Byte SHA256/OID не включает Git tree mode и effective attributes.

## 8. 40-path exception justification

Каждая из 40 записей сверена по OID/SHA256/size и raw bytes. Все ordinary offending lines содержат CR suffix; перед ним нет trailing space/tab. Поэтому обычный check отмечает сохранённые исторические CRLF, а residual cr-at-eol шесть diagnostics вызваны CRCRLF. Их три пути — initial archived verify-repo-command.txt, remediation verify-repo-command.txt и current verify-repo-command.txt; строки 68 и 79 в каждом.

Сохранение raw bytes необходимо для provenance исходных command streams и archived evidence snapshots. Нормализация изменила бы независимо сохранённые hashes. Mutable current reports/new Round2 records не требуют waiver. Каждая причина, line/reason mapping и attributes сохранены в [independent-evidence.json](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/independent-evidence.json>); Appendix A содержит полный 40-path hash/OID inventory. Исторические manifests/reports под initial archive — immutable historical copies, а не mutable current reports.

## 9. Whitespace checks и реальные exit codes

| Независимый полный/scoped check | Результат | Diagnostics | Paths |
| --- | --- | ---: | ---: |
| ordinary | FAIL/2 | 3887 | 40 |
| cr-at-eol | FAIL/2 | 6 | 3 |
| scoped-ordinary | PASS/0 | 0 | 0 |
| scoped-cr-at-eol | PASS/0 | 0 | 0 |

Ordinary stream SHA256 `c1b69b199ac5cd41c665d656a72587d36ff0d13dc04a82c0a4c3d75086da20fb`; cr-at-eol `5837278beb0d2ef638db564512c6913f9ae02346d204ba7b75c059aaef373f63`. Они совпадают с предыдущим независимым аудитом; итоговые streams и exact arrays сохранены без фильтрации. **Full git diff --check: FAIL.** Exception approval пока отсутствует; scoped PASS и local verifier exit0 не переименовывают full FAIL.

Outputs: [ordinary-diagnostics.txt](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/ordinary-diagnostics.txt>), [cr-at-eol-diagnostics.txt](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/cr-at-eol-diagnostics.txt>), [independent-evidence.json](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/independent-evidence.json>).

## 10. Independent negative probes

Все mutations сделаны в scratch root. Scratch index менялся только через `hash-object -w`/`update-index`; source index не менялся. Исторический v1 verifier не запускался: он пишет scratch под source var, и не является текущим gate. Staged v2 unit suite отдельно повторена: 15 tests, exit0, 0 skips; это дополнительная проверка, независимые Git probes ниже шире неё.

| Собственная проверка | Ожидаемый exit | Фактический exit | Наблюдение |
| --- | ---: | ---: | --- |
| allowlist entry change + manifest rebind | 1 | **1** | POLICY_DIGEST_MISMATCH |
| add mutable report exception | 1 | **1** | POLICY_DIGEST_MISMATCH |
| remove required allowlist path | 1 | **1** | POLICY_DIGEST_MISMATCH |
| replace pinned entry SHA256 | 1 | **1** | POLICY_DIGEST_MISMATCH |
| add new allowed path | 1 | **1** | POLICY_DIGEST_MISMATCH |
| normal blob byte mutation | 1 | **1** | BLOB_OID: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/owner-handoff.md |
| normal blob mutation with manifest rebind | 0 | **0** | OWNER_EXCEPTION_APPROVAL_PENDING; reviewed manifest внешне ещё не pinned |
| raw working byte mutation | 1 | **1** | WORK_BLOB_CONTENT: docs/acceptance/MS7-MIG-V02/full_content-command.txt |
| raw blob byte mutation + manifest rebind | 1 | **1** | ORIGINAL128_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/full_content-command.txt |
| unexpected staged file | 1 | **1** | PUBLICATION_PATH_SET |
| missing staged file | 1 | **1** | PUBLICATION_PATH_SET |
| missing working file | 1 | **1** | MISSING_OR_SYMLINK_WORK_PATH: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/owner-handoff.md |
| normal mode 100755 | 1 | **1** | FILE_MODE: docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/owner-handoff.md |
| manifest self mode 100755 | 1 | **0** | OWNER_EXCEPTION_APPROVAL_PENDING |
| changed local attributes | 1 | **1** | BLOB_OID: docs/acceptance/MS7-MIG-V02/.gitattributes |
| whitespace defect outside allowlist + manifest rebind | 1 | **1** | UNKNOWN_OR_CHANGED_WHITESPACE_DIAGNOSTICS: ordinary |
| extra CRCRLF diagnostic + manifest rebind | 1 | **1** | ORIGINAL128_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/full_content-command.txt |
| default gate without external trust anchor | 3 | **3** | OWNER_EXCEPTION_APPROVAL_PENDING |
| normal working CRLF equivalence | 0 | **0** | OWNER_EXCEPTION_APPROVAL_PENDING |
| joint verifier + policy + manifest replacement | 0 | **0** | OWNER_EXCEPTION_APPROVAL_PENDING; отсутствие local independent trust boundary ожидаемо |
| independent before-execution verifier pin rejects joint tamper | digest mismatch | digest mismatch | Только внешняя before-execution pin simulation |
| raw ARCHIVE working byte mutation | 1 | **1** | WORK_BLOB_CONTENT: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/content/grades.py |
| raw ARCHIVE staged byte mutation + manifest rebind | 1 | **1** | ORIGINAL128_BLOB_MUTATION: docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/content/grades.py |
| manifest self mode 100755 WITH unchanged independent byte anchor | 1 | **0** | OWNER_EXCEPTION_APPROVED_BY_EXTERNAL_ANCHOR; unexpected acceptance |
| manifest self mode 100755 TREE --ref | 1 | **0** | OWNER_EXCEPTION_APPROVAL_PENDING; unexpected acceptance |
| manifest self effective attributes -text | 1 | **0** | OWNER_EXCEPTION_APPROVAL_PENDING; unexpected acceptance |
| manifest self -text WITH unchanged independent byte anchor | 1 | **0** | OWNER_EXCEPTION_APPROVED_BY_EXTERNAL_ANCHOR; unexpected acceptance |

Joint replacement expected exit0 показывает границу локальной защиты; без independently pinned executable задача может переписать сам checker. Normal new Round2 report+manifest rebinding также локально допустим до external manifest approval. Эти результаты не выдаются за protection PASS. Self metadata negatives, напротив, должны FAIL даже при исходных reviewed byte pins и проходят — новый defect.

Синтетический JSON содержит `owner=Ruslan,decision=APPROVED` **только как attack-test fixture** и явный маркер NOT ACTUAL OWNER APPROVAL. Его digest/runner закреплены audit harness; это не запись решения Руслана и не deployed anchor. Fixture используется только внутри отдельной копии. Полные результаты: [probes.json](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/probes.json>), [extra-probes.json](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/extra-probes.json>), [unit-tests.txt](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/unit-tests.txt>).

## 11. External trust-anchor requirements — A / B / C

**A — Local technical correctness: PARTIALLY VERIFIED; один metadata blocker.** Policy byte pin, path reconciliation, existing evidence, whitespace diagnostics и checkout portability воспроизводимы. Claim о полном контроле mode/attributes неверен для self manifest.

**B — Independent external trust anchor: PENDING.** Не найден/не поставлен approved owner-controlled artifact. Требуются verifier code/digest и policy digest вне mutable V02, exact final manifest digest, trusted approval-anchor digest, controlled Python/Git execution inputs. Executable digest проверяется перед исполнением; approved values нельзя принимать из candidate. Owner должен контролировать CLI (`--local-proposal` запрещён для publication gate), root/ref, base, Git configuration/environment и исключить чужие Git info/global attributes. Следует отдельно проверять exact reviewed tree/commit и tree metadata, включая manifest mode/attributes. Будущий опубликованный exact implementation SHA должен быть independently привязан; текущий tree OID является tree, не implementation commit.

**C — Human Task Approval: PENDING.** Руслан отдельно оценивает exact опубликованный implementation SHA, target CI и acceptance evidence. Local audit не подменяет решение owner и не даёт разрешение на commit/push/PR/deployment.

## 12. Historical byte preservation

External previous128 records matched; all47 archived files matched original independent snapshot; negative F01/F02 report/snapshot и negative publication audit сохранены. Imports base64 декодированы, hashes/sizes проверены и bytes сравнены с реально существующими внешними source files. Positive123 snapshot также существует и совпадает с импортом. Важные hashes:

- Original negative publication audit: `839e327ce53021596084a962fbf6b17bb86b0b7c40f70eb967d6760413ee53dd`.
- Positive F01/F02 re-audit: `105057ee4ab4380b728a997d56781f278b11b4e4986e9efd443ef01472e16b5c`.
- Positive123 source snapshot: `bd3d12753513ccb2ba0c8771b7c28dd75d58db0e8baa62f193fc6fdcde56082a`.
- Original F01/F02 negative report: `1feaa929b56e5485534fbc606184c8be9953199c1d558782a8fe6717549ddbd2`; snapshot: `19349dca6f3dc9560723a8837766d01a114c6917b158c27a825fafbab0b74a30` (сохранены внутри unchanged128; initial47 отдельно сверены).

Historical отрицательные verdicts остаются CHANGES REQUIRED для своих snapshot. Additive source-imports/report-v2 явно отражают positive runtime provenance и не меняют старые вердикты. Старый stale-runtime-status P3 разрешён новой provenance записью. Missing обязательных файлов не обнаружено. Import receipts: [imports.json](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/imports.json>).

## 13. F01/F02 source identity

Все 28 current backend/source/test/lock/README файлов byte-identical **external positive independent F01/F02 snapshot**, включая indexed bytes и working bytes. F01/F02 source/test changes после технического re-audit отсутствуют. `releases.py` SHA256 `26b11598b287ab063273e3ffe393fbd40da34be1cbc00fdb005125a8439853b4`; `app.py` `1228cb796b594852cc80c2427766c8f0627c2d5fc8a9fb5e18022fb6ceb718e7`.

Новый runtime-аудит из-за publication Round2 delta не требуется. Runtime86/V01/PG/verify_repo исторические результаты не представлены как новое выполнение. Positive report подтверждает F01 CLOSED/F02 CLOSED в своём snapshot; current publication metadata defect не открывает заново их runtime findings. Exact28 mapping — [independent-evidence.json](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/independent-evidence.json>).

## 14. Frozen / ownership verification

60 frozen records сверены с V02_BASE_SHA, HEAD/index blobs и recorded checkout hashes; failures0. Все source staged changes — additions в V02-owned zones. V01/Alembic, Илья frontend, Руслан root CI/verification не менялись. §9–11 Migration Assignment v1.1 требуют independent review, exact source/evidence, target CI и human approval; §10 сохраняет R03/root ownership за Русланом. V02-local proposal verifier не является изменением root registry/CI.

Filename/signature inspection staged bytes не обнаружила DB/venv/cache/pyc/credential files или известных private-key/GitHub/AWS/Slack token signatures. Dedicated secret scanner не запускался; это ограниченная signature review, не универсальное доказательство отсутствия любых secrets/PII. Logs/patches и source-imports являются объяснёнными task records; developer username/paths остаются provenance, runtime private user data не выявлено.

## 15. Remaining P1/P2/P3 findings

**PUB-V2-F01 — P2, blocking: manifest self metadata bypass.** Location: [verify_publication_v2.py](<C:/Projects/MathStart-Python-V02/docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/verify_publication_v2.py:193>) (строки 193–199; anchor проверяет только bytes в 241–244). `if path != MANIFEST` исключает вместе с self hash также FILE_MODE/INDEX_ATTRIBUTES. Текущий self mode=100644, но scratch `git update-index --chmod=+x <manifest>` сохраняет тот же blob OID/SHA256/size и даёт exit0. `--ref` altered tree тоже exit0. С исходными reviewed verifier/policy/manifest byte hashes, independently pinned synthetic runner/anchor получено exit0 `OWNER_EXCEPTION_APPROVED_BY_EXTERNAL_ANCHOR`.

Дополнительно scratch `.git/info/attributes` exact manifest path `-text` меняет effective cached/working attributes (`text=unset` вместо approved normal text=auto) и тоже даёт exit0, включая synthetic anchored run. Никакой verifier/policy/manifest blob при этих anchored probes не менялся. Поэтому owner handoff с одними перечисленными byte digests не обеспечивает заявленный полный mode/attributes gate.

Необходимая доработка: проверять `actual['mode']=='100644'` для **всех139** paths, включая manifest; независимо закрепить и проверять self effective attributes (normal text=auto,eol=lf,без diff/whitespace suppression) в non-circular policy/constant либо owner-controlled metadata gate. Исправить tests: реальные index/tree mode и effective-attribute mutations должны FAIL и с external anchor. Затем пересчитать verifier/manifest digests и выполнить новый scoped independent verification. Raw128/history менять не требуется.

P1: none observed. P2: один подтверждённый новый технический blocker. P3: новых не выявлено. End-to-end P01 остаётся pending B; это отдельно незавершённый owner gate, а не утверждение, что local unchanged verifier принимает allowlist mutation.

## 16. NOT VERIFIED

- Deployed independently protected R03/root CI executable, real approved anchor/exception decision.
- Human Task Approval Руслана; опубликованный exact implementation commit и current candidate target CI.
- Новые runtime/PostgreSQL/Django/verify_repo suites: не запускались по задаче при подтверждённой identity source/tests; historical PASS не объявлены новым PASS.
- Cross-OS execution; Linux/macOS clean checkout не выполнялись. Windows checkout использует documented audit scratch longpaths configuration.
- V03/V04/I02/I03/V05 full integration, production/performance/cutover/deployment; production DB не использовалась.
- Dedicated universal secrets/PII scanner.

## 17. Exact owner-handoff inputs и SHA256

Текущие, независимо измеренные **Git blob bytes** ниже. Это review inputs текущего proposal, не approved pins; после исправления PUB-V2-F01 verifier и manifest должны быть перепроверены/перезакреплены.

| Input | SHA256 | Git blob OID | Bytes | Mode |
| --- | --- | --- | ---: | --- |
| verify_publication_v2.py | `3c3c797a0ae5a039ad8a5e8a47eb7693171b3fe6690991137904b692d0e92b42` | `2448a29c266345d5bc1d86ffb30fed0a107ee066` | 14326 | 100644 |
| exception-policy.json | `09fff1895df489f707000f4a1fec8f6ddd62d1666d2b1c44c94b16ca8ae1741f` | `7cb5b1a151d29efa9723222b98610d3b63dcaec0` | 413159 | 100644 |
| publication-manifest-v2.json | `77b1683733d82a6407f07cc8ce84b5f5344d9f1fd7bf4568ea294b0f6ab10662` | `b94ccda772489f8aa784cf0397bc59cfad96035f` | 103763 | 100644 |

Reviewed current publication tree: `26dfd614f3babc918c7ce5c00c54db55fa983dfd`; input BASE и immutable MIG_BASE_SHA указаны в §1. Tree получен `write-tree` только во временной копии; commit не создавался. После metadata mutation tree изменяется даже при прежних blob digests.

Owner-handoff достаточен как концептуальный handoff для отдельной R03 реализации без изменения V02 ownership: fields owner/decision/policy_blob_sha256/verifier_blob_sha256/manifest_blob_sha256 и external anchor pin перечислены, mutable candidate от trusted runner отделён. **Как готовая execution recipe он требует дополнения/fix self metadata и контроля execution inputs.** Руслану можно передать точную 40-path policy для предварительного решения, но текущий executable не следует закреплять как технически полностью проверенный. Никакое сообщение Руслану/GitHub review этим аудитом не отправлено.

## 18. Final verdict

**CHANGES REQUIRED.**

```text
P01: NOT CLOSED — local policy integrity verified; external immutable enforcement pending
P02: CLOSED — original clean-checkout failure remedied; new metadata P2 tracked separately
P03: CLOSED
External trust anchor: PENDING
Full git diff --check: FAIL
Blocking findings: 1 (PUB-V2-F01, P2)
Human Task Approval: PENDING
```

Исключения40 обоснованы, сохранность bytes и portability подтверждены. Полный статус TECHNICALLY VERIFIED пока недопустим из-за self metadata blocker. READY FOR PUBLICATION недопустим также из-за незавершённых B/C gates. Source139 staged files не изменены; index hash, весь tracked index entries/status и рабочие hashes сравнивались до/после и равны. No git add/commit/push/merge/reset/rebase/clean/PR/review выполнялись. Trace/отчёт/пробы находятся вне source согласно STRICT READ-ONLY.

Final state receipts: [before.json](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/before.json>), [after.json](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/after.json>), [final-state.json](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/final-state.json>). Raw archive probes и независимый отдельный diagnostic parser: FINAL[probes.json](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/probes.json>).

## Appendix A. Exact 40 exceptions

Для каждого пути приведены actual SHA256/OID и количества ordinary/cr-at-eol diagnostics. Полные line/reason arrays и reasons доступны в [independent-evidence.json](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/independent-evidence.json>). Все entries exact paths; raw provenance category указана рядом.

| Path | SHA256 | Git OID | Bytes | Ordinary / cr-at-eol | Raw reason |
| --- | --- | --- | ---: | ---: | --- |
| `docs/acceptance/MS7-MIG-V02/full_content-command.txt` | `abb7ca52c7445d7e0225df99cef1a0d0defab765cde53dcb1589fa3291363130` | `d2888eed7b959f80f5fffd38d80a81aa1329dfb8` | 264 | 1/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/legacy-fresh-smoke-command.txt` | `88a168d66b7a679dcf8fe30eabd32cadf4cc297273f62c3d0c8c615fa986748b` | `fb7041138a28c8341c90f25b78cf4aa5e44cece4` | 3948 | 75/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/legacy-version-report-command.txt` | `105803c51de34022a77ffdef02852ce75ce1fcfea2cfd7d849e1cfff9a1b1a43` | `a8e70131166c1bcaf9281bb401a2633de41d9134` | 650 | 24/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/r02-command.txt` | `faa185cf2db3682ccbaa98bccb4951c8eadfa472223a97d871441ed7ddf71409` | `c64a3712327f99e2f87f849fd3d8fa8a14220549` | 11626 | 68/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/r02a-command.txt` | `dafd961558154ceb3cddfff4f90dd7229aa6ea73d40bbadf280c8174d6ce747a` | `744ccd25be565ed077f1dac1a6b44ea992ab6ce0` | 4494 | 35/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/r03a-command.txt` | `33d07eed6d2827fa5fc7a2254aa7fdeced40065f2aeea01275d1c34f80c028d1` | `cd634dfb5892747b3c55e96c1dff4c551d84d2bd` | 5089 | 47/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/before-fix-command.txt` | `53ba91c265f8ae56363be8557b588d9b93df1776f8425ad0f35920dfa28c9ad4` | `766cab0914e11a8a6229960ccadaef54a206417d` | 2255 | 26/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/full_content-command.txt` | `abb7ca52c7445d7e0225df99cef1a0d0defab765cde53dcb1589fa3291363130` | `d2888eed7b959f80f5fffd38d80a81aa1329dfb8` | 264 | 1/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/files.md` | `3079f97accfb55c514eb03c7c5eb67ee2f29ade50c7680be1e1dcf2b03fc5115` | `dd51ed47a11db9a5640b5dea5ac329def469aa38` | 5158 | 53/0 | Immutable original snapshot CRLF bytes |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/frozen-ownership.json` | `1dbba499b2234e94f680cffacfaa0fa36f0f68c573108b82d8d2d1800fd7877d` | `9828ff349f131f8f6250168d7cd7f3a5cd1f8201` | 29591 | 513/0 | Immutable original snapshot CRLF bytes |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/full_content-command.txt` | `abb7ca52c7445d7e0225df99cef1a0d0defab765cde53dcb1589fa3291363130` | `d2888eed7b959f80f5fffd38d80a81aa1329dfb8` | 264 | 1/0 | Immutable original snapshot CRLF bytes |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/legacy-fresh-smoke-command.txt` | `88a168d66b7a679dcf8fe30eabd32cadf4cc297273f62c3d0c8c615fa986748b` | `fb7041138a28c8341c90f25b78cf4aa5e44cece4` | 3948 | 75/0 | Immutable original snapshot CRLF bytes |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/legacy-version-report-command.txt` | `105803c51de34022a77ffdef02852ce75ce1fcfea2cfd7d849e1cfff9a1b1a43` | `a8e70131166c1bcaf9281bb401a2633de41d9134` | 650 | 24/0 | Immutable original snapshot CRLF bytes |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/old-to-new-evidence.json` | `82913fe097e279f08ebbb1d4b26b9795473b4afe60bac4099a5886c0aa8b67ea` | `2e870bbc0729e68210694ca160fa85a27756f9d8` | 7017 | 143/0 | Immutable original snapshot CRLF bytes |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/r02-command.txt` | `faa185cf2db3682ccbaa98bccb4951c8eadfa472223a97d871441ed7ddf71409` | `c64a3712327f99e2f87f849fd3d8fa8a14220549` | 11626 | 68/0 | Immutable original snapshot CRLF bytes |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/r02a-command.txt` | `dafd961558154ceb3cddfff4f90dd7229aa6ea73d40bbadf280c8174d6ce747a` | `744ccd25be565ed077f1dac1a6b44ea992ab6ce0` | 4494 | 35/0 | Immutable original snapshot CRLF bytes |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/r03a-command.txt` | `33d07eed6d2827fa5fc7a2254aa7fdeced40065f2aeea01275d1c34f80c028d1` | `cd634dfb5892747b3c55e96c1dff4c551d84d2bd` | 5089 | 47/0 | Immutable original snapshot CRLF bytes |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/routes.json` | `95525391e04f00988a1ecd32eb238a9daecd3931e0093e59efd2630d8233aff6` | `a9b080ca72abc7014ba4dba5435dbc55cca01fe9` | 5011 | 192/0 | Immutable original snapshot CRLF bytes |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/test-matrix.json` | `fc08da1b76bc37f809b36cae842ff5e033bfab3c815caf7f20d6b7ba456352c3` | `09713b902baa525728817dd417eb90cdf8ad9621` | 18151 | 512/0 | Immutable original snapshot CRLF bytes |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/v01-command.txt` | `75d29c0df286c2a0b6db843ead8df5edc1bfe27cfb63e5b7dfbc79043b4c9add` | `24dccd1a03d49803d632e39d361cf0aadb2d1cea` | 5291 | 39/0 | Immutable original snapshot CRLF bytes |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/v02-command.txt` | `eb7b35590d12e4d3324cc205a83043a520f061e27e5a3b67fbbb6f7e57b70334` | `b848a725278d84d38167d0a0471689d53133aa9b` | 7295 | 46/0 | Immutable original snapshot CRLF bytes |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/verification.json` | `eda3dcabfc4846615d8556359f5e40c4bca842fa5cec9ce72f909e433ce67c3b` | `3f8e533feadb2ebd03cb141c20db638e565d96cc` | 12328 | 335/0 | Immutable original snapshot CRLF bytes |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/verify-repo-command.txt` | `b350b6ec5e6bfb56e3064f210aa337a95a89a8edd0f714bd3706a8031db57b75` | `7078b6e4504a6c8e984be4b7fbea4f7b789d9408` | 16720 | 194/2 | Immutable original snapshot CRLF bytes |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/workspace-manifest.json` | `0a2a37d7141e1b1e4662a4042bb59018995bc20e4b63a1d02b586ee24c266435` | `4b245ac2d8ecccafd0f9a94457a3177bd7be30b6` | 8730 | 195/0 | Immutable original snapshot CRLF bytes |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/intermediate-v02-84-command.txt` | `3a181050337c571eb7f23f2dcd84d08870d3ec4a9ffdc923ec93fbd5e1665898` | `e294c439242bcc1a4f300542119d8a9fa7330d4e` | 15003 | 89/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/legacy-fresh-smoke-command.txt` | `26d29d15ae943f4795d029fc3aa07abced09f69fc8694c444c7ea9f1a8a266d9` | `9b1f946bad2df57c63532dd4ac694024b0e79e9d` | 3948 | 75/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/legacy-version-report-command.txt` | `105803c51de34022a77ffdef02852ce75ce1fcfea2cfd7d849e1cfff9a1b1a43` | `a8e70131166c1bcaf9281bb401a2633de41d9134` | 650 | 24/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/original-audit/independent-source-snapshot.json` | `19349dca6f3dc9560723a8837766d01a114c6917b158c27a825fafbab0b74a30` | `f66e49eb3ae5785c68046cdfb7a6cf6566f6cc89` | 7827 | 194/0 | Immutable original snapshot CRLF bytes |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/r02-command.txt` | `83d2c167acd1c0950ce7754376b860b4c2b0738478b25baf21a988ddb1cf20c5` | `0713c503b266cfa0ce8fd5ae7d537ff49f1cb8f4` | 11626 | 68/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/r02a-command.txt` | `52e4bf5e0323651f6765a400cfb90e111c01e6c3f0104b7eb4fde7092d8c4637` | `79dd2149afe772e98386a44654e67d331456c010` | 4494 | 35/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/r03a-command.txt` | `7ef400d692becd196c2d1fdb001c47fab3501f9a7f9bfe72822bcc8f2477a14d` | `522074af58846733dc501cf400ececbe777ae708` | 5089 | 47/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/runtime-command.txt` | `c1db251b97af7cd8313f64f080fb02f0248aebdc8039b34ba7b50f938c06280d` | `019231a9c55e7d1c1bc34949c5da3a5c31c880d3` | 112 | 1/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/runtime-pip-command.txt` | `672aec65a45bed50e70229c70934a7eebf0462595c459b83023027645d57cccf` | `5c7a95a1123daef23ddc6831a08c3a59baedb153` | 31 | 1/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/test-pip-command.txt` | `672aec65a45bed50e70229c70934a7eebf0462595c459b83023027645d57cccf` | `5c7a95a1123daef23ddc6831a08c3a59baedb153` | 31 | 1/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/v01-command.txt` | `80989be4302e5ffb86c9eff7792875262ffe4dc4c0ec73d2a51d926f2de59dac` | `fc731837e344fb740cb087f2973fa89ab72a93bd` | 5291 | 39/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/v02-command.txt` | `08a8a1ab7041a22ca05e3011969ab8146137d711bcd566abef40ce8a9fddb257` | `9c919a96d9eadf26b2168a763e39eb1e52911f6a` | 15415 | 91/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/verify-repo-command.txt` | `da00309e1d91b592e91f52a20b7be8a9b7b4696d6c59adc91e46c4ecccf24ea2` | `78827649e80bde2b19d72410003ef4d6e6c5162d` | 16720 | 194/2 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/v01-command.txt` | `75d29c0df286c2a0b6db843ead8df5edc1bfe27cfb63e5b7dfbc79043b4c9add` | `24dccd1a03d49803d632e39d361cf0aadb2d1cea` | 5291 | 39/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/v02-command.txt` | `eb7b35590d12e4d3324cc205a83043a520f061e27e5a3b67fbbb6f7e57b70334` | `b848a725278d84d38167d0a0471689d53133aa9b` | 7295 | 46/0 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |
| `docs/acceptance/MS7-MIG-V02/verify-repo-command.txt` | `b350b6ec5e6bfb56e3064f210aa337a95a89a8edd0f714bd3706a8031db57b75` | `7078b6e4504a6c8e984be4b7fbea4f7b789d9408` | 16720 | 194/2 | Actual captured command stream CRLF/CRCRLF; source log SHA256 retained |

## Appendix B. Exact 33 removed whitespace exemptions

Все остаются raw/hash-pinned, actual ordinary/cr-at-eol diagnostics=0.

- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/compile-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/content/__init__.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/content/grades.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/content/projection.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/content/releases.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/README.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/__init__.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/app.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/contracts.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/requirements.lock`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/requirements.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/runtime.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/signing.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/transport.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/staff/__init__.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/staff/authorization.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/staff/publication.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/staff/reads.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/__init__.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/baseline.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/check_evidence.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/fixtures.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/legacy_comparator.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/public_baseline_projection.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/requirements.lock`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/test_http.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/test_postgres.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/test_unit.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/acceptance-draft.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/report.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/agent-traces/MS7-MIG-V02.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/exec-plans/active/MS7-MIG-V02.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/original-audit/Independent-Audit-Report.md`

## Appendix C. Exact old73 set

- `docs/acceptance/MS7-MIG-V02/full_content-command.txt`
- `docs/acceptance/MS7-MIG-V02/legacy-fresh-smoke-command.txt`
- `docs/acceptance/MS7-MIG-V02/legacy-version-report-command.txt`
- `docs/acceptance/MS7-MIG-V02/r02-command.txt`
- `docs/acceptance/MS7-MIG-V02/r02a-command.txt`
- `docs/acceptance/MS7-MIG-V02/r03a-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/before-fix-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/compile-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/full_content-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/content/__init__.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/content/grades.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/content/projection.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/content/releases.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/README.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/__init__.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/app.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/contracts.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/requirements.lock`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/requirements.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/runtime.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/signing.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/transport.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/staff/__init__.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/staff/authorization.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/staff/publication.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/staff/reads.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/__init__.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/baseline.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/check_evidence.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/fixtures.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/legacy_comparator.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/public_baseline_projection.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/requirements.lock`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/test_http.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/test_postgres.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/test_unit.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/acceptance-draft.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/files.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/frozen-ownership.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/full_content-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/legacy-fresh-smoke-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/legacy-version-report-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/old-to-new-evidence.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/r02-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/r02a-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/r03a-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/report.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/routes.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/test-matrix.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/v01-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/v02-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/verification.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/verify-repo-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/workspace-manifest.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/agent-traces/MS7-MIG-V02.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/exec-plans/active/MS7-MIG-V02.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/intermediate-v02-84-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/legacy-fresh-smoke-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/legacy-version-report-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/original-audit/Independent-Audit-Report.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/original-audit/independent-source-snapshot.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/r02-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/r02a-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/r03a-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/runtime-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/runtime-pip-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/test-pip-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/v01-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/v02-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/verify-repo-command.txt`
- `docs/acceptance/MS7-MIG-V02/v01-command.txt`
- `docs/acceptance/MS7-MIG-V02/v02-command.txt`
- `docs/acceptance/MS7-MIG-V02/verify-repo-command.txt`

## Appendix D. Exact staged additions139

- `backend/content/__init__.py`
- `backend/content/grades.py`
- `backend/content/projection.py`
- `backend/content/releases.py`
- `backend/infrastructure/http/README.md`
- `backend/infrastructure/http/__init__.py`
- `backend/infrastructure/http/app.py`
- `backend/infrastructure/http/contracts.py`
- `backend/infrastructure/http/requirements.lock`
- `backend/infrastructure/http/requirements.txt`
- `backend/infrastructure/http/runtime.py`
- `backend/infrastructure/http/signing.py`
- `backend/infrastructure/http/transport.py`
- `backend/staff/__init__.py`
- `backend/staff/authorization.py`
- `backend/staff/publication.py`
- `backend/staff/reads.py`
- `backend/tests/v02/__init__.py`
- `backend/tests/v02/baseline.py`
- `backend/tests/v02/check_evidence.py`
- `backend/tests/v02/fixtures.py`
- `backend/tests/v02/legacy_comparator.py`
- `backend/tests/v02/public_baseline_projection.py`
- `backend/tests/v02/requirements.lock`
- `backend/tests/v02/test_asset_regressions.py`
- `backend/tests/v02/test_http.py`
- `backend/tests/v02/test_postgres.py`
- `backend/tests/v02/test_unit.py`
- `docs/acceptance/MS7-MIG-V02/.gitattributes`
- `docs/acceptance/MS7-MIG-V02/acceptance-draft.md`
- `docs/acceptance/MS7-MIG-V02/files.md`
- `docs/acceptance/MS7-MIG-V02/frozen-ownership.json`
- `docs/acceptance/MS7-MIG-V02/full_content-command.txt`
- `docs/acceptance/MS7-MIG-V02/legacy-fresh-smoke-command.txt`
- `docs/acceptance/MS7-MIG-V02/legacy-version-report-command.txt`
- `docs/acceptance/MS7-MIG-V02/old-to-new-evidence.json`
- `docs/acceptance/MS7-MIG-V02/publication-byte-audit/publication-evidence.json`
- `docs/acceptance/MS7-MIG-V02/publication-byte-audit/publication-manifest.json`
- `docs/acceptance/MS7-MIG-V02/publication-byte-audit/report.md`
- `docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/checkout-results.json`
- `docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/exception-policy.json`
- `docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/intake.json`
- `docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/owner-handoff.md`
- `docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/probe-results.json`
- `docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/publication-manifest-v2.json`
- `docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/report-v2.md`
- `docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/source-imports.json`
- `docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/test_publication_v2.py`
- `docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/verification.json`
- `docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/verify_publication_v2.py`
- `docs/acceptance/MS7-MIG-V02/publication-byte-audit/verify_publication.py`
- `docs/acceptance/MS7-MIG-V02/r02-command.txt`
- `docs/acceptance/MS7-MIG-V02/r02a-command.txt`
- `docs/acceptance/MS7-MIG-V02/r03a-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/F01-runtime.patch`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/F02-runtime.patch`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/before-fix-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/compile-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/django-http-probes.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/findings.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/frozen-ownership.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/full_content-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/content/__init__.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/content/grades.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/content/projection.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/content/releases.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/README.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/__init__.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/app.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/contracts.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/requirements.lock`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/requirements.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/runtime.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/signing.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/infrastructure/http/transport.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/staff/__init__.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/staff/authorization.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/staff/publication.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/staff/reads.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/__init__.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/baseline.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/check_evidence.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/fixtures.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/legacy_comparator.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/public_baseline_projection.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/requirements.lock`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/test_http.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/test_postgres.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/tests/v02/test_unit.py`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/acceptance-draft.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/files.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/frozen-ownership.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/full_content-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/legacy-fresh-smoke-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/legacy-version-report-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/old-to-new-evidence.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/r02-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/r02a-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/r03a-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/report.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/routes.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/test-matrix.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/v01-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/v02-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/verification.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/verify-repo-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/workspace-manifest.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/agent-traces/MS7-MIG-V02.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/docs/exec-plans/active/MS7-MIG-V02.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/intake.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/intermediate-v02-84-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/legacy-fresh-smoke-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/legacy-version-report-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/original-audit/Independent-Audit-Report.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/original-audit/independent-source-snapshot.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/r02-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/r02a-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/r03a-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/report.md`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/runtime-check-source.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/runtime-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/runtime-pip-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/scope-recheck.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/test-matrix.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/test-pip-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/v01-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/v02-command.txt`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/verification.json`
- `docs/acceptance/MS7-MIG-V02/remediation-f01-f02/verify-repo-command.txt`
- `docs/acceptance/MS7-MIG-V02/report.md`
- `docs/acceptance/MS7-MIG-V02/routes.json`
- `docs/acceptance/MS7-MIG-V02/test-matrix.json`
- `docs/acceptance/MS7-MIG-V02/v01-command.txt`
- `docs/acceptance/MS7-MIG-V02/v02-command.txt`
- `docs/acceptance/MS7-MIG-V02/verification.json`
- `docs/acceptance/MS7-MIG-V02/verify-repo-command.txt`
- `docs/acceptance/MS7-MIG-V02/workspace-manifest.json`
- `docs/agent-traces/MS7-MIG-V02.md`
- `docs/exec-plans/active/MS7-MIG-V02.md`

## Appendix E. Scope of independent evidence

Fresh audit sources: [audit.py](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/audit.py>), [evidence.py](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/evidence.py>), [extra_probes.py](<C:/Users/vladimir/.codex/visualizations/2026/10/12/01a1327a-6c78-70e1-ba92-62725126ad22/publication-reaudit-v2/extra_probes.py>). Reconciliation, diagnostics, probes and final-state receipts are local files outside repository. Synthetic owner fixture is test data only; never reuse it for publication approval.
