from pathlib import Path
import json,hashlib
O=Path(__file__).resolve().parent
def load(n): return json.loads((O/n).read_bytes())
r=load('reconciliation.json'); e=load('independent-evidence.json'); c=load('checkouts.json'); probes=load('probes.json')+load('final-probes.json')['probes']; extra=load('extra-probes.json'); before=load('before.json'); after=load('final-state.json')
assert before==after
def link(n): return '['+n+'](<'+(O/n).as_posix()+'>)'
verifier='C:/Projects/MathStart-Python-V02/docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/verify_publication_v2.py'
text='''# MS7-MIG-V02 — Final Independent Publication Re-Audit v2

13.10.2026, Europe/Moscow. Issue #35. STRICT READ-ONLY аудит исходного worktree/index. Все собственные изменения сделаны только в отдельном audit directory. Human Task Approval Руслана не выдаётся.

**Final verdict: CHANGES REQUIRED.** Подтверждены воспроизводимость clean checkout, прежние bytes и точное сужение whitespace exceptions. Обнаружен один новый блокирующий P2: verifier не проверяет Git mode и ожидаемые effective attributes собственного manifest. Byte-only external anchor также не устраняет этот дефект.

## 1. Actual branch, HEAD и Git index

- Branch: `ms7-mig-v02-content`.
- HEAD / V02_BASE_SHA / merge-base с `origin/ms7-mig-react-fastapi`: `0c03197e23f69a233c0fcf8bdffa336feca20b92`.
- Immutable MIG_BASE_SHA и merge-base с ним: `60b341fbd00f4c8dadd54ae9a3e5811869a9b0f7`.
- 139 staged additions; 0 unstaged; 0 untracked; 0 изменений/удалений baseline paths.
- Implementation commit отсутствует. `tested_implementation_sha=null`, `publication_status=PENDING_PUBLICATION` подтверждены по staged manifest.
- Инструменты: Windows, Python 3.12.10, Git 2.47.0.windows.1. Зависимости не устанавливались; production/working DB не использовались.

Исходный index является index отдельного Git worktree; реальный git-dir определён через `rev-parse --absolute-git-dir`. На source использовался `GIT_OPTIONAL_LOCKS=0`, Python — `-B`/`PYTHONDONTWRITEBYTECODE=1`. Source index SHA256 до/после: `INDEX_HASH`.

## 2. Exact staged file reconciliation

139 = прежние 128 + 11 новых append-only файлов Round2. Все 128 независимо совпали по working SHA256, blob SHA256, OID и size с **внешним previous independent128_records**, а также с Round2 intake. Нулевой diff baseline исключает изменения V01/Alembic/frontend/root CI. Все 11 новых путей находятся в task-owned V02 acceptance subtree; это verifier, tests и evidence/handoff records.

Manifest содержит 138 records плюс исключённый из собственного хеширования manifest: 139 paths, missing/extra=0. Связка bytes/OID/size/mode/attributes для 138 records корректна в текущем index. Никакая historical manifest не переписана: они входят в неизменённые 128 и/или exact initial47 archive.

Полный 139-path inventory, hashes/OIDs/sizes/modes и точные 11 additions: RECONCILIATION. Внешнее сравнение 128: EXTERNAL128.

## 3. P01 — independent finding

**P01: NOT CLOSED end-to-end. Local mutable-policy bypass устранён; independent enforcement ещё PENDING.** Неизменённый staged v2 verifier закрепляет SHA256 policy `09fff1895df489f707000f4a1fec8f6ddd62d1666d2b1c44c94b16ca8ae1741f` в строке 17. Policy и verifier находятся внутри `docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/` и остаются изменяемыми task inputs.

Изменение entry, добавление mutable report/new allowed path, удаление entry и замена entry SHA256 возвращают exit1 `POLICY_DIGEST_MISMATCH`, в том числе после корректного пересчёта соседнего manifest. Новые exceptions автоматически не принимаются неизменённым verifier. Exact path set/count и original128 pins также действуют.

Собственный joint probe изменил policy metadata, заменил digest в verifier и пересчитал оба manifest records. Получен **exit0 local proposal conformance**. Это воспроизведение отсутствия independent local trust boundary; исторические bytes и diagnostics при этом не менялись. Внешний before-execution pin проверенного verifier отклонил заменённый executable digest в отдельной симуляции. Симуляция не доказывает наличие deployed R03 gate. Обычный запуск без anchor возвращает exit3; local proposal exit0 не является approval.

Внешний gate должен получать independently reviewed verifier digest/code, policy digest, final manifest digest, отдельный trusted anchor digest и контролируемый execution context. Их нельзя брать из candidate JSON/report или заново вычислять и объявлять approved самим task. Pending B не скрывается закрытием локальных negatives.

## 4. P02 — independent finding

**P02: CLOSED для исходного clean-checkout portability failure.** Все три реальных checkout проходят unchanged verifier в `--local-proposal` и `--ref TREE` режимах. Исходные Windows working hashes не обязательны; 20 text files меняют только CRLF/LF representation. Raw73 остаются точными bytes, Git index entries неизменны.

Отдельный новый P2 metadata finding в §15 остаётся открытым. Закрытие исходного P02 не означает, что все заявленные mode/attribute guarantees verifier выполнены.

## 5. P03 — independent finding

**P03: CLOSED.** Предыдущий allowlist содержит ровно 73 уникальных пути; новый whitespace allowlist — ровно 40, subset старого. Независимые ordinary diagnostics имеют именно эти 40 paths. Все 33 удалённых из whitespace exemption paths имеют ноль diagnostics; scoped ordinary и cr-at-eol checks вне 40 проходят exit0. Их raw/hash protection сохранена.

73 raw preservation paths = 47 initial archive files + 2 original negative-audit copies + 24 captured command logs. В 40 exceptions входят 17 archived records и 23 raw command logs; active implementation/test files и current mutable reports/manifests не exempt. Archived implementation/test files остаются raw-preserved, но исключены из whitespace waiver при отсутствии diagnostics.

Точный old73/new40/removed33 опубликован в RECONCILIATION и приложениях. Whitespace exceptions используют exact paths, Git pathspec `:(exclude,literal)`; wildcard/path-prefix exclusions отсутствуют. Wildcards в `.gitattributes` регулируют byte preservation архивов/логов и не расширяют whitespace exception list.

## 6. Clean-checkout verification

Созданы три независимых Git roots вне исходного worktree. Index скопирован; Git objects доступны через read-only alternates, новые objects/trees пишутся только в scratch object stores. Выполнен настоящий `git checkout-index --all --force`; commits не создавались. Windows long paths в scratch включены через `core.longpaths=true` из-за длинных repository paths. Initial scratch setup исправлен после CRLF в alternates file и длинных Windows путей; это ошибки настройки audit harness, не результаты candidate checks. Финальные результаты ниже получены после исправления harness.

| core.autocrlf | local proposal | Git tree | --ref tree | raw73 | text EOL-only changes |
| --- | --- | --- | --- | --- | --- |
'''
for mode,x in c.items(): text+=f"| {mode} | PASS/{x['result']['exit']} | `{x['tree']}` | PASS/{x['ref_result']['exit']} | exact | {len(x['working_eol_changes'])} |\n"
text+='''
Во всех трёх roots Git tree representation одинаков; все index OID/mode/stage entries равны исходным. Raw73 bytes, SHA256 и sizes сохранены. Нормализуемые files имеют Git blob LF; дополнительный самостоятельный рабочий LF→CRLF probe на normal report проходит exit0 без изменения blobs. `eol=lf` задаёт LF и при autocrlf=true; отсутствие различий между тремя roots здесь ожидаемо. Explicit working normalization проверена отдельно.

Verifier не обращается к developer absolute path и не требует runtime/venv/DB/внешних original source files; абсолютные source paths в imports служат provenance. Другая ОС не запускалась. Полные checkout receipts: CHECKOUTS.

## 7. Git blob/hash/mode/attributes verification

Независимо проверены все 139 текущих modes (100644), каждый blob SHA256/size/OID и effective cached/working attributes. Manifest records совпадают для 138 файлов. Normal paths: `text=auto,eol=lf,diff=unspecified,whitespace=unspecified`; raw73: `text=unset,eol=lf`, suppression отсутствует. Root и V02-local `.gitattributes` сохранены; baseline/root file mutations отсутствуют.

Raw archive byte, normal blob, unexpected staged path, missing staged/working path, normal file mode и изменённый staged attributes file отклоняются. Новый whitespace defect после manifest rebind также отклоняется по unknown diagnostics. Для **manifest self metadata** verifier фактически не обеспечивает такой же контроль: см. §15. Текущая корректность index metadata не заменяет failing negative test.

Самохеширование manifest обоснованно исключено во избежание цикла. Its working bytes сравниваются с canonical blob; independently pinned final manifest digest должен связывать его содержание. Но исключение self hash не требует исключать проверку mode и approved attributes. Byte SHA256/OID не включает Git tree mode и effective attributes.

## 8. 40-path exception justification

Каждая из 40 записей сверена по OID/SHA256/size и raw bytes. Все ordinary offending lines содержат CR suffix; перед ним нет trailing space/tab. Поэтому обычный check отмечает сохранённые исторические CRLF, а residual cr-at-eol шесть diagnostics вызваны CRCRLF. Их три пути — initial archived verify-repo-command.txt, remediation verify-repo-command.txt и current verify-repo-command.txt; строки 68 и 79 в каждом.

Сохранение raw bytes необходимо для provenance исходных command streams и archived evidence snapshots. Нормализация изменила бы независимо сохранённые hashes. Mutable current reports/new Round2 records не требуют waiver. Каждая причина, line/reason mapping и attributes сохранены в EVIDENCE; Appendix A содержит полный 40-path hash/OID inventory. Исторические manifests/reports под initial archive — immutable historical copies, а не mutable current reports.

## 9. Whitespace checks и реальные exit codes

| Независимый полный/scoped check | Результат | Diagnostics | Paths |
| --- | --- | ---: | ---: |
'''
for name,x in e['checks'].items(): text+=f"| {name} | {'PASS' if x['exit_code']==0 else 'FAIL'}/{x['exit_code']} | {x['count']} | {len(x['by_path'])} |\n"
text+='''
Ordinary stream SHA256 `c1b69b199ac5cd41c665d656a72587d36ff0d13dc04a82c0a4c3d75086da20fb`; cr-at-eol `5837278beb0d2ef638db564512c6913f9ae02346d204ba7b75c059aaef373f63`. Они совпадают с предыдущим независимым аудитом; итоговые streams и exact arrays сохранены без фильтрации. **Full git diff --check: FAIL.** Exception approval пока отсутствует; scoped PASS и local verifier exit0 не переименовывают full FAIL.

Outputs: ORDINARY, CRDIAG, EVIDENCE.

## 10. Independent negative probes

Все mutations сделаны в scratch root. Scratch index менялся только через `hash-object -w`/`update-index`; source index не менялся. Исторический v1 verifier не запускался: он пишет scratch под source var, и не является текущим gate. Staged v2 unit suite отдельно повторена: 15 tests, exit0, 0 skips; это дополнительная проверка, независимые Git probes ниже шире неё.

| Собственная проверка | Ожидаемый exit | Фактический exit | Наблюдение |
| --- | ---: | ---: | --- |
'''
for x in probes:
    if 'actual' in x:
        a=x['actual']; detail=a['result'].get('error',a['result'].get('owner_exception_status',''))
        if x['name'].startswith('joint'): detail+='; отсутствие local independent trust boundary ожидаемо'
        if x['name']=='normal blob mutation with manifest rebind': detail+='; reviewed manifest внешне ещё не pinned'
        text+=f"| {x['name']} | {x['expected_exit']} | **{a['exit']}** | {detail} |\n"
    else: text+=f"| {x['name']} | digest mismatch | digest mismatch | Только внешняя before-execution pin simulation |\n"
for x in extra:
    a=x.get('actual',{}); code=x.get('actual_exit',a.get('exit')); detail=x.get('result',a.get('result',{})).get('owner_exception_status','')
    text+=f"| {x['name']} | {x['expected_exit']} | **{code}** | {detail}; unexpected acceptance |\n"
text+='''
Joint replacement expected exit0 показывает границу локальной защиты; без independently pinned executable задача может переписать сам checker. Normal new Round2 report+manifest rebinding также локально допустим до external manifest approval. Эти результаты не выдаются за protection PASS. Self metadata negatives, напротив, должны FAIL даже при исходных reviewed byte pins и проходят — новый defect.

Синтетический JSON содержит `owner=Ruslan,decision=APPROVED` **только как attack-test fixture** и явный маркер NOT ACTUAL OWNER APPROVAL. Его digest/runner закреплены audit harness; это не запись решения Руслана и не deployed anchor. Fixture используется только внутри отдельной копии. Полные результаты: PROBES, EXTRA, UNIT.

## 11. External trust-anchor requirements — A / B / C

**A — Local technical correctness: PARTIALLY VERIFIED; один metadata blocker.** Policy byte pin, path reconciliation, existing evidence, whitespace diagnostics и checkout portability воспроизводимы. Claim о полном контроле mode/attributes неверен для self manifest.

**B — Independent external trust anchor: PENDING.** Не найден/не поставлен approved owner-controlled artifact. Требуются verifier code/digest и policy digest вне mutable V02, exact final manifest digest, trusted approval-anchor digest, controlled Python/Git execution inputs. Executable digest проверяется перед исполнением; approved values нельзя принимать из candidate. Owner должен контролировать CLI (`--local-proposal` запрещён для publication gate), root/ref, base, Git configuration/environment и исключить чужие Git info/global attributes. Следует отдельно проверять exact reviewed tree/commit и tree metadata, включая manifest mode/attributes. Будущий опубликованный exact implementation SHA должен быть independently привязан; текущий tree OID является tree, не implementation commit.

**C — Human Task Approval: PENDING.** Руслан отдельно оценивает exact опубликованный implementation SHA, target CI и acceptance evidence. Local audit не подменяет решение owner и не даёт разрешение на commit/push/PR/deployment.

## 12. Historical byte preservation

External previous128 records matched; all47 archived files matched original independent snapshot; negative F01/F02 report/snapshot и negative publication audit сохранены. Imports base64 декодированы, hashes/sizes проверены и bytes сравнены с реально существующими внешними source files. Positive123 snapshot также существует и совпадает с импортом. Важные hashes:

- Original negative publication audit: `839e327ce53021596084a962fbf6b17bb86b0b7c40f70eb967d6760413ee53dd`.
- Positive F01/F02 re-audit: `105057ee4ab4380b728a997d56781f278b11b4e4986e9efd443ef01472e16b5c`.
- Positive123 source snapshot: `bd3d12753513ccb2ba0c8771b7c28dd75d58db0e8baa62f193fc6fdcde56082a`.
- Original F01/F02 negative report: `1feaa929b56e5485534fbc606184c8be9953199c1d558782a8fe6717549ddbd2`; snapshot: `19349dca6f3dc9560723a8837766d01a114c6917b158c27a825fafbab0b74a30` (сохранены внутри unchanged128; initial47 отдельно сверены).

Historical отрицательные verdicts остаются CHANGES REQUIRED для своих snapshot. Additive source-imports/report-v2 явно отражают positive runtime provenance и не меняют старые вердикты. Старый stale-runtime-status P3 разрешён новой provenance записью. Missing обязательных файлов не обнаружено. Import receipts: IMPORTS.

## 13. F01/F02 source identity

Все 28 current backend/source/test/lock/README файлов byte-identical **external positive independent F01/F02 snapshot**, включая indexed bytes и working bytes. F01/F02 source/test changes после технического re-audit отсутствуют. `releases.py` SHA256 `26b11598b287ab063273e3ffe393fbd40da34be1cbc00fdb005125a8439853b4`; `app.py` `1228cb796b594852cc80c2427766c8f0627c2d5fc8a9fb5e18022fb6ceb718e7`.

Новый runtime-аудит из-за publication Round2 delta не требуется. Runtime86/V01/PG/verify_repo исторические результаты не представлены как новое выполнение. Positive report подтверждает F01 CLOSED/F02 CLOSED в своём snapshot; current publication metadata defect не открывает заново их runtime findings. Exact28 mapping — EVIDENCE.

## 14. Frozen / ownership verification

60 frozen records сверены с V02_BASE_SHA, HEAD/index blobs и recorded checkout hashes; failures0. Все source staged changes — additions в V02-owned zones. V01/Alembic, Илья frontend, Руслан root CI/verification не менялись. §9–11 Migration Assignment v1.1 требуют independent review, exact source/evidence, target CI и human approval; §10 сохраняет R03/root ownership за Русланом. V02-local proposal verifier не является изменением root registry/CI.

Filename/signature inspection staged bytes не обнаружила DB/venv/cache/pyc/credential files или известных private-key/GitHub/AWS/Slack token signatures. Dedicated secret scanner не запускался; это ограниченная signature review, не универсальное доказательство отсутствия любых secrets/PII. Logs/patches и source-imports являются объяснёнными task records; developer username/paths остаются provenance, runtime private user data не выявлено.

## 15. Remaining P1/P2/P3 findings

**PUB-V2-F01 — P2, blocking: manifest self metadata bypass.** Location: VERIFIER_LINK (строки 193–199; anchor проверяет только bytes в 241–244). `if path != MANIFEST` исключает вместе с self hash также FILE_MODE/INDEX_ATTRIBUTES. Текущий self mode=100644, но scratch `git update-index --chmod=+x <manifest>` сохраняет тот же blob OID/SHA256/size и даёт exit0. `--ref` altered tree тоже exit0. С исходными reviewed verifier/policy/manifest byte hashes, independently pinned synthetic runner/anchor получено exit0 `OWNER_EXCEPTION_APPROVED_BY_EXTERNAL_ANCHOR`.

Дополнительно scratch `.git/info/attributes` exact manifest path `-text` меняет effective cached/working attributes (`text=unset` вместо approved normal text=auto) и тоже даёт exit0, включая synthetic anchored run. Никакой verifier/policy/manifest blob при этих anchored probes не менялся. Поэтому owner handoff с одними перечисленными byte digests не обеспечивает заявленный полный mode/attributes gate.

Необходимая доработка: проверять `actual['mode']=='100644'` для **всех139** paths, включая manifest; независимо закрепить и проверять self effective attributes (normal text=auto,eol=lf,без diff/whitespace suppression) в non-circular policy/constant либо owner-controlled metadata gate. Исправить tests: реальные index/tree mode и effective-attribute mutations должны FAIL и с external anchor. Затем пересчитать verifier/manifest digests и выполнить новый scoped independent verification. Raw128/history менять не требуется.

P1: none observed. P2: один подтверждённый новый технический blocker. P3: новых не выявлено. End-to-end P01 остаётся pending B; это отдельно незавершённый owner gate, а не утверждение, что local unchanged verifier принимает allowlist mutation.

## 16. NOT VERIFIED

- Deployed independently protected R03/root CI executable, real approved anchor/exception decision.
- Human Task Approval Руслана; опубликованный exact implementation commit и current candidate target CI.
- Новые runtime/PostgreSQL/Django/verify_repo suites: не запускались по задаче при подтверждённой identity source/tests; historical PASS не объявлены новым PASS.
- Cross-OS execution; Linux/macOS clean checkout не выполнялись. Windows checkout использует documented audit scratch longpaths configuration.
- V03/V04/I02/I03/V05 full integration, production/performance/cutover/deployment; production DB не использовалась.
- Dedicated universal secrets/PII scanner.

## 17. Exact owner-handoff inputs и SHA256

Текущие, независимо измеренные **Git blob bytes** ниже. Это review inputs текущего proposal, не approved pins; после исправления PUB-V2-F01 verifier и manifest должны быть перепроверены/перезакреплены.

| Input | SHA256 | Git blob OID | Bytes | Mode |
| --- | --- | --- | ---: | --- |
'''
for p,x in r['digests'].items(): text+=f"| {Path(p).name} | `{x['sha256']}` | `{x['oid']}` | {x['bytes']} | {x['mode']} |\n"
text+='''
Reviewed current publication tree: `26dfd614f3babc918c7ce5c00c54db55fa983dfd`; input BASE и immutable MIG_BASE_SHA указаны в §1. Tree получен `write-tree` только во временной копии; commit не создавался. После metadata mutation tree изменяется даже при прежних blob digests.

Owner-handoff достаточен как концептуальный handoff для отдельной R03 реализации без изменения V02 ownership: fields owner/decision/policy_blob_sha256/verifier_blob_sha256/manifest_blob_sha256 и external anchor pin перечислены, mutable candidate от trusted runner отделён. **Как готовая execution recipe он требует дополнения/fix self metadata и контроля execution inputs.** Руслану можно передать точную 40-path policy для предварительного решения, но текущий executable не следует закреплять как технически полностью проверенный. Никакое сообщение Руслану/GitHub review этим аудитом не отправлено.

## 18. Final verdict

**CHANGES REQUIRED.**

```text
P01: NOT CLOSED — local policy integrity verified; external immutable enforcement pending
P02: CLOSED — original clean-checkout failure remedied; new metadata P2 tracked separately
P03: CLOSED
External trust anchor: PENDING
Full git diff --check: FAIL
Blocking findings: 1 (PUB-V2-F01, P2)
Human Task Approval: PENDING
```

Исключения40 обоснованы, сохранность bytes и portability подтверждены. Полный статус TECHNICALLY VERIFIED пока недопустим из-за self metadata blocker. READY FOR PUBLICATION недопустим также из-за незавершённых B/C gates. Source139 staged files не изменены; index hash, весь tracked index entries/status и рабочие hashes сравнивались до/после и равны. No git add/commit/push/merge/reset/rebase/clean/PR/review выполнялись. Trace/отчёт/пробы находятся вне source согласно STRICT READ-ONLY.

Final state receipts: BEFORE, AFTER, FINALSTATE. Raw archive probes и независимый отдельный diagnostic parser: FINALPROBES.

## Appendix A. Exact 40 exceptions

Для каждого пути приведены actual SHA256/OID и количества ordinary/cr-at-eol diagnostics. Полные line/reason arrays и reasons доступны в EVIDENCE. Все entries exact paths; raw provenance category указана рядом.

| Path | SHA256 | Git OID | Bytes | Ordinary / cr-at-eol | Raw reason |
| --- | --- | --- | ---: | ---: | --- |
'''
for x in e['exceptions']:
    text+=f"| `{x['path']}` | `{x['blob_sha256']}` | `{x['blob_oid']}` | {x['bytes']} | {len(x['ordinary'])}/{len(x['cr_at_eol'])} | {x['reason']} |\n"
text+='\n## Appendix B. Exact 33 removed whitespace exemptions\n\nВсе остаются raw/hash-pinned, actual ordinary/cr-at-eol diagnostics=0.\n\n'
text+='\n'.join('- `'+p+'`' for p in r['removed33'])+'\n'
text+='\n## Appendix C. Exact old73 set\n\n'+ '\n'.join('- `'+p+'`' for p in r['old73'])+'\n'
text+='\n## Appendix D. Exact staged additions139\n\n'+ '\n'.join('- `'+p+'`' for p in sorted(r['staged']))+'\n'
text+='\n## Appendix E. Scope of independent evidence\n\nFresh audit sources: '+link('audit.py')+', '+link('evidence.py')+', '+link('extra_probes.py')+'. Reconciliation, diagnostics, probes and final-state receipts are local files outside repository. Synthetic owner fixture is test data only; never reuse it for publication approval.\n'
replacements={'INDEX_HASH':after['index_sha256'],'RECONCILIATION':link('reconciliation.json'),'EXTERNAL128':link('external128-comparison.json'),
'CHECKOUTS':link('checkouts.json'),'EVIDENCE':link('independent-evidence.json'),'ORDINARY':link('ordinary-diagnostics.txt'),'CRDIAG':link('cr-at-eol-diagnostics.txt'),
'PROBES':link('probes.json'),'EXTRA':link('extra-probes.json'),'UNIT':link('unit-tests.txt'),'IMPORTS':link('imports.json'),
'VERIFIER_LINK':'[verify_publication_v2.py](<'+verifier+':193>)','BEFORE':link('before.json'),'AFTER':link('after.json'),'FINALSTATE':link('final-state.json'),'FINALPROBES':link('final-probes.json')}
for a,b in replacements.items(): text=text.replace(a,b)
(O/'Independent-Publication-Re-Audit-v2.md').write_text(text,encoding='utf-8')
print('Report saved',len(text),'characters')
