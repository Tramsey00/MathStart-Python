import os, sys, json, hashlib, subprocess, shutil, base64, re, copy
from pathlib import Path
ROOT=Path('C:/Projects/MathStart-Python-V02')
OUT=Path(__file__).resolve().parent
P='docs/acceptance/MS7-MIG-V02/publication-byte-audit/round2/'
V=P+'verify_publication_v2.py'; POL=P+'exception-policy.json'; M=P+'publication-manifest-v2.json'
BASE='0c03197e23f69a233c0fcf8bdffa336feca20b92'
os.environ.update(GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1', LC_ALL='C')
def sha(b): return hashlib.sha256(b).hexdigest()
def run(root,args,data=None):
    r=subprocess.run(args,cwd=root,input=data,capture_output=True)
    return r
def git(root,*args,data=None):
    r=run(root,['git',*args],data)
    if r.returncode: raise RuntimeError((args,r.returncode,r.stderr.decode(errors='replace')))
    return r.stdout
def j(b): return json.loads(b)
GITDIR=Path(git(ROOT,'rev-parse','--absolute-git-dir').decode().strip())
OBJECTS=Path(git(ROOT,'rev-parse','--path-format=absolute','--git-path','objects').decode().strip())
def dump(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def blob(root,path): return git(root,'show',':'+path)
def entries(root):
    d={}
    for x in git(root,'ls-files','--stage','-z').split(b'\0'):
        if x:
            meta,path=x.split(b'\t'); mode,oid,stage=meta.decode().split(); d[path.decode()]={'mode':mode,'oid':oid,'stage':stage}
    return d
def state():
    paths=git(ROOT,'ls-files','-z').decode().split('\0')[:-1]
    return {'index_sha256':sha((GITDIR/'index').read_bytes()),'status':git(ROOT,'status','--porcelain=v1','-z').decode(),
            'head':git(ROOT,'rev-parse','HEAD').decode().strip(),'branch':git(ROOT,'branch','--show-current').decode().strip(),
            'index_entries':entries(ROOT),'working_files':{p:sha((ROOT/p).read_bytes()) for p in paths if (ROOT/p).is_file()}}
def check(root,*args):
    r=run(root,[sys.executable,'-B',str(root/V),'--root',str(root),*args])
    try: result=j(r.stdout)
    except Exception: result={'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace')}
    return {'exit':r.returncode,'result':result}
def init_copy(name,autocrlf='false'):
    root=OUT/name; root.mkdir(exist_ok=True)
    git(root,'init','--quiet')
    git(root,'config','core.autocrlf',autocrlf)
    git(root,'config','core.filemode','false')
    git(root,'config','core.longpaths','true')
    git(root,'config','core.whitespace','blank-at-eol,blank-at-eof,space-before-tab')
    (root/'.git/objects/info/alternates').write_bytes((OBJECTS.as_posix()+'\n').encode())
    (root/'.git/HEAD').write_bytes((BASE+'\n').encode())
    shutil.copyfile(GITDIR/'index',root/'.git/index')
    git(root,'checkout-index','--all','--force')
    return root
def stage(root,path,raw,mode='100644'):
    f=root/path; f.parent.mkdir(parents=True,exist_ok=True); f.write_bytes(raw)
    oid=git(root,'hash-object','-w','--stdin',data=raw).decode().strip()
    git(root,'update-index','--add','--cacheinfo',mode,oid,path)
    return oid
def rebind(root,path):
    m=j(blob(root,M)); b=blob(root,path); e=entries(root)[path]
    if path in m['files']:
        m['files'][path].update(blob_oid=e['oid'],blob_sha256=sha(b),blob_bytes=len(b),mode=e['mode'])
    stage(root,M,(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode())
before=state(); dump('before.json',before)
staged=git(ROOT,'diff','--cached','--name-only','-z').decode().split('\0')[:-1]
policy=j(blob(ROOT,POL)); manifest=j(blob(ROOT,M)); intake=j(blob(ROOT,P+'intake.json'))
cached=j((OUT/'reconciliation.json').read_bytes()) if (OUT/'reconciliation.json').exists() else None
records=cached['staged'] if cached else {p:{**before['index_entries'][p],'sha256':sha(blob(ROOT,p)),'bytes':len(blob(ROOT,p)),'work_sha256':sha((ROOT/p).read_bytes())} for p in staged}
assert len(staged)==139 and len(manifest['files'])==138
old=j(blob(ROOT,'docs/acceptance/MS7-MIG-V02/publication-byte-audit/publication-evidence.json'))['exact_evidence_allowlist']
oldset={i['path'] for i in old}; newset={i['path'] for i in policy['whitespace_exceptions']}
assert len(oldset)==73 and len(newset)==40 and newset<=oldset
unchanged=[]
for p,x in intake['files'].items():
    r=records[p]
    assert (r['sha256'],r['oid'],r['bytes'],r['work_sha256'],len((ROOT/p).read_bytes()))==(x['blob_sha256'],x['oid'],x['blob_bytes'],x['work_sha256'],x['work_bytes']),p
    unchanged.append(p)
imports=j(blob(ROOT,P+'source-imports.json'))['sources']; import_checks={}
for key,x in imports.items():
    b=base64.b64decode(x['bytes_base64']); assert sha(b)==x['sha256'] and len(b)==x['bytes']
    f=Path(x['source']); exists=f.is_file(); assert not exists or f.read_bytes()==b
    import_checks[key]={'source':str(f),'exists':exists,'sha256':sha(b),'bytes':len(b),'keys':list(x)}
    (OUT/(key+'.txt')).write_bytes(b)
snapshot=j(base64.b64decode(imports['positive_runtime_snapshot']['bytes_base64'])) if 'positive_runtime_snapshot' in imports else None
dump('imports.json',import_checks)
dump('reconciliation.json',{'staged':records,'original128_unchanged':unchanged,'new11':sorted(set(staged)-set(unchanged)),
    'old73':sorted(oldset),'new40':sorted(newset),'removed33':sorted(oldset-newset),'digests':{p:records[p] for p in (V,POL,M)}})
print('Intake, 139 paths, original128, imports verified',flush=True)
copies={}; checkout_results={}
for mode in ('false','true','input'):
    root=init_copy('checkout-'+mode,mode); copies[mode]=root
    tree=git(root,'write-tree').decode().strip()
    result=check(root,'--local-proposal'); assert result['exit']==0,result
    e=entries(root); assert e==before['index_entries']
    changes=[p for p in staged if sha((root/p).read_bytes())!=records[p]['work_sha256']]
    raw=[i['path'] for i in policy['preserve_raw_bytes']]
    assert all((root/p).read_bytes()==blob(ROOT,p) for p in raw)
    checkout_results[mode]={'tree':tree,'result':result,'raw73_exact':True,'all_index_entries_identical':True,'working_eol_changes':changes,
         'ref_result':check(root,'--ref',tree,'--local-proposal')}
    print('Clean checkout',mode,result['exit'],flush=True)
dump('checkouts.json',checkout_results)
root=copies['false']; baseindex=(root/'.git/index').read_bytes()
saved={p:(root/p).read_bytes() for p in staged}
probes=[]
def restore():
    (root/'.git/index').write_bytes(baseindex)
    for p,b in saved.items(): (root/p).write_bytes(b)
def probe(name,mutate,expected=1,extra=('--local-proposal',)):
    restore(); mutate(); actual=check(root,*extra)
    probes.append({'name':name,'expected_exit':expected,'actual':actual,'matched':actual['exit']==expected})
    dump('probes.json',probes)
    print(name,actual['exit'],actual.get('result',{}).get('error',''),flush=True)
def pol_mutate(fn,rebind_manifest=False):
    q=copy.deepcopy(policy); fn(q); stage(root,POL,(json.dumps(q,ensure_ascii=False,indent=2)+'\n').encode())
    if rebind_manifest: rebind(root,POL)
probe('allowlist entry change + manifest rebind',lambda:pol_mutate(lambda q:q['whitespace_exceptions'][0].update(raw_preservation_reason='changed'),True))
probe('add mutable report exception',lambda:pol_mutate(lambda q:q['whitespace_exceptions'].append({**q['whitespace_exceptions'][0],'path':P+'report-v2.md'}),True))
probe('remove required allowlist path',lambda:pol_mutate(lambda q:q['whitespace_exceptions'].pop(),True))
probe('replace pinned entry SHA256',lambda:pol_mutate(lambda q:q['whitespace_exceptions'][0].update(blob_sha256='0'*64),True))
probe('add new allowed path',lambda:pol_mutate(lambda q:q['whitespace_exceptions'].append({**q['whitespace_exceptions'][0],'path':'new/unapproved.txt'})))
normal=P+'owner-handoff.md'; raw=policy['preserve_raw_bytes'][0]['path']
probe('normal blob byte mutation',lambda:stage(root,normal,saved[normal]+b'changed\n'))
probe('normal blob mutation with manifest rebind',lambda:(stage(root,normal,saved[normal]+b'changed\n'),rebind(root,normal)),expected=0)
probe('raw working byte mutation',lambda:(root/raw).write_bytes(saved[raw]+b'x'))
probe('raw blob byte mutation + manifest rebind',lambda:(stage(root,raw,saved[raw]+b'x'),rebind(root,raw)))
probe('unexpected staged file',lambda:stage(root,'unexpected-audit-file.txt',b'x\n'))
probe('missing staged file',lambda:git(root,'update-index','--force-remove',normal))
probe('missing working file',lambda:(root/normal).unlink())
probe('normal mode 100755',lambda:git(root,'update-index','--chmod=+x',normal))
probe('manifest self mode 100755',lambda:git(root,'update-index','--chmod=+x',M))
probe('changed local attributes',lambda:stage(root,'docs/acceptance/MS7-MIG-V02/.gitattributes',saved['docs/acceptance/MS7-MIG-V02/.gitattributes']+b'publication-byte-audit/round2/*.md -text\n'))
probe('whitespace defect outside allowlist + manifest rebind',lambda:(stage(root,normal,saved[normal]+b'bad \t\n'),rebind(root,normal)))
probe('extra CRCRLF diagnostic + manifest rebind',lambda:(stage(root,raw,saved[raw]+b'extra\r\r\n'),rebind(root,raw)))
probe('default gate without external trust anchor',lambda:None,expected=3,extra=())
probe('normal working CRLF equivalence',lambda:(root/normal).write_bytes(saved[normal].replace(b'\n',b'\r\n')),expected=0)
def joint():
    # Change policy metadata and verifier pin together, preserving cardinalities/diagnostics.
    q=copy.deepcopy(policy); q['unreviewed_policy_change']='unapproved attacker-controlled metadata'
    b=(json.dumps(q,ensure_ascii=False,indent=2)+'\n').encode(); stage(root,POL,b)
    code=saved[V].replace(sha(blob(ROOT,POL)).encode(),sha(b).encode()); stage(root,V,code)
    rebind(root,POL); rebind(root,V)
probe('joint verifier + policy + manifest replacement',joint,expected=0)
restore(); joint()
probes.append({'name':'independent before-execution verifier pin rejects joint tamper','expected':'digest mismatch',
    'actual_digest':sha((root/V).read_bytes()),'reviewed_digest':records[V]['sha256'],
    'matched':sha((root/V).read_bytes())!=records[V]['sha256'],'simulation_only':True})
restore()
unit=run(root,[sys.executable,'-B',str(root/(P+'test_publication_v2.py'))]); (OUT/'unit-tests.txt').write_bytes(unit.stdout+unit.stderr)
dump('unit.json',{'exit':unit.returncode,'output_sha256':sha(unit.stdout+unit.stderr)})
dump('probes.json',probes)
after=state(); dump('after.json',after); assert before==after,'SOURCE MUTATED'
print('Source state identical; audit probes complete',flush=True)
