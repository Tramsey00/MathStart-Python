from pathlib import Path
exec(Path(__file__).with_name('audit.py').read_text().split('before=state();')[0])
root=OUT/'checkout-false'; results=[]
archive='docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/backend/content/grades.py'
b=(root/archive).read_bytes(); index=(root/'.git/index').read_bytes()
(root/archive).write_bytes(b+b'changed byte\n')
results.append({'name':'raw ARCHIVE working byte mutation','expected_exit':1,'actual':check(root,'--local-proposal')})
stage(root,archive,b+b'changed byte\n'); rebind(root,archive)
results.append({'name':'raw ARCHIVE staged byte mutation + manifest rebind','expected_exit':1,'actual':check(root,'--local-proposal')})
(root/'.git/index').write_bytes(index); (root/archive).write_bytes(b); (root/M).write_bytes(blob(ROOT,M))
assert all(x['actual']['exit']==1 for x in results)
old=Path('C:/Users/vladimir/.codex/visualizations/2026/10/12/01a13252-fee4-7fa0-b5e4-1de384038a3c/publication-audit-temp/diagnostics-and-records.json')
previous=j(old.read_bytes()); evidence=j((OUT/'independent-evidence.json').read_bytes())
for name in ('ordinary','cr-at-eol'):
    raw=(OUT/(name+'-diagnostics.txt')).read_bytes(); independent={}
    for line in raw.split(b'\n'):
        if not line or line.startswith(b'+'): continue
        path,number,reason=line.decode().rsplit(':',2)
        assert reason.startswith(' ') and reason.endswith('.')
        independent.setdefault(path,[]).append({'line':int(number),'reason':reason[1:-1]})
    assert independent==evidence['checks'][name]['by_path']
    assert independent==previous[name]['findings_by_path']
imports=j(blob(ROOT,P+'source-imports.json'))['sources']
for name,x in imports.items():
    b=base64.b64decode(x['bytes_base64']); stringkeys=[k for k in x if 'utf' in k or 'verbatim' in k]
    for k in stringkeys:
        assert x[k].encode('utf-8')==b,(name,k)
before=j((OUT/'before.json').read_bytes()); after=state(); assert before==after
dump('final-state.json',after)
dump('final-probes.json',{'probes':results,'independent_diagnostic_parser_matches_previous':True,'imports_utf8_matches_base64':True,'source_exactly_preserved':True})
print('Raw ARCHIVE negatives exit1; independent diagnostic parser matches previous; source bytes/index unchanged')
