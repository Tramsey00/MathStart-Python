from pathlib import Path
exec(Path(__file__).with_name('audit.py').read_text().split('before=state();')[0])
root=OUT/'checkout-false'
sourceindex=(GITDIR/'index').read_bytes()
paths=git(ROOT,'diff','--cached','--name-only','-z').decode().split('\0')[:-1]
# Restore scratch candidate from source read-only blobs, never restore source itself.
def restore():
    (root/'.git/index').write_bytes(sourceindex)
    for p in paths: (root/p).write_bytes(blob(ROOT,p))
    f=root/'.git/info/attributes'
    if f.exists(): f.unlink()
restore()
reviewed={p:sha(blob(ROOT,p)) for p in (POL,V,M)}
anchor={'owner':'Ruslan','decision':'APPROVED','policy_blob_sha256':reviewed[POL],'verifier_blob_sha256':reviewed[V],'manifest_blob_sha256':reviewed[M],
        '_fixture':'SYNTHETIC AUDIT PROBE ONLY. NOT ACTUAL OWNER APPROVAL.'}
anchor_path=OUT/'SYNTHETIC-NOT-OWNER-APPROVAL.json'
anchor_bytes=(json.dumps(anchor,indent=2)+'\n').encode(); anchor_path.write_bytes(anchor_bytes)
runner=OUT/'synthetic-owner-pinned-runner.py'; runner.write_bytes(blob(ROOT,V)); assert sha(runner.read_bytes())==reviewed[V]
results=[]
def anchored(label):
    argv=[sys.executable,'-B',str(runner),'--root',str(root),'--owner-anchor',str(anchor_path),'--owner-anchor-sha256',sha(anchor_bytes)]
    r=run(root,argv); results.append({'name':label,'expected_exit':1,'actual_exit':r.returncode,'result':j(r.stdout),'fixture_only':True,
        'reviewed_byte_pins_unchanged':all(sha(blob(root,p))==reviewed[p] for p in (POL,V,M))})
git(root,'update-index','--chmod=+x',M)
anchored('manifest self mode 100755 WITH unchanged independent byte anchor')
tree=git(root,'write-tree').decode().strip()
results.append({'name':'manifest self mode 100755 TREE --ref','expected_exit':1,'actual':check(root,'--local-proposal','--ref',tree),'tree':tree})
restore()
(root/'.git/info/attributes').write_bytes((M+' -text\n').encode())
results.append({'name':'manifest self effective attributes -text','expected_exit':1,'actual':check(root,'--local-proposal'),
    'cached_attributes':git(root,'check-attr','--cached','text','eol','diff','whitespace','--',M).decode()})
anchored('manifest self -text WITH unchanged independent byte anchor')
restore()
dump('extra-probes.json',results)
print(json.dumps(results))
