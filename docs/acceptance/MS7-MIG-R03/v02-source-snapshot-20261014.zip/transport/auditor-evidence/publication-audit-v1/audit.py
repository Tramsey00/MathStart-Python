import os,sys,json,subprocess,hashlib,tempfile,shutil,re,collections
from pathlib import Path
R=Path(r'C:\Projects\MathStart-Python-V02'); A=Path(r'C:\Users\vladimir\.codex\visualizations\2026\10\12\01a13205-a85a-7183-94b5-1483f3b7aba9\audit'); P='docs/acceptance/MS7-MIG-V02/'; Q=P+'publication-byte-audit/'; H=P+'remediation-f01-f02/'
os.environ['GIT_OPTIONAL_LOCKS']='0'; os.environ['PYTHONDONTWRITEBYTECODE']='1'
def run(*args,cwd=R):return subprocess.run(args,cwd=cwd,capture_output=True)
def git(*args,cwd=R):
 r=run('git',*args,cwd=cwd);assert r.returncode==0,(args,r.stderr);return r.stdout
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(p):return git('show',':'+p)
def load(p):return json.loads(p.read_bytes())
paths=git('diff','--cached','--name-only','-z').decode().split('\0')[:-1];idx=Path(git('rev-parse','--git-path','index').decode().strip())
def state():return {'index':sha(idx.read_bytes()),'status':git('status','--porcelain=v1','-z').hex(),'work':{p:sha((R/p).read_bytes()) for p in paths}}
# Batch staged blob reads, OIDs and effective attributes to avoid repeated process starts.
entries=git('ls-files','--stage','-z').split(b'\0')[:-1]; ids={x.split(b'\t',1)[1].decode():x.split()[1].decode() for x in entries}
batch=subprocess.run(['git','cat-file','--batch'],input=('\n'.join(ids.values())+'\n').encode(),cwd=R,capture_output=True,check=True).stdout; pos=0; bc={}
for p in ids:
 end=batch.index(b'\n',pos); size=int(batch[pos:end].split()[-1]);pos=end+1;bc[p]=batch[pos:pos+size];pos+=size+1
attrraw=subprocess.run(['git','check-attr','--cached','text','eol','--stdin'],input=('\n'.join(paths)+'\n').encode(),cwd=R,capture_output=True,check=True).stdout.decode().splitlines();ac={}
for line in attrraw: ac.setdefault(line.split(': ',1)[0],[]).append(line)
original_git=git
def git(*args,cwd=R):
 if cwd==R and args[0]=='show' and args[1].startswith(':'):return bc[args[1][1:]]
 if cwd==R and args[0]=='rev-parse' and args[1].startswith(':'):return (ids[args[1][1:]]+'\n').encode()
 if cwd==R and args[0]=='check-attr':return ('\n'.join(ac[args[-1]])+'\n').encode()
 return original_git(*args,cwd=cwd)
before=state();m=load(R/(Q+'publication-manifest.json'));e=load(R/(Q+'publication-evidence.json'));old=load(R/(P+'workspace-manifest.json'))
out={'head':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'staged':len(paths),'unstaged':git('diff','--name-only').decode(),'untracked':git('ls-files','--others','--exclude-standard').decode(),'status_counts':dict(collections.Counter(x.split('\t')[0] for x in git('diff','--cached','--name-status').decode().splitlines()))}
out['scope_counts']=dict(collections.Counter('backend' if p.startswith('backend/') else 'initial_archive' if '/history/initial/' in p else 'original_audit' if '/original-audit/' in p else 'publication_audit' if '/publication-byte-audit/' in p else 'V02_docs' for p in paths));out['manifest_missing']=sorted(set(paths)-set(m['files'])-{Q+'publication-manifest.json'});out['manifest_extra']=sorted(set(m['files'])-set(paths));errors=[];diffs=[];cr=[];attrs={}
for p,r in m['files'].items():
 w=(R/p).read_bytes();b=blob(p);oid=git('rev-parse',':'+p).decode().strip();attrs[p]=git('check-attr','--cached','text','eol','--',p).decode().strip()
 checks=[sha(w)==r['working_byte_sha256'],sha(b)==r['index_blob_byte_sha256'],oid==r['git_blob_oid'],len(w)==r['working_bytes'],len(b)==r['index_blob_bytes'],(w==b)==r['working_equals_index'],w==b if r['byte_policy']=='EXACT_RAW' else w.replace(b'\r\n',b'\n')==b]
 if not all(checks):errors.append([p,checks])
 if w!=b:diffs.append(p)
 if b'\r\r\n' in b:cr.append({'path':p,'count':b.count(b'\r\r\n'),'LF':b.count(b'\n'),'CRLF':b.count(b'\r\n'),'CR':b.count(b'\r'),'lines':[i for i,l in enumerate(b.split(b'\n'),1) if l.endswith(b'\r\r')],'sha256':sha(b),'trailing_spaces_tabs':bool(re.search(rb'[ \t]+\r*\n',b))})
out.update(manifest_errors=errors,differences=diffs,crcrlf=cr,attributes=attrs)
out['old_manifest_deltas']=[p for p,r in old['files'].items() if sha((R/p).read_bytes())!=r['checkout_byte_sha256']]
snap=load(A/'reaudit-source-snapshot.json');out['positive_snapshot_deltas']=[p for p,r in snap['files'].items() if sha((R/p).read_bytes())!=r['sha256']];out['positive_backend_count']=sum(p.startswith('backend/') for p in snap['files'])
initial=load(R/(H+'original-audit/independent-source-snapshot.json'));out['archive_failures']=[p for p,r in initial['files'].items() if sha(blob(H+'history/initial/'+p))!=r['sha256'] or sha((A/p).read_bytes())!=r['sha256']];out['archive_count']=len(initial['files'])
out['audit_copies']={n:{'original_sha':sha((A/n).read_bytes()),'blob_sha':sha(blob(H+'original-audit/'+n)),'equal':(A/n).read_bytes()==blob(H+'original-audit/'+n)} for n in ['Independent-Audit-Report.md','independent-source-snapshot.json']};out['negative_verdict_preserved']=b'CHANGES REQUIRED' in blob(H+'original-audit/Independent-Audit-Report.md')
frozen=load(R/(P+'frozen-ownership.json'))['checked_frozen_files'];out['frozen_failures']=[r['path'] for r in frozen if sha(blob(r['path']))!=r['head_blob_sha256'] or sha((R/r['path']).read_bytes())!=r['checkout_sha256'] or sha(git('show',out['head']+':'+r['path']))!=r['input_blob_sha256']];out['frozen_count']=len(frozen)
allow=e['exact_evidence_allowlist'];ex=[':(exclude,literal)'+r['path'] for r in allow];out['allow_count']=len(allow);out['allow_duplicates']=len(allow)-len({r['path'] for r in allow});out['allow_vs_raw']=sorted(set(r['path'] for r in allow)^set(p for p,r in m['files'].items() if r['byte_policy']=='EXACT_RAW'));out['allow_hash_failures']=[r['path'] for r in allow if sha(blob(r['path']))!=r['required_blob_and_work_sha256']]
ws={}
for name,args in {'ordinary':['diff','--cached','--check'],'cr-at-eol':['-c','core.whitespace=cr-at-eol','diff','--cached','--check'],'scoped-ordinary':['diff','--cached','--check','--','.',*ex],'scoped-cr-at-eol':['-c','core.whitespace=cr-at-eol','diff','--cached','--check','--','.',*ex]}.items():
 r=run('git',*args);raw=r.stdout+r.stderr;groups=collections.defaultdict(list)
 for p,n,why in re.findall(rb'^([^\n]+):(\d+): ([^\n]+)\.\r?$',raw,re.M):groups[p.decode()].append({'line':int(n),'reason':why.decode()})
 ws[name]={'exit':r.returncode,'count':sum(map(len,groups.values())),'paths':len(groups),'sha256':sha(raw),'expected_equal':r.returncode==e['final_checks'][name]['exit_code'] and dict(groups)==e['final_checks'][name]['findings_by_path'] and sha(raw)==e['final_checks'][name]['diagnostic_sha256']}
 if name=='ordinary':out['allow_without_diagnostics']=[r['path'] for r in allow if r['path'] not in groups]
out['whitespace']=ws
p=H+'F02-runtime.patch';new=blob(p);lines=new.splitlines(keepends=True)
for n in (10,13,31,32):assert lines[n-1]==b'\n';lines[n-1]=b' \n'
oldpatch=b''.join(lines);out['patch']={'new_sha':sha(new),'new_bytes':len(new),'old_blob_sha':sha(oldpatch),'old_work_sha':sha(oldpatch.replace(b'\n',b'\r\n')),'matches_old_manifest':sha(oldpatch.replace(b'\n',b'\r\n'))==old['files'][p]['checkout_byte_sha256']}
pat=[rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',rb'\bgh[pousr]_[A-Za-z0-9]{30,}',rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}',rb'\bxox[baprs]-[A-Za-z0-9-]{20,}',rb'\bsk-(?:proj-)?[A-Za-z0-9_-]{32,}'];out['secret_signature_paths']=[p for p in paths if any(re.search(q,blob(p)) for q in pat)];out['runtime_cache_paths']=[p for p in paths if re.search(r'(^|/)(\.env|\.venv|venv|__pycache__)(/|$)|\.(pyc|sqlite3|db|pem|pfx)$',p)]
t=Path(__file__).parent; c=t/'repo';(t/'preliminary.json').write_text(json.dumps(out,indent=2),encoding='utf-8'); c.mkdir(exist_ok=True); git('init',str(c),cwd=t); common=Path(git('rev-parse','--git-common-dir').decode().strip()); (c/'.git/objects/info/alternates').write_text(str(common/'objects').replace('\\','/')+'\n',encoding='utf-8',newline='\n');git('update-ref','refs/heads/'+out['branch'],out['head'],cwd=c);git('symbolic-ref','HEAD','refs/heads/'+out['branch'],cwd=c);git('update-ref','refs/remotes/origin/ms7-mig-react-fastapi',out['head'],cwd=c);git('config','core.longpaths','true',cwd=c);shutil.copyfile(idx,c/'.git/index');git('checkout-index','--all','--force',cwd=c)
out['clean_checkout_raw_failures']=[p for p,r in m['files'].items() if r['byte_policy']=='EXACT_RAW' and (c/p).read_bytes()!=blob(p)]
for p in paths:(c/p).write_bytes((R/p).read_bytes())
(c/'var').mkdir(exist_ok=True)
ver=Q+'verify_publication.py'
def verify():
 r=run(sys.executable,ver,cwd=c);return {'exit':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace')[-1500:]}
out['verifier_baseline']=verify();p0=allow[0]['path'];saved=(c/p0).read_bytes();(c/p0).write_bytes(saved+b'X');out['negative_raw_work']=verify();git('add','--',p0,cwd=c);out['negative_raw_index']=verify();(c/p0).write_bytes(saved);git('add','--',p0,cwd=c)
x='backend/content/grades.py';savedx=(c/x).read_bytes();(c/x).write_bytes(savedx+b'\n# independent negative probe \t\n');git('add','--',x,cwd=c);out['negative_outside_allowlist']=verify();out['negative_scoped_exit']=run('git','diff','--cached','--check','--','.',*ex,cwd=c).returncode;(c/x).write_bytes(savedx);git('add','--',x,cwd=c)
removed=out['allow_without_diagnostics'][0];evpath=c/(Q+'publication-evidence.json');mvpath=c/(Q+'publication-manifest.json');ev=load(evpath);ev['exact_evidence_allowlist']=[r for r in ev['exact_evidence_allowlist'] if r['path']!=removed];evpath.write_text(json.dumps(ev,indent=2)+'\n',encoding='utf-8',newline='\n');git('add','--',Q+'publication-evidence.json',cwd=c)
mm=load(mvpath);rr=mm['files'][Q+'publication-evidence.json'];bb=git('show',':'+Q+'publication-evidence.json',cwd=c);rr.update(working_byte_sha256=sha(evpath.read_bytes()),index_blob_byte_sha256=sha(bb),git_blob_oid=git('rev-parse',':'+Q+'publication-evidence.json',cwd=c).decode().strip(),working_bytes=len(evpath.read_bytes()),index_blob_bytes=len(bb),working_equals_index=True);mvpath.write_text(json.dumps(mm,indent=2)+'\n',encoding='utf-8',newline='\n');git('add','--',Q+'publication-manifest.json',cwd=c);out['negative_allowlist_remove']={'removed':removed,'verifier':verify()}
d=t/'patch';target='backend/infrastructure/http/app.py';(d/target).parent.mkdir(parents=True);(d/target).write_bytes(blob(H+'history/initial/'+target));(d/'fix.patch').write_bytes(new);checks=[]
for args in (['--check'],[]):
 r=run('git','apply','-p1',*args,str(d/'fix.patch'),cwd=d);checks.append({'exit':r.returncode,'stderr':r.stderr.decode()})
out['patch'].update(checks=checks,result_exact=(d/target).read_bytes()==blob(target));out['original_state_preserved']=before==state();out['original_index_sha256']=before['index'];(t/'results.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='attributes'},indent=2))



