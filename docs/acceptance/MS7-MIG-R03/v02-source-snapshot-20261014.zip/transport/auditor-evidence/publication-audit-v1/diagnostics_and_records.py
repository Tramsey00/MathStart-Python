import json,subprocess,os,hashlib,collections,re
from pathlib import Path
R=Path(r'C:\Projects\MathStart-Python-V02');T=Path(__file__).parent;P='docs/acceptance/MS7-MIG-V02/';Q=P+'publication-byte-audit/';os.environ['GIT_OPTIONAL_LOCKS']='0';e=json.loads((R/(Q+'publication-evidence.json')).read_bytes());pre=json.loads((T/'results.json').read_bytes());out={}
for name,args in [('ordinary',['diff','--cached','--check']),('cr-at-eol',['-c','core.whitespace=cr-at-eol','diff','--cached','--check'])]:
 r=subprocess.run(['git',*args],cwd=R,capture_output=True);raw=r.stdout+r.stderr;(T/(name+'-diagnostics.txt')).write_bytes(raw);groups=collections.defaultdict(list)
 for p,n,reason in re.findall(rb'^([^\n]+):(\d+): ([^\n]+)\.\r?$',raw,re.M):groups[p.decode()].append({'line':int(n),'reason':reason.decode()})
 out[name]={'exit':r.returncode,'sha256':hashlib.sha256(raw).hexdigest(),'findings_by_path':groups}
ex=[':(exclude,literal)'+p for p in out['ordinary']['findings_by_path']];out['narrowed40_checks']={}
for name,args in [('ordinary',[]),('cr-at-eol',['-c','core.whitespace=cr-at-eol'])]:
 r=subprocess.run(['git',*args,'diff','--cached','--check','--','.',*ex],cwd=R,capture_output=True);out['narrowed40_checks'][name]={'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()}
# Full indexed data used to independently remeasure every manifest entry, including self.
m=json.loads((R/(Q+'publication-manifest.json')).read_bytes());paths=list(m['files'])+[Q+'publication-manifest.json'];s=subprocess.check_output(['git','ls-files','--stage','-z'],cwd=R).split(b'\0')[:-1];ids={x.split(b'\t')[1].decode():x.split()[1].decode() for x in s};raw=subprocess.run(['git','cat-file','--batch'],input=('\n'.join(ids[p] for p in paths)+'\n').encode(),cwd=R,capture_output=True,check=True).stdout;pos=0;records={}
for p in paths:
 end=raw.index(b'\n',pos);n=int(raw[pos:end].split()[-1]);pos=end+1;b=raw[pos:pos+n];pos+=n+1;w=(R/p).read_bytes();records[p]={'working_sha256':hashlib.sha256(w).hexdigest(),'blob_sha256':hashlib.sha256(b).hexdigest(),'blob_oid':ids[p],'working_bytes':len(w),'blob_bytes':len(b),'effective_attributes':pre['attributes'].get(p),'eol_only_difference':w!=b and w.replace(b'\r\n',b'\n')==b}
out['independent128_records']=records;(T/'diagnostics-and-records.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({'narrowed40_checks':out['narrowed40_checks'],'independent_records':len(records)},indent=2))
