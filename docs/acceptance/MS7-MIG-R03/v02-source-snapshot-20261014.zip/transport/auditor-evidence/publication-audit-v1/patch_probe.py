import json,subprocess,hashlib
from pathlib import Path
R=Path(r'C:\Projects\MathStart-Python-V02');T=Path(__file__).parent;pre=json.loads((T/'preliminary.json').read_bytes());attrs=pre['attributes'];print(json.dumps({'eol_differences':len(pre['differences']),'backend_wrong_attributes':[p for p in attrs if p.startswith('backend/') and ': text: auto' not in attrs[p]],'raw_count':sum(': text: unset' in v for v in attrs.values()),'secrets':pre['secret_signature_paths'],'runtime_caches':pre['runtime_cache_paths'],'manifest_paths_missing':pre['manifest_missing'],'manifest_paths_extra':pre['manifest_extra'],'untracked':pre['untracked'],'unstaged':pre['unstaged']},indent=2))
# Separate immediate patch probe, no dependency on running verifier scratch.
d=T/'independent-patch';target='backend/infrastructure/http/app.py';(d/target).parent.mkdir(parents=True,exist_ok=True)
def blob(p):return subprocess.check_output(['git','show',':'+p],cwd=R)
subprocess.run(['git','init',str(d)],check=True,capture_output=True);(d/'.gitattributes').write_bytes(blob('.gitattributes'));p='docs/acceptance/MS7-MIG-V02/remediation-f01-f02/';(d/target).write_bytes(blob(p+'history/initial/'+target));(d/'fix.patch').write_bytes(blob(p+'F02-runtime.patch'));out={}
for key,args in [('strict_check',['--check']),('apply',[])]:
 r=subprocess.run(['git','apply','-p1',*args,str(d/'fix.patch')],cwd=d,capture_output=True);out[key]={'exit':r.returncode,'stderr':r.stderr.decode()}
out['exact_result']=(d/target).read_bytes()==blob(target);(T/'patch-probe.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))

