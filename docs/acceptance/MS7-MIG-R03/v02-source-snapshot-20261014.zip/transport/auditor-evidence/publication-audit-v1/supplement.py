import json,hashlib,subprocess
from pathlib import Path
R=Path(r'C:\Projects\MathStart-Python-V02'); T=Path(__file__).parent;P='docs/acceptance/MS7-MIG-V02/';e=json.loads((R/(P+'publication-byte-audit/publication-evidence.json')).read_bytes());out={'provenance':[]}
for r in e['exact_evidence_allowlist']:
 p=r['provenance'];x={'path':r['path'],'provenance':p}
 if 'source_log' in p:
  src=Path(p['source_log']);x['exists']=src.exists();x['source_hash_ok']=src.exists() and hashlib.sha256(src.read_bytes()).hexdigest()==p['source_log_sha256'];x['staged_hash_matches_source']=r['required_blob_and_work_sha256']==p['source_log_sha256']
 out['provenance'].append(x)
out['source_hash_failures']=[r for r in out['provenance'] if 'source_hash_ok' in r and not r['source_hash_ok']]
# Real Windows newline translation, actual Django code inspected separately.
import io,os
b=io.BytesIO();t=io.TextIOWrapper(b,encoding='utf-8',newline=None);t.write('Creating test database'+os.linesep);t.flush();out['windows_newline_probe_hex']=b.getvalue().hex()
(T/'supplement.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({'source_hash_failures':out['source_hash_failures'],'provenance_count':len(out['provenance']),'raw_logs':sum('source_log' in r['provenance'] for r in out['provenance']),'newline_hex':out['windows_newline_probe_hex']},indent=2))
