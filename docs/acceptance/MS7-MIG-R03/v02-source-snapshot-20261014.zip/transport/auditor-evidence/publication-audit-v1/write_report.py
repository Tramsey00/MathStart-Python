from pathlib import Path
import json,subprocess,hashlib,os
T=Path(__file__).parent;R=Path(r'C:\Projects\MathStart-Python-V02');d=json.loads((T/'results.json').read_bytes());s=json.loads((T/'supplement.json').read_bytes());extra=json.loads((T/'negative-add-exemption.json').read_bytes());clean=json.loads((T/'clean-checkout-verifier.json').read_bytes());records=json.loads((T/'diagnostics-and-records.json').read_bytes());patch=json.loads((T/'patch-probe.json').read_bytes());os.environ['GIT_OPTIONAL_LOCKS']='0'
def link(name):return f'[{name}](<{(T/name).as_posix()}>)'
idx=Path(subprocess.check_output(['git','rev-parse','--git-path','index'],cwd=R).decode().strip());now=hashlib.sha256(idx.read_bytes()).hexdigest();final={'index_sha256':now,'index_preserved':now==d['original_index_sha256'],'staged':len(subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=R).split(b'\0'))-1,'unstaged':subprocess.check_output(['git','diff','--name-only'],cwd=R).decode(),'untracked':subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode()};(T/'final-state.json').write_text(json.dumps(final,indent=2),encoding='utf-8')
report=f'''# MS7-MIG-V02 — Independent Publication Audit Report

13.10.2026, Europe/Moscow. Owner: Владимир. Reviewer / Task Approver / root verification Owner: Руслан. Issue #35. Независимый STRICT READ-ONLY аудит публикационной подготовки; исходный working tree и index не изменялись. Все mutations и negative probes выполнены в отдельных временных audit-копиях вне репозитория. БД, commit, push, PR и human approval не выполнялись.

**Verdict: CHANGES REQUIRED.** Исторические bytes, staged blobs, patch и неизменность реализации подтверждены. Предложенный exception verifier не обеспечивает неизменность самого утверждаемого списка исключений; обычный clean checkout также не проходит этот verifier. Это публикационные findings, а не повторное открытие F01/F02 runtime-дефектов.

## 1. Exact HEAD, branch и Git index scope

- Branch: `ms7-mig-v02-content`.
- HEAD / V02_BASE_SHA / merge-base с `origin/ms7-mig-react-fastapi`: `0c03197e23f69a233c0fcf8bdffa336feca20b92`.
- Merge-base с immutable MIG_BASE_SHA: `60b341fbd00f4c8dadd54ae9a3e5811869a9b0f7`.
- Staged: ровно **128**, все `A`. Unstaged: 0. Untracked: 0. Modified/deleted baseline paths: 0.
- Реальный implementation commit отсутствует; `tested_implementation_sha=null` корректен.
- SHA256 исходного и финального index: `{now}`. Побайтовое сравнение index, status и всех 128 рабочих файлов до/после probes: PASS. Финальный контроль: {link('final-state.json')}.

Фактические инструменты этого аудита: Python 3.12.10, Git 2.47.0.windows.1, Windows. Зависимости не устанавливались. `GIT_OPTIONAL_LOCKS=0`, `PYTHONDONTWRITEBYTECODE=1` использованы для независимых probes.

## 2. Staged 128-file reconciliation

| Категория | Файлов |
| --- | ---: |
| Текущие backend production/test paths | 28 |
| Исторический initial archive | 47 |
| Original negative audit report + snapshot | 2 |
| Publication audit files | 4 |
| Остальные V02 records, local attributes, plan и trace | 47 |
| Всего | 128 |

Publication manifest: 127 entries + manifest self. Missing/extra paths: 0. Все пути входят в ownership активного V02 plan: `backend/content`, `backend/staff`, `backend/infrastructure/http`, `backend/tests/v02`, V02 acceptance directory, V02 plan/trace. Добавлений в V01/Alembic, frozen contracts, frontend или root CI нет.

Независимый staged-byte signature scan, inspection filenames и сохранённый verifier credential scan не нашли secrets, DB/SQLite, venv, runtime caches, pyc или private-key files. Это не доказательство обнаружения любых возможных secrets; специализированный scanner не запускался.

## 3. F02-runtime.patch byte/provenance verification

Единственная дельта относительно независимого положительного 123-file source snapshot — этот patch. Новый рабочий файл и staged blob равны, размер 3336 bytes, SHA256:
`25eff3c55a118c5009e66586c1fc0f612a3f0a7c1c3916766cb854b22e204194`.

Независимая реконструкция добавлением ASCII context marker обратно только на строках 10, 13, 31, 32 дала прежний indexed SHA256:
`ca926a034f8820e35b13dd88c69b71ff199db23cdd590b8e9a754332d8ea88be`.
Возврат CRLF дал исходный working SHA256:
`d8582e6d412b18286aec29e51f326e4ceee2cfb44f9d63d985a58014a105b0b2`, совпадающий с положительным re-audit/workspace snapshot.

Следовательно, working-byte изменение включает LF-нормализацию всех 72 CRLF и удаление четырёх marker-пробелов. Относительно прежнего Git blob удалены только четыре bytes. Других текстовых/hunk/context изменений нет; patch не скрывает дополнительных изменений.

Из archived `history/initial/backend/infrastructure/http/app.py` в отдельном Git root с исходным root `.gitattributes`:
`git apply -p1 --check` exit 0; `git apply -p1` exit 0; результат **byte-identical** текущему indexed `app.py`. Нет ignore-whitespace, reject или unidiff-zero. Proof: {link('patch-probe.json')} и {link('patch_probe.py')}.

Контрольная попытка вне Git attributes при системном `core.autocrlf=true` дала CRLF output: strict apply exit 0, но exact-byte comparison false, LF-normalized comparison true. Этот фактический результат сохранён в `results.json::patch`; его нельзя выдавать за byte-identical PASS. Повтор с правильной исходной EOL policy дал exact PASS. Неверного baseline или потери контекста не обнаружено.

## 4. Historical raw-byte preservation

Независимо проверены все 47 staged archive blobs по исходному independent snapshot и исходным файлам audit-копии: SHA256/bytes сохранены. Две сохранённые original-audit копии равны своим внешним originals:

- Report: `1feaa929b56e5485534fbc606184c8be9953199c1d558782a8fe6717549ddbd2`.
- Snapshot: `19349dca6f3dc9560723a8837766d01a114c6917b158c27a825fafbab0b74a30`.

Отрицательный verdict **CHANGES REQUIRED** сохранён. Положительный аудит — отдельный `Final-Independent-F01-F02-Re-Audit.md` во внешнем audit directory `01a13205-a85a-7183-94b5-1483f3b7aba9/audit`, с собственным `reaudit-source-snapshot.json`; он не подменяет отрицательный документ и не является approval Руслана.

CRCRLF найдены только в трёх staged V02 raw logs:

| Относительно V02 acceptance directory | CRCRLF | Строки | SHA256 |
| --- | ---: | --- | --- |
| `verify-repo-command.txt` | 2 | 68, 79 | `b350b6ec5e6bfb56e3064f210aa337a95a89a8edd0f714bd3706a8031db57b75` |
| `remediation-f01-f02/history/initial/docs/acceptance/MS7-MIG-V02/verify-repo-command.txt` | 2 | 68, 79 | тот же |
| `remediation-f01-f02/verify-repo-command.txt` | 2 | 68, 79 | `da00309e1d91b592e91f52a20b7be8a9b7b4696d6c59adc91e46c4ecccf24ea2` |

Каждый: 194 LF, 194 CRLF, 196 CR; пробелов/табов перед окончаниями этих строк нет. Всего 6 CRCRLF occurrences, а не 6 trailing-space/tab defects. `Django BaseDatabaseCreation.log()` в установленной версии пишет `msg + os.linesep`; собственный Windows TextIOWrapper probe воспроизвёл `0D 0D 0A`. Это подтверждает механизм происхождения. Все 24 `source_log` paths из provenance существуют и их реальные SHA256 совпадают со staged logs: {link('supplement.json')}. Raw logs не редактировались.

## 5. .gitattributes effective rules

Фактический путь: `docs/acceptance/MS7-MIG-V02/.gitattributes`. Область — только этот subtree. Root attributes и Git config исходного репозитория не изменены.

- `remediation-f01-f02/history/initial/** -text`: 47 historical snapshot files.
- `remediation-f01-f02/original-audit/** -text`: 2 imported originals.
- `*-command.txt -text` и remediation rule: 24 current raw command logs.
- Root default: `* text=auto eol=lf`; inherited `eol=lf` для raw paths остаётся видимым в check-attr, но при `text=unset` conversion отключено.
- Все 28 active backend/source/test files имеют `text=auto`, `eol=lf`, не `-text`. Архивные code/test copies намеренно raw historical artifacts.

Effective attributes проверены для каждой из 127 manifest entries; сохранены в {link('results.json')} и {link('diagnostics-and-records.json')}. Diff/whitespace suppression attributes отсутствуют. Предсказуемость staged text normalization подтверждена фактическими bytes.

Отдельный clean checkout/index export сохранил все 73 raw files побайтно; Git `core.longpaths=true` понадобился только временной копии из-за длинного audit directory. Initial `git clone` был ограничен sandbox/MSYS; использован отдельный Git root, копия index и read-only object alternates. Objects/index исходного repository не записывались. Ограничение самого verifier после clean checkout описано в §10/13.

## 6. Git blob SHA256/object ID verification

Для каждой manifest entry независимо измерены working SHA256, staged SHA256, `git rev-parse :path` blob OID, оба размера, equality и normalization policy. Несовпадений: **0/127**. Manifest self working/index equality подтверждена; собственная независимая запись self OID/hash/size также включена в набор **128 measured records**: {link('diagnostics-and-records.json')}.

Source provenance реконструирована из внешнего positive 123-file snapshot, original 47-file snapshot/intake, 24 source logs и пяти добавленных publication artifacts. Publication manifest различает checkout hashes, staged blob hashes/OIDs и отсутствующий implementation commit. OID не выдаётся за commit SHA. Provenance не является отдельным полем каждой manifest entry: соответствующие связи находятся в source snapshots и publication-evidence.

## 7. Working copy versus blob differences

Ровно **20** различий SHA256 working/index. Каждое полностью объясняется `working.replace(CRLF, LF) == staged`; никаких иных byte differences. Все 73 EXACT_RAW entries равны working/index bytes. Все 28 active backend files равны working/index и независимому positive re-audit snapshot.

Полный список 20 paths — Appendix A. Старый workspace manifest не переписан; его SHA256 остаётся `aa6fff39637b1b775e2034c844428881756c0bb8077e05d62f09da7e50e01d0b`.

## 8. Exact whitespace diagnostics

| Check | Exit | Diagnostics | Paths | Verdict |
| --- | ---: | ---: | ---: | --- |
| `git diff --cached --check` | 2 | 3887 | 40 | **FAIL** |
| `git -c core.whitespace=cr-at-eol diff --cached --check` | 2 | 6 | 3 | **FAIL** |
| Ordinary outside original73 allowlist | 0 | 0 | 0 | PASS scoped |
| cr-at-eol outside original73 allowlist | 0 | 0 | 0 | PASS scoped |

Полные path/line/reason arrays и byte hash diagnostic streams независимо совпали с developer evidence. Ordinary stream SHA256: `c1b69b199ac5cd41c665d656a72587d36ff0d13dc04a82c0a4c3d75086da20fb`; cr-at-eol: `5837278beb0d2ef638db564512c6913f9ae02346d204ba7b75c059aaef373f63`.

Собственные несокращённые outputs: {link('ordinary-diagnostics.txt')}, {link('cr-at-eol-diagnostics.txt')}; exact path/line mappings: {link('diagnostics-and-records.json')}. Exit 0 локального verifier не переименовывает полные FAIL в PASS.

## 9. Justification of 73-path allowlist

73 = 47 archived initial files + 2 imported original audit artifacts + 24 raw logs. Все 73 уникальны и закреплены фактическими Git blob SHA256; current paths равны EXACT_RAW set. Текущих executable implementation files, active tests, mutable reports или publication manifest в исходном allowlist нет. Archived code/tests/reports/manifests входят как historical snapshots.

Сохранение bytes всех 73 обосновано evidence provenance. Однако whitespace exemption требуется только **40** paths с ordinary diagnostics. Другие **33**, перечисленные в Appendix B, можно оставить raw/hash-pinned без исключения из whitespace checks. Это независимо проверено: оба scoped checks с исключением только этих40 paths завершились exit 0. При policy `cr-at-eol` residual exception нужен лишь3 CRCRLF logs, но изменение нормативной whitespace policy тоже требует решения Owner.

## 10. Negative testing of exception enforcement

Запуск **неизменённого staged verifier** в отдельной копии с исходными working bytes: exit 0, full checks 2/2, scoped checks 0/0. Собственные probes:

| Probe | Actual result |
| --- | --- |
| Изменение одного raw working byte | verifier exit 1: Unstaged drift |
| Тот же byte change staged в scratch index | verifier exit 1: hash mismatch |
| Новая trailing-space/tab строка вне allowlist | verifier exit 1; scoped Git check exit 2 |
| Удаление `remediation-f01-f02/compile-command.txt` из allowlist; пересчёт mutable evidence/manifest | **verifier exit 0**, список уже72 |
| Добавление нового mutable `publication-byte-audit/report.md` в полученный список; снова73, пересчёт двух JSON | **verifier exit 0** |
| Обычный clean checkout исходного staged index | **verifier exit 1**: working hash `acceptance-draft.md` |

Для двух list mutations production source, raw evidence, historical snapshots и diagnostics не изменялись. Изменялись только policy container `publication-evidence.json` и его record в mutable self-unhashed `publication-manifest.json`. Baseline/current file count оставался128. Это доказывает отсутствие проверки точного утверждаемого списка, а не обход SHA256 неизменённого manifest.

Exact diagnostics проверяются: verifier сравнивает exit, path/line/reason arrays и diagnostic stream SHA256; вывод не просто подавляется. Но expected diagnostics и exemption list находятся в изменяемом policy container. Нет независимого approved digest для самой policy, hardcoded exact set/count, equality allowlist/EXACT_RAW gate или внешнего approval anchor. Проверки OID/size fields также отсутствуют в самом verifier, хотя в этом аудите эти поля сверены.

Raw byte и whitespace негативы: {link('results.json')}; unexpected mutable exemption: {link('negative-add-exemption.json')}; clean checkout: {link('clean-checkout-verifier.json')}. Все probe sources сохранены в этом же temporary audit directory.

Clean checkout сохраняет staged LF representation text files и raw bytes, но verifier требует original CRLF working hashes 20 text files. Исходная публикационная копия проходит; стандартный новый checkout — нет. Для независимого воспроизведения нужен документированный режим indexed/checkout verification или отдельное восстановление input checkout representation без изменения historical snapshots.

## 11. Frozen / ownership checks

60 frozen entries: base/HEAD/index/checkouts соответствуют recorded hashes; failures0. Поскольку все128 staged entries — additions, изменения existing V01 foundation/Alembic/R02/R02A/R03A/frontend/root CI отсутствуют. Действующий V02 plan допускает эти backend/doc zones. Local attributes не распространяются на чужие owner-зоны. Root verification/CI owner остаётся Руслан; локальный V02 verifier не меняет обязательные project checks.

## 12. Unchanged F01/F02 implementation evidence

Positive external re-audit source snapshot проверен независимо, а не по assertion developer report. Все **28** current backend/source/test files byte-identical ему. Единственная existing-file delta в123 reviewed files — минимальная F02 patch modification из §3.

- `backend/content/releases.py`: SHA256 `26b11598b287ab063273e3ffe393fbd40da34be1cbc00fdb005125a8439853b4`.
- `backend/infrastructure/http/app.py`: SHA256 `1228cb796b594852cc80c2427766c8f0627c2d5fc8a9fb5e18022fb6ceb718e7`.
- F01/F02 regression sources, comparator и original test modules также совпадают.

Повторный runtime regression audit вследствие этой publication delta не требуется: код/тесты не изменялись. V01/frozen сохранены. Предыдущие независимые runtime results относятся к этому code snapshot; новым выполнением suites они здесь не объявляются.

## 13. Remaining P1/P2/P3 findings

**P1: none observed in this publication scope.**

**PUB-F01 / P2 — exemption list approval boundary не enforced.** `verify_publication.py:136–139` читает список из изменяемого evidence и проверяет только hashes его текущих members. Negative removal и introduction mutable report проходят exit0. Заявление «любое появление нового exempt path требует нового review» не обеспечивается executable gate. До публикации требуется exact set/type/count check и закрепление reviewed policy digest/состава в независимом approval anchor; простой пересчёт соседнего manifest не должен заменять review. Нужны failing negative probes для удаления/замены/расширения списка.

**PUB-F02 / P2 — independent clean-checkout verification неполна.** `verify_publication.py:103` отвергает корректный Git-normalized checkout, требуя input CRLF working bytes. Требуется воспроизводимая documented source/staged/checkout distinction и rerun в clean copy. Historical workspace manifest и raw evidence переписывать нельзя.

**PUB-F03 / P3 — whitespace exemption можно сузить.** 33 из73 paths имеют0 diagnostics. Сохранить73 raw/hash records, но исключать из ordinary check лишь40 подтверждённых paths; либо явно обосновать более широкий approved policy.

**PUB-F04 / P3 — publication status records stale.** Publication/remediation records помечают positive independent re-audit PENDING, хотя внешний положительный report существует и его source snapshot подтверждён. Нужна новая отдельная provenance/status запись, не редактирование historical negative audit. Task Approval остаётся PENDING.

## 14. NOT VERIFIED

- Новый запуск `scripts/verify_repo.py`, backend/PG suites и fresh smoke в этом publication audit не выполнялся: пользователь ограничил scope post-re-audit publication changes, runtime/test bytes совпадают с независимо проверенным snapshot. Их прежние PASS не названы новым запуском.
- Future published commit SHA/blob binding, candidate CI, external GitHub approval receipts и human Task Approval Руслана отсутствуют/не проверены.
- Cross-OS verifier portability не проверена; независимая копия была Windows.
- Специализированный secret scanner и новые production/integration/deployment checks не запускались; production DB не использовалась.

## 15. Required Ruslan approval or alternative remediation

MS7-MIG §§9–11 сохраняют независимый review, exact source/contract/evidence provenance, required checks/CI и отдельное human Task Approval. §10 и V02 plan закрепляют root verify/CI за Русланом. Proposed exception является изменением publication acceptance policy; Владимир/агент не могут сами одобрить waiver.

Предпочтительный путь: сохранить raw73 без изменений; сузить whitespace allowlist до40; закрепить exact reviewed policy отдельно от mutable evidence; закрыть list mutation negatives; обеспечить clean-checkout verification; привязать положительный re-audit новым status/provenance record; затем получить явное решение Руслана по residual full-check FAIL и отдельно Task Approval. При отказе от exception допустима другая согласованная evidence packaging policy с exact-byte archive preservation, без нормализации historical raw logs ради зелёного check.

Полный Git whitespace check остаётся FAIL даже после approval исключения. Условный следующий статус после устранения technical gaps и до human decision: `TECHNICALLY VERIFIED — OWNER EXCEPTION APPROVAL PENDING`. Этот аудит такого статуса текущему verifier не присваивает.

## 16. Verdict and git commit recommendation

**CHANGES REQUIRED.** Сохранность historical/staged bytes и F01/F02 implementation подтверждена; proposed exception enforcement и самостоятельная clean-checkout verification требуют доработки.

**Можно ли сейчас безопасно выполнять git commit?** Побайтово текущие staged blobs сохраняют историю, и обычный commit сам по себе не переписывает эти blobs. Но публикация текущего пакета как прошедшего обязательные gates не обоснована: оба full checks FAIL, exception не approved, технические publication findings открыты. Поэтому рекомендация — **не выполнять git commit как approved publication candidate до remediation и явного решения Руслана**. Это technical recommendation, не human approval. Никакой commit этим аудитом не выполнялся.

## Appendix A — exact20 working/index EOL-only paths

'''+ '\n'.join('- `'+p+'`' for p in d['differences']) + '\n\n## Appendix B — exact33 raw paths without whitespace diagnostics\n\n'+ '\n'.join('- `'+p+'`' for p in d['allow_without_diagnostics'])+ '\n\n## Independent evidence files\n\n'+ '\n'.join('- '+link(p) for p in ['results.json','diagnostics-and-records.json','supplement.json','negative-add-exemption.json','clean-checkout-verifier.json','patch-probe.json','final-state.json','audit.py','negative_add_exemption.py','clean_checkout.py','patch_probe.py','diagnostics_and_records.py'])+'\n'
(T/'Independent-Publication-Audit-Report.md').write_text(report,encoding='utf-8');print(json.dumps({'report':str(T/'Independent-Publication-Audit-Report.md'),'final_state':final,'verdict':'CHANGES REQUIRED'},indent=2))
