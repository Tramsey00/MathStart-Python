from pathlib import Path
import subprocess,json
R=Path(r'C:\Projects\MathStart-Python-V02');T=Path(__file__).parent;d=T/'independent-patch'/'nested-scratch';target='backend/infrastructure/http/app.py';(d/target).parent.mkdir(parents=True,exist_ok=True);raw=subprocess.check_output(['git','show',':docs/acceptance/MS7-MIG-V02/remediation-f01-f02/history/initial/'+target],cwd=R);(d/target).write_bytes(raw)
p=T/'independent-patch/fix.patch';out={}
for name,args in [('check',['--check']),('apply',[])]:
 r=subprocess.run(['git','apply','--verbose','-p1',*args,str(p)],cwd=d,capture_output=True);out[name]={'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()}
out['source_unchanged']=(d/target).read_bytes()==raw;(T/'nested-patch-probe.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))
