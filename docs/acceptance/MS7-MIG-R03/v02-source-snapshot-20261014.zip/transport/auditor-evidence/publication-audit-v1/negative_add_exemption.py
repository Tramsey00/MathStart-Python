import json,subprocess,hashlib,os,sys
from pathlib import Path
T=Path(__file__).parent;C=T/'repo';P='docs/acceptance/MS7-MIG-V02/publication-byte-audit/';os.environ['GIT_OPTIONAL_LOCKS']='0';os.environ['PYTHONDONTWRITEBYTECODE']='1'
def git(*args):return subprocess.check_output(['git',*args],cwd=C)
def sha(b):return hashlib.sha256(b).hexdigest()
ep=C/(P+'publication-evidence.json');mp=C/(P+'publication-manifest.json');e=json.loads(ep.read_bytes());m=json.loads(mp.read_bytes());p=P+'report.md';raw=git('show',':'+p)
e['exact_evidence_allowlist'].append({'path':p,'required_blob_and_work_sha256':sha(raw),'ordinary_lines':[],'cr_at_eol_lines':[],'provenance':{'independent_negative_probe':'new mutable report path; not part of original73'}})
ep.write_text(json.dumps(e,indent=2)+'\n',encoding='utf-8',newline='\n');git('add','--',P+'publication-evidence.json');r=m['files'][P+'publication-evidence.json'];b=git('show',':'+P+'publication-evidence.json');r.update(working_byte_sha256=sha(ep.read_bytes()),index_blob_byte_sha256=sha(b),git_blob_oid=git('rev-parse',':'+P+'publication-evidence.json').decode().strip(),working_bytes=len(ep.read_bytes()),index_blob_bytes=len(b),working_equals_index=True);mp.write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n');git('add','--',P+'publication-manifest.json')
r=subprocess.run([sys.executable,P+'verify_publication.py'],cwd=C,capture_output=True);out={'added_path':p,'allow_count':len(e['exact_evidence_allowlist']),'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()};(T/'negative-add-exemption.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
